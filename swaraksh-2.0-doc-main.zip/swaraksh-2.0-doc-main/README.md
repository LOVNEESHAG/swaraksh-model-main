# ID Document Verification — Python/FastAPI V1

This is the current implementation of the document-only module:

`Secure upload -> file validation -> document detection -> image preprocessing -> OCR -> field extraction/validation -> embedded-face extraction -> basic face-region forensic heuristics -> document integrity heuristics -> cross-validation -> risk engine -> PASS/REVIEW/FAIL`

## Important scope

This V1 does **not** perform live-face capture, liveness detection, or selfie matching.

The face component analyzes the photograph already embedded in the uploaded ID image. The current manipulation detector is intentionally heuristic and should not be presented as a production-grade deepfake classifier.

## Requirements

- Python 3.11+
- Tesseract OCR installed and available on PATH
- pip

Ubuntu/Debian example:

```bash
sudo apt update
sudo apt install tesseract-ocr
```

Windows: install Tesseract and either put it on PATH or set `TESSERACT_CMD` in `.env`.

## Setup

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

Windows Git Bash / macOS / Linux:

```bash
source .venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

Create environment file:

```bash
copy .env.example .env
```

or:

```bash
cp .env.example .env
```

Generate a persistent Fernet key for development:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Paste it into `.env` as `FERNET_KEY=...`.

Start the API:

```bash
uvicorn app.main:app --reload
```

Open:

`http://127.0.0.1:8000/docs`

## Verify a document with curl

Without user-reference comparison:

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/documents/verify" \
  -F "file=@/path/to/document.jpg"
```

With user reference fields:

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/documents/verify" \
  -F "file=@/path/to/document.jpg" \
  -F "expected_name=HARSHAL JAIN" \
  -F "expected_dob=15/08/2003" \
  -F "expected_document_number=ABCDE1234F"
```

## API result

The API returns structured JSON containing:

- detected document type
- OCR confidence and extracted fields
- format/required-field validation
- face detection and a manipulation heuristic score
- document integrity signals
- reference-data cross-validation
- overall risk score and PASS/REVIEW/FAIL decision

## Security/privacy design

The original upload is encrypted before temporary disk storage and is removed in a `finally` block after processing. In production, use HTTPS/TLS, keep the Fernet key outside source control, use a secret manager, restrict database access, and define a documented retention policy.

The API stores the verification result in SQLite by default. Do not store raw identity documents in the database unless there is a clear requirement and an appropriate retention/legal basis.

## Extending V1 later

The function `app/services/face_tampering.py::analyze` is intentionally isolated. A validated pretrained/trained document-forgery or face-manipulation model can replace that implementation while keeping the API and risk engine stable.

## Universal forensic analysis (V2)

The verification core is document-type agnostic. It first evaluates file/image quality, OCR quality, global image statistics, localized recompression anomalies, noise inconsistency, sharpness, and optional embedded-face manipulation signals. Document type is retained only as an informational label and for optional field extraction/format evidence; it does not drive the core tampering score.

A document with an unknown type, weak OCR, or insufficient extracted evidence cannot receive a PASS. It is routed to REVIEW unless strong tampering evidence justifies FAIL.
