import hashlib
import uuid

def new_id():
    return uuid.uuid4().hex

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
