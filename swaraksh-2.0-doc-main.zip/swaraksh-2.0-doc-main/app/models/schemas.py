# app/models/schemas.py

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


# ============================================================
# REFERENCE IDENTITY
# ============================================================

class ReferenceIdentity(BaseModel):
    """
    Optional user/reference data.

    Used only when the caller explicitly supplies reference
    information for cross-validation.
    """

    name: str | None = None

    dob: str | None = None

    document_number: str | None = None


# ============================================================
# OCR REGION
# ============================================================

class OCRRegion(BaseModel):
    """
    Semantic OCR region.

    Coordinates correspond to the document image coordinate
    system after OCR coordinate conversion.
    """

    # Semantic field name, e.g.:
    # name / dob / blood_group / issue_date
    field: str = "unknown"

    # Human-readable label.
    label: str = ""

    # OCR-extracted value.
    value: str = ""

    # Bounding box.
    x: int = 0
    y: int = 0
    w: int = 0
    h: int = 0

    # OCR confidence in [0, 1].
    confidence: float = 0.0


# ============================================================
# EXTRACTED FIELDS
# ============================================================

class ExtractedFields(BaseModel):
    """
    Generic OCR-extracted fields.

    These fields are not restricted to a particular document
    type.
    """

    name: str | None = None

    dob: str | None = None

    document_number: str | None = None

    issue_date: str | None = None

    certificate_id: str | None = None

    course: str | None = None

    issuer: str | None = None

    # --------------------------------------------------------
    # Backward-compatible date regions
    # --------------------------------------------------------

    date_regions: list[dict[str, Any]] = Field(
        default_factory=list
    )

    # --------------------------------------------------------
    # Generic semantic OCR regions
    # --------------------------------------------------------
    #
    # Examples:
    #
    #   name
    #   dob
    #   blood_group
    #   issue_date
    #   validity
    #   document_number
    #   address
    #
    # These regions are used by the localized forensic layer.
    # --------------------------------------------------------

    ocr_regions: list[dict[str, Any]] = Field(
        default_factory=list
    )

    # Full OCR output.
    raw_text: str = ""


# ============================================================
# VALIDATION RESULT
# ============================================================

class ValidationResult(BaseModel):
    """
    Generic/type-independent content validation.

    This does not determine whether a document is genuine.

    Document-specific format checking is not the primary
    authenticity mechanism.
    """

    document_type: str = "unknown"

    # Kept for API compatibility.
    #
    # In the universal architecture this does not represent
    # document authenticity.
    format_valid: bool = True

    required_fields_present: bool = False

    date_valid: bool | None = None

    fields_consistent: bool = False

    # Amount of useful structured content extracted.
    content_quality: float = 0.0

    # SUFFICIENT / INSUFFICIENT / INCONSISTENT
    validation_status: str = "INSUFFICIENT"

    # Successfully populated structured fields.
    populated_fields: list[str] = Field(
        default_factory=list
    )

    messages: list[str] = Field(
        default_factory=list
    )


# ============================================================
# FACE ANALYSIS
# ============================================================

class FaceAnalysis(BaseModel):
    """
    Face detection and face-region forensic analysis.

    Face absence is not automatically considered fraud.
    """

    face_detected: bool = False

    face_count: int = 0

    face_box: dict[str, int] | None = None

    manipulation_probability: float = 0.0

    signals: dict[str, Any] = Field(
        default_factory=dict
    )

    note: str = ""


# ============================================================
# IMAGE QUALITY
# ============================================================

class ImageQuality(BaseModel):
    """
    Universal image-usability signals.

    These measure whether the image is suitable for analysis.

    They do not prove authenticity or forgery.
    """

    width: int = 0

    height: int = 0

    sharpness_score: float = 0.0

    brightness_score: float = 0.0

    contrast_score: float = 0.0

    noise_score: float = 0.0

    document_boundary_detected: bool = False

    likely_cropped: bool = False

    crop_confidence: float = 0.0

    original_area_fraction: float = 1.0

    warnings: list[str] = Field(
        default_factory=list
    )


# ============================================================
# INTEGRITY / FORENSICS
# ============================================================

class IntegrityResult(BaseModel):
    """
    Universal image-forensics result.

    These values are evidence/signals, not proof of authenticity
    or forgery.
    """

    # --------------------------------------------------------
    # Overall image quality
    # --------------------------------------------------------

    score: float = 0.0

    quality_score: float = 0.0

    # --------------------------------------------------------
    # Combined tampering evidence
    # --------------------------------------------------------

    tampering_probability: float = 0.0

    tampering_evidence_score: float = 0.0

    # --------------------------------------------------------
    # Individual evidence components
    # --------------------------------------------------------

    global_tampering_evidence: float = 0.0

    local_tampering_evidence: float = 0.0

    # --------------------------------------------------------
    # PRETRAINED ML FORGERY MODEL
    # --------------------------------------------------------

    ml_forgery: dict[str, Any] = Field(
        default_factory=dict
    )

    # --------------------------------------------------------
    # OCR semantic-region forensic analysis
    # --------------------------------------------------------

    ocr_region_analysis: dict[str, Any] = Field(
        default_factory=dict
    )

    # --------------------------------------------------------
    # Image quality penalty
    # --------------------------------------------------------

    quality_penalty: float = 0.0

    # --------------------------------------------------------
    # Universal forensic signals
    # --------------------------------------------------------

    signals: dict[str, Any] = Field(
        default_factory=dict
    )

    warnings: list[str] = Field(
        default_factory=list
    )

    note: str = ""


# ============================================================
# CROSS VALIDATION
# ============================================================

class CrossValidation(BaseModel):
    """
    Optional comparison against externally supplied reference
    information.
    """

    attempted: bool = False

    name_match: bool | None = None

    dob_match: bool | None = None

    document_number_match: bool | None = None

    match_score: float = 0.0

    messages: list[str] = Field(
        default_factory=list
    )


# ============================================================
# RISK ENGINE
# ============================================================

class RiskResult(BaseModel):
    """
    Final evidence/risk assessment.

    risk_score:
        Amount of suspicious/negative evidence.

    verification_confidence:
        Amount of usable evidence available to support a
        meaningful decision.

    These are different concepts.
    """

    risk_score: float = 0.0

    risk_level: str = "UNKNOWN"

    decision: str = "REVIEW"

    verification_confidence: float = 0.0

    verification_blocked: bool = False

    verification_block_reasons: list[str] = Field(
        default_factory=list
    )

    reasons: list[str] = Field(
        default_factory=list
    )

    signals: dict[str, Any] = Field(
        default_factory=dict
    )

    document_type: str = "unknown"


# ============================================================
# MAIN VERIFICATION RESPONSE
# ============================================================

class VerificationResponse(BaseModel):
    """
    Complete response returned by the document-verification API.
    """

    verification_id: str

    created_at: datetime

    status: str

    risk_level: str

    risk_score: float

    # --------------------------------------------------------
    # Document classification
    # --------------------------------------------------------
    #
    # Informational only.
    #
    # It must not become the authenticity gate.
    # --------------------------------------------------------

    document_type: str

    # --------------------------------------------------------
    # OCR / extracted content
    # --------------------------------------------------------

    fields: ExtractedFields

    # --------------------------------------------------------
    # Generic content validation
    # --------------------------------------------------------

    validation: ValidationResult

    # --------------------------------------------------------
    # Universal image quality
    # --------------------------------------------------------

    image_quality: ImageQuality = Field(
        default_factory=ImageQuality
    )

    # --------------------------------------------------------
    # Face analysis
    # --------------------------------------------------------

    face_analysis: FaceAnalysis

    # --------------------------------------------------------
    # Universal document forensics
    # --------------------------------------------------------

    document_integrity: IntegrityResult

    # --------------------------------------------------------
    # Optional reference comparison
    # --------------------------------------------------------

    cross_validation: CrossValidation

    # --------------------------------------------------------
    # Final risk assessment
    # --------------------------------------------------------

    risk: RiskResult

    # --------------------------------------------------------
    # Privacy / security information
    # --------------------------------------------------------

    privacy: dict[str, Any] = Field(
        default_factory=dict
    )