from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[1]

class Settings(BaseSettings):
    app_name: str = "ID Document Verification API"
    env: str = "development"
    max_upload_mb: int = 10
    temp_retention_seconds: int = 300
    fernet_key: str | None = None
    database_url: str = "sqlite:///./verification.db"
    api_key: str | None = None
    tesseract_cmd: str = "tesseract"
    allow_user_reference_data: bool = True

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

@lru_cache
def get_settings() -> Settings:
    return Settings()
