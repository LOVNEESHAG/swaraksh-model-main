# app/api/document.py

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import (
    APIRouter,
    File,
    Form,
    HTTPException,
    UploadFile,
    status,
)

from ..config import get_settings
from ..database import SessionLocal, VerificationRecord

from ..models.schemas import (
    VerificationResponse,
    ReferenceIdentity,
    ExtractedFields,
    ValidationResult,
    FaceAnalysis,
    ImageQuality,
    IntegrityResult,
    CrossValidation,
    RiskResult,
)

from ..security.encryption import EncryptionService

from ..services.file_validator import (
    validate_image_bytes,
    FileValidationError,
)

from ..services.image_processor import preprocess

from ..services.ocr_service import run_ocr

from ..services.document_detector import (
    detect_document_type,
)

from ..services.field_extractor import (
    extract_fields,
)

from ..services.field_validator import (
    validate_fields,
)

from ..services.face_detector import (
    FaceDetector,
)

from ..services.face_tampering import (
    analyze as analyze_face_tampering,
)

from ..services.document_integrity import (
    analyze as analyze_integrity,
)

from ..services.cross_validator import (
    compare,
)

from ..services.risk_engine import (
    calculate,
)

from ..utils.helpers import (
    new_id,
    sha256,
)


# ============================================================
# ROUTER / SETTINGS
# ============================================================

router = APIRouter(
    prefix="/api/v1/documents",
    tags=["document verification"],
)

settings = get_settings()

encryption = EncryptionService(
    settings.fernet_key
)

face_detector = FaceDetector()


TEMP_DIR = (
    Path(__file__).resolve().parents[2]
    / "storage"
    / "temporary"
)

TEMP_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# ============================================================
# OPTIONAL REFERENCE DATA
# ============================================================

def _clean_optional(
    value: str | None,
) -> str | None:
    """
    Clean optional Swagger/form values.

    Swagger commonly uses the literal string "string"
    as an example value. We must never treat that as
    real reference data.
    """

    if value is None:
        return None

    value = value.strip()

    if value.lower() in {
        "",
        "string",
        "null",
        "none",
        "undefined",
    }:
        return None

    return value


def _parse_reference(
    name: str | None,
    dob: str | None,
    document_number: str | None,
) -> ReferenceIdentity | None:
    """
    Build reference identity only when at least one actual
    reference value was supplied.
    """

    cleaned_name = _clean_optional(name)

    cleaned_dob = _clean_optional(dob)

    cleaned_document_number = _clean_optional(
        document_number
    )

    if not any(
        (
            cleaned_name,
            cleaned_dob,
            cleaned_document_number,
        )
    ):
        return None

    return ReferenceIdentity(
        name=cleaned_name,
        dob=cleaned_dob,
        document_number=cleaned_document_number,
    )


# ============================================================
# OCR REGION COORDINATE CONVERSION
# ============================================================

def _convert_ocr_regions_to_original_scale(
    regions: list[dict] | None,
    scale: float,
    image_width: int,
    image_height: int,
) -> list[dict]:
    """
    Convert OCR bounding boxes from the OCR image coordinate
    system back to the document image coordinate system.

    OCR is performed on an upscaled image, so coordinates are
    divided by the OCR scale.

    The final bounding boxes are clamped to the actual image
    dimensions.
    """

    if not regions:
        return []

    try:
        scale = float(scale)
    except (TypeError, ValueError):
        scale = 1.0

    if scale <= 0:
        scale = 1.0

    try:
        image_width = max(
            1,
            int(image_width),
        )

        image_height = max(
            1,
            int(image_height),
        )

    except (TypeError, ValueError):
        return []

    converted: list[dict] = []

    for region in regions:

        if not isinstance(
            region,
            dict,
        ):
            continue

        try:
            x = float(
                region.get(
                    "x",
                    0,
                )
            )

            y = float(
                region.get(
                    "y",
                    0,
                )
            )

            w = float(
                region.get(
                    "w",
                    0,
                )
            )

            h = float(
                region.get(
                    "h",
                    0,
                )
            )

            confidence = float(
                region.get(
                    "confidence",
                    0.0,
                )
            )

        except (
            TypeError,
            ValueError,
        ):
            continue

        if w <= 0 or h <= 0:
            continue

        # --------------------------------------------------------
        # Scale back to document image coordinates
        # --------------------------------------------------------

        x = int(round(x / scale))
        y = int(round(y / scale))
        w = int(round(w / scale))
        h = int(round(h / scale))

        if w <= 0 or h <= 0:
            continue

        # --------------------------------------------------------
        # Convert width/height to right/bottom
        # --------------------------------------------------------

        x1 = x
        y1 = y
        x2 = x + w
        y2 = y + h

        # --------------------------------------------------------
        # Clamp to image boundaries
        # --------------------------------------------------------

        x1 = max(
            0,
            min(
                x1,
                image_width - 1,
            ),
        )

        y1 = max(
            0,
            min(
                y1,
                image_height - 1,
            ),
        )

        x2 = max(
            x1 + 1,
            min(
                x2,
                image_width,
            ),
        )

        y2 = max(
            y1 + 1,
            min(
                y2,
                image_height,
            ),
        )

        final_width = x2 - x1
        final_height = y2 - y1

        if (
            final_width <= 0
            or final_height <= 0
        ):
            continue

        converted.append(
            {
                "field": str(
                    region.get(
                        "field",
                        "unknown",
                    )
                ),

                "label": str(
                    region.get(
                        "label",
                        "",
                    )
                ),

                "value": str(
                    region.get(
                        "value",
                        "",
                    )
                ),

                "x": x1,
                "y": y1,
                "w": final_width,
                "h": final_height,

                "confidence": max(
                    0.0,
                    min(
                        1.0,
                        confidence,
                    ),
                ),
            }
        )

    return converted


# ============================================================
# IMAGE QUALITY DICTIONARY
# ============================================================

def _build_image_quality(
    processed,
) -> dict[str, Any]:
    """
    Convert ProcessedImage quality attributes into the
    dictionary expected by the forensic layer.
    """

    return {
        "width": processed.width,
        "height": processed.height,

        "sharpness_score": (
            processed.sharpness_score
        ),

        "brightness_score": (
            processed.brightness_score
        ),

        "contrast_score": (
            processed.contrast_score
        ),

        "noise_score": (
            processed.noise_score
        ),

        "document_boundary_detected": (
            processed.document_boundary_detected
        ),

        "likely_cropped": (
            processed.likely_cropped
        ),

        "crop_confidence": (
            processed.crop_confidence
        ),

        "original_area_fraction": (
            processed.original_area_fraction
        ),

        "warnings": list(
            processed.warnings
        ),
    }


# ============================================================
# HEALTH
# ============================================================

@router.get("/health")
def health():
    return {
        "service": "document-verification",
        "status": "ok",
    }


# ============================================================
# DOCUMENT VERIFICATION
# ============================================================

@router.post(
    "/verify",
    response_model=VerificationResponse,
    status_code=status.HTTP_200_OK,
)
async def verify_document(
    file: UploadFile = File(...),

    expected_name: str | None = Form(
        default=None
    ),

    expected_dob: str | None = Form(
        default=None
    ),

    expected_document_number: str | None = Form(
        default=None
    ),
):
    """
    Universal document verification endpoint.

    Core analysis is document-type independent.
    """

    # ========================================================
    # 1. CLEAN OPTIONAL REFERENCE DATA
    # ========================================================

    expected_name = _clean_optional(
        expected_name
    )

    expected_dob = _clean_optional(
        expected_dob
    )

    expected_document_number = (
        _clean_optional(
            expected_document_number
        )
    )

    if (
        not settings.allow_user_reference_data
        and any(
            [
                expected_name,
                expected_dob,
                expected_document_number,
            ]
        )
    ):

        raise HTTPException(
            status_code=400,
            detail=(
                "Reference identity fields are disabled."
            ),
        )

    # ========================================================
    # 2. READ UPLOAD
    # ========================================================

    data = await file.read()

    if not data:

        raise HTTPException(
            status_code=400,
            detail="Uploaded file is empty.",
        )

    # ========================================================
    # 3. FILE VALIDATION
    # ========================================================

    try:

        validate_image_bytes(
            data,
            file.filename or "upload",
            file.content_type,
            settings.max_upload_mb
            * 1024
            * 1024,
        )

    except FileValidationError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    # ========================================================
    # 4. VERIFICATION ID
    # ========================================================

    verification_id = new_id()

    temp_file = (
        TEMP_DIR
        / f"{verification_id}.enc"
    )

    # ========================================================
    # 5. SECURE PROCESSING
    # ========================================================

    try:

        # ----------------------------------------------------
        # Encrypt temporary upload
        # ----------------------------------------------------

        encryption.encrypt_to_file(
            data,
            temp_file,
        )

        # ----------------------------------------------------
        # Decrypt only for processing
        # ----------------------------------------------------

        secured_bytes = (
            encryption.decrypt_file(
                temp_file
            )
        )

        # ====================================================
        # 6. IMAGE PROCESSING
        # ====================================================

        processed = preprocess(
            secured_bytes
        )

        image_quality = (
            _build_image_quality(
                processed
            )
        )

        # ====================================================
        # 7. OCR
        # ====================================================

        ocr = run_ocr(
            processed.document_crop,
            settings.tesseract_cmd,
        )

        # ====================================================
        # 8. DOCUMENT TYPE
        # ====================================================
        #
        # Informational only.
        # It does not control universal forensics.
        # ====================================================

        (
            document_type,
            document_confidence,
            detector_evidence,
        ) = detect_document_type(
            ocr.text,
            processed.document_crop,
        )

        # ====================================================
        # 9. GENERIC FIELD EXTRACTION
        # ====================================================

        fields = extract_fields(
            ocr,
            document_type,
        )

        # ====================================================
        # 10. FIELD VALIDATION
        # ====================================================

        validation = validate_fields(
            fields,
            document_type,
        )

        # ====================================================
        # 11. FACE DETECTION
        # ====================================================

        (
            face_crop,
            faces,
        ) = face_detector.extract_primary_face(
            processed.document_crop
        )

        # ====================================================
        # 12. FACE FORENSICS
        # ====================================================

        if faces:

            face_tamper = (
                analyze_face_tampering(
                    face_crop,
                    processed.document_crop,
                )
            )

            face = {
                "face_detected": True,

                "face_count": len(
                    faces
                ),

                "face_box": faces[0],

                "manipulation_probability": (
                    face_tamper.probability
                ),

                "signals": (
                    face_tamper.signals
                ),

                "note": (
                    face_tamper.note
                ),
            }

        else:

            face = {
                "face_detected": False,

                "face_count": 0,

                "face_box": None,

                "manipulation_probability": 0.0,

                "signals": {
                    "available": False,
                    "heuristic_only": True,
                },

                "note": (
                    "No face was detected. "
                    "Face-region manipulation analysis "
                    "was not applicable to this image."
                ),
            }

        # ====================================================
        # 13. OCR REGIONS
        # ====================================================

        # IMPORTANT:
        # fields["ocr_regions"] are generated using OCR image
        # coordinates. Convert them back to the actual
        # processed.document_crop coordinate system.

        height, width = (
            processed.document_crop.shape[:2]
        )

        ocr_regions = (
            _convert_ocr_regions_to_original_scale(
                fields.get(
                    "ocr_regions",
                    [],
                ),
                getattr(
                    ocr,
                    "scale",
                    1.0,
                ),
                width,
                height,
            )
        )

        # ====================================================
        # 14. UNIVERSAL DOCUMENT FORENSICS
        # ====================================================

        integrity = analyze_integrity(
            image=processed.document_crop,

            perspective_corrected=(
                processed.perspective_corrected
            ),

            ocr_text=ocr.text,

            document_type=document_type,

            face_boxes=faces,

            ocr_confidence=ocr.confidence,

            ocr_regions=ocr_regions,

            image_quality=image_quality,
        )

        # ====================================================
        # 15. OPTIONAL CROSS VALIDATION
        # ====================================================

        reference = _parse_reference(
            expected_name,
            expected_dob,
            expected_document_number,
        )

        cross = compare(
            fields,
            reference,
        )

        # ====================================================
        # 16. RISK ENGINE
        # ====================================================

        risk = calculate(
            ocr_confidence=ocr.confidence,

            validation=validation,

            face_analysis=face,

            integrity=integrity,

            cross=cross,

            document_type=document_type,
        )

        # ====================================================
        # 17. TIMESTAMP
        # ====================================================

        now = datetime.now(
            timezone.utc
        )

        # ====================================================
        # 18. RESPONSE
        # ====================================================

        result = VerificationResponse(

            verification_id=verification_id,

            created_at=now,

            status=risk["decision"],

            risk_level=risk["risk_level"],

            risk_score=risk["risk_score"],

            document_type=document_type,

            fields=ExtractedFields(
                **fields
            ),

            validation=ValidationResult(
                **validation
            ),

            image_quality=ImageQuality(
                **image_quality
            ),

            face_analysis=FaceAnalysis(
                **face
            ),

            document_integrity=IntegrityResult(
                **integrity
            ),

            cross_validation=CrossValidation(
                **cross
            ),

            risk=RiskResult(
                **risk
            ),

            privacy={
                "transport": (
                    "Use HTTPS/TLS in deployment."
                ),

                "temporary_storage": (
                    "Encrypted at rest during processing."
                ),

                "raw_document_retention": (
                    "Deleted after processing attempt."
                ),

                "document_sha256": sha256(data),

                "fernet_ephemeral_key": (
                    encryption.ephemeral
                ),

                "document_classifier_confidence": (
                    document_confidence
                ),

                "document_classifier_evidence": (
                    detector_evidence
                ),

                "ocr_scale": getattr(
                    ocr,
                    "scale",
                    1.0,
                ),

                "ocr_variant": getattr(
                    ocr,
                    "variant",
                    "unknown",
                ),

                "likely_cropped": (
                    processed.likely_cropped
                ),

                "crop_confidence": (
                    processed.crop_confidence
                ),
            },
        )

        # ====================================================
        # 19. DATABASE STORAGE
        # ====================================================

        db = SessionLocal()

        try:

            db.add(
                VerificationRecord(
                    id=verification_id,

                    created_at=now,

                    status=result.status,

                    risk_level=result.risk_level,

                    risk_score=result.risk_score,

                    document_type=(
                        result.document_type
                    ),

                    result_json=json.dumps(
                        result.model_dump(
                            mode="json"
                        )
                    ),
                )
            )

            db.commit()

        finally:

            db.close()

        # ====================================================
        # 20. RETURN
        # ====================================================

        return result

    # ========================================================
    # HTTP EXCEPTIONS
    # ========================================================

    except HTTPException:
        raise

    # ========================================================
    # UNEXPECTED PROCESSING ERROR
    # ========================================================

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "Document processing failed: "
                f"{type(exc).__name__}: {exc}"
            ),
        ) from exc

    # ========================================================
    # ALWAYS DELETE TEMPORARY ENCRYPTED FILE
    # ========================================================

    finally:

        try:

            temp_file.unlink(
                missing_ok=True
            )

        except OSError:

            pass