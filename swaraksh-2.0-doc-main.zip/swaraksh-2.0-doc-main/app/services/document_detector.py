# app/services/document_detector.py

from __future__ import annotations

import re
from typing import Any


# ============================================================
# DOCUMENT TYPE EVIDENCE
# ============================================================

DOCUMENT_PATTERNS: dict[str, list[str]] = {

    "pan": [
        "permanent account number",
        "income tax department",
        "pan card",
    ],

    "passport": [
        "passport",
        "republic of india",
        "nationality",
    ],

    "aadhaar": [
        "aadhaar",
        "unique identification",
        "uidai",
    ],

    "driving_license": [
        "driving licence",
        "driving license",
        "transport department",
        "licence",
    ],

    "voter_id": [
        "election commission",
        "elector",
        "voter",
        "epic",
    ],

    "certificate": [
        "certificate",
        "program completion certificate",
        "successfully completing",
        "certificate of",
    ],
}


# ============================================================
# SIGNAL WEIGHTS
# ============================================================
#
# Strong phrases receive more weight than generic words.
#
# This affects ONLY classification.
#
# It does NOT affect authenticity/tampering risk.
# ============================================================

PATTERN_WEIGHTS: dict[str, float] = {

    "permanent account number": 1.0,
    "income tax department": 1.0,
    "pan card": 0.9,

    "passport": 1.0,
    "republic of india": 0.8,
    "nationality": 0.4,

    "aadhaar": 1.0,
    "unique identification": 1.0,
    "uidai": 1.0,

    "driving licence": 1.0,
    "driving license": 1.0,
    "transport department": 0.8,
    "licence": 0.35,

    "election commission": 1.0,
    "elector": 0.6,
    "voter": 0.7,
    "epic": 0.7,

    "certificate": 0.6,
    "program completion certificate": 1.0,
    "successfully completing": 0.9,
    "certificate of": 0.8,
}


# ============================================================
# TEXT NORMALIZATION
# ============================================================

def normalize_text(
    text: str,
) -> str:
    """
    Normalize OCR text for document-type classification.

    This is ONLY classification preprocessing.
    """

    if not text:
        return ""

    normalized = str(
        text
    ).lower()

    # Normalize common separators.
    normalized = re.sub(
        r"[_|/\\]+",
        " ",
        normalized,
    )

    # Keep letters/numbers and normal spaces.
    normalized = re.sub(
        r"[^a-z0-9\s-]",
        " ",
        normalized,
    )

    normalized = re.sub(
        r"\s+",
        " ",
        normalized,
    )

    return normalized.strip()


# ============================================================
# TOKEN-BOUNDARY MATCH
# ============================================================

def _contains_phrase(
    text: str,
    phrase: str,
) -> bool:
    """
    Match a phrase using word boundaries.

    This avoids accidental substring matches.

    Example:

        "voter" should not match an unrelated word merely
        because "voter" happens to occur inside another word.
    """

    escaped = re.escape(
        phrase.lower()
    )

    pattern = (
        rf"(?<![a-z0-9])"
        rf"{escaped}"
        rf"(?![a-z0-9])"
    )

    return re.search(
        pattern,
        text,
        flags=re.IGNORECASE,
    ) is not None


# ============================================================
# SCORE ONE DOCUMENT TYPE
# ============================================================

def _score_document_type(
    doc_type: str,
    text: str,
) -> tuple[
    float,
    list[str],
]:
    """
    Calculate evidence strength for one document type.

    The score represents classification confidence only.
    """

    patterns = DOCUMENT_PATTERNS.get(
        doc_type,
        [],
    )

    if not patterns:
        return (
            0.0,
            [],
        )

    hits: list[str] = []

    weighted_score = 0.0

    maximum_possible = 0.0

    for pattern in patterns:

        weight = PATTERN_WEIGHTS.get(
            pattern,
            0.5,
        )

        maximum_possible += weight

        if _contains_phrase(
            text,
            pattern,
        ):

            hits.append(
                pattern
            )

            weighted_score += weight

    if maximum_possible <= 0:
        return (
            0.0,
            hits,
        )

    normalized_score = (
        weighted_score
        / maximum_possible
    )

    # --------------------------------------------------------
    # Independent-signal bonus
    # --------------------------------------------------------
    #
    # More than one independent keyword is stronger evidence
    # than one generic keyword.
    # --------------------------------------------------------

    if len(hits) >= 2:
        normalized_score += 0.10

    elif len(hits) == 1:

        # Single weak/generic evidence should remain weak.
        only_hit = hits[0]

        if PATTERN_WEIGHTS.get(
            only_hit,
            0.5,
        ) < 0.60:

            normalized_score *= 0.60

    normalized_score = min(
        1.0,
        normalized_score,
    )

    return (
        normalized_score,
        hits,
    )


# ============================================================
# OPTIONAL IMAGE SHAPE SIGNAL
# ============================================================

def _image_shape_signal(
    image: Any,
) -> float:
    """
    Very weak fallback signal based on aspect ratio.

    It is deliberately NOT a document classifier.

    Aspect ratio alone must never determine document type.
    """

    if image is None:
        return 0.0

    try:

        height, width = (
            image.shape[:2]
        )

        if (
            width <= 0
            or height <= 0
        ):
            return 0.0

        ratio = (
            width
            / float(height)
        )

    except (
        AttributeError,
        TypeError,
        ValueError,
    ):

        return 0.0

    # Keep this signal extremely weak.
    #
    # It only slightly improves classification when OCR
    # evidence already exists.
    if ratio < 0.85:
        return 0.05

    if ratio > 1.65:
        return 0.05

    return 0.0


# ============================================================
# MAIN DOCUMENT TYPE DETECTOR
# ============================================================

def detect_document_type(
    text: str,
    image: Any = None,
) -> tuple[
    str,
    float,
    list[str],
]:
    """
    Detect the most likely document category.

    IMPORTANT:

        This result is informational.

        It does NOT:
            - prove authenticity
            - prove forgery
            - modify tampering scores
            - perform PAN/Aadhaar/passport/DL validation

    The universal forensic pipeline must work even when this
    function returns "unknown".
    """

    normalized = normalize_text(
        text
    )

    if not normalized:

        return (
            "unknown",
            0.0,
            [],
        )

    scores: dict[str, float] = {}

    evidence: dict[
        str,
        list[str],
    ] = {}

    # ========================================================
    # Score each document type
    # ========================================================

    for doc_type in DOCUMENT_PATTERNS:

        score, hits = (
            _score_document_type(
                doc_type,
                normalized,
            )
        )

        scores[
            doc_type
        ] = score

        evidence[
            doc_type
        ] = hits

    # ========================================================
    # Best candidates
    # ========================================================

    ranked = sorted(
        scores.items(),
        key=lambda item: item[1],
        reverse=True,
    )

    if not ranked:

        return (
            "unknown",
            0.0,
            [],
        )

    best_type, best_score = (
        ranked[0]
    )

    second_score = (
        ranked[1][1]
        if len(ranked) > 1
        else 0.0
    )

    best_evidence = evidence.get(
        best_type,
        [],
    )

    # ========================================================
    # Image shape is only a tiny tie-breaker
    # ========================================================

    shape_bonus = _image_shape_signal(
        image
    )

    # Only use the weak image signal when OCR evidence already
    # exists.
    if best_score > 0:

        best_score = min(
            1.0,
            best_score
            + shape_bonus,
        )

    # ========================================================
    # Confidence / ambiguity check
    # ========================================================
    #
    # If two document types have similar evidence, do not force
    # a classification.
    # ========================================================

    margin = (
        best_score
        - second_score
    )

    if best_score <= 0:

        return (
            "unknown",
            0.0,
            [],
        )

    # --------------------------------------------------------
    # Certificate
    # --------------------------------------------------------
    #
    # Certificates are particularly useful to identify because
    # they otherwise might be confused with generic ID text.
    # --------------------------------------------------------

    if best_type == "certificate":

        if (
            best_score >= 0.35
            and margin >= 0.10
        ):

            return (
                "certificate",
                round(
                    best_score,
                    3,
                ),
                best_evidence,
            )

        return (
            "unknown",
            round(
                best_score,
                3,
            ),
            best_evidence,
        )

    # --------------------------------------------------------
    # Identity documents
    # --------------------------------------------------------

    if (
        best_score >= 0.55
        and margin >= 0.12
    ):

        return (
            best_type,
            round(
                best_score,
                3,
            ),
            best_evidence,
        )

    # --------------------------------------------------------
    # Moderate evidence
    # --------------------------------------------------------
    #
    # We deliberately return unknown rather than making a weak
    # classification.
    # --------------------------------------------------------

    return (
        "unknown",
        round(
            best_score,
            3,
        ),
        best_evidence
        if best_score > 0
        else [],
    )