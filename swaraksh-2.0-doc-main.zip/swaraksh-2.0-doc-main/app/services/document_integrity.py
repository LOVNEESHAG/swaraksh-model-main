# app/services/document_integrity.py

from __future__ import annotations

from typing import Any, Optional

import cv2
import numpy as np

from .ml_forgery_detector import analyze as analyze_ml_forgery
from .universal_forensics import analyze_document


# ============================================================
# BASIC HELPERS
# ============================================================

def _safe_float(
    value: Any,
    default: float = 0.0,
) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _clip01(
    value: float,
) -> float:
    return float(
        np.clip(
            value,
            0.0,
            1.0,
        )
    )


# ============================================================
# FACE AREA
# ============================================================

def _face_area_fraction(
    image: Optional[np.ndarray],
    face_boxes: Optional[list[dict]] = None,
) -> float:

    if (
        image is None
        or not isinstance(image, np.ndarray)
        or image.size == 0
        or not face_boxes
    ):
        return 0.0

    try:
        height, width = image.shape[:2]
    except (AttributeError, ValueError):
        return 0.0

    image_area = max(
        width * height,
        1,
    )

    largest_area = 0

    for box in face_boxes:

        try:
            box_width = max(
                0,
                int(box.get("w", 0)),
            )

            box_height = max(
                0,
                int(box.get("h", 0)),
            )

            area = box_width * box_height

            largest_area = max(
                largest_area,
                area,
            )

        except (
            AttributeError,
            TypeError,
            ValueError,
        ):
            continue

    return round(
        largest_area / image_area,
        5,
    )


# ============================================================
# OCR REGION VALIDATION
# ============================================================

def _valid_ocr_regions(
    ocr_regions: Optional[list[dict]],
) -> list[dict]:

    if not ocr_regions:
        return []

    result: list[dict] = []

    for region in ocr_regions:

        if not isinstance(
            region,
            dict,
        ):
            continue

        try:
            x = int(
                region.get(
                    "x",
                    0,
                )
            )

            y = int(
                region.get(
                    "y",
                    0,
                )
            )

            w = int(
                region.get(
                    "w",
                    0,
                )
            )

            h = int(
                region.get(
                    "h",
                    0,
                )
            )

        except (
            TypeError,
            ValueError,
        ):
            continue

        if (
            w <= 0
            or h <= 0
        ):
            continue

        value = str(
            region.get(
                "value",
                "",
            )
        ).strip()

        field = str(
            region.get(
                "field",
                "unknown",
            )
        ).strip().lower()

        label = str(
            region.get(
                "label",
                field,
            )
        ).strip()

        confidence = _clip01(
            _safe_float(
                region.get(
                    "confidence",
                    0.0,
                )
            )
        )

        result.append(
            {
                "field": field,
                "label": label,
                "value": value,
                "x": x,
                "y": y,
                "w": w,
                "h": h,
                "confidence": confidence,
            }
        )

    return result


# ============================================================
# IMAGE REGION EXTRACTION
# ============================================================

def _crop_region(
    image: np.ndarray,
    region: dict,
    padding: int = 6,
) -> tuple[
    Optional[np.ndarray],
    tuple[int, int, int, int],
]:

    if (
        image is None
        or not isinstance(
            image,
            np.ndarray,
        )
        or image.size == 0
    ):
        return None, (
            0,
            0,
            0,
            0,
        )

    height, width = image.shape[:2]

    try:
        x = int(
            region["x"]
        )

        y = int(
            region["y"]
        )

        w = int(
            region["w"]
        )

        h = int(
            region["h"]
        )

    except (
        KeyError,
        TypeError,
        ValueError,
    ):
        return None, (
            0,
            0,
            0,
            0,
        )

    x1 = max(
        0,
        x - padding,
    )

    y1 = max(
        0,
        y - padding,
    )

    x2 = min(
        width,
        x + w + padding,
    )

    y2 = min(
        height,
        y + h + padding,
    )

    if (
        x2 <= x1
        or y2 <= y1
    ):
        return None, (
            0,
            0,
            0,
            0,
        )

    crop = image[
        y1:y2,
        x1:x2,
    ]

    if crop.size == 0:
        return None, (
            0,
            0,
            0,
            0,
        )

    return (
        crop,
        (
            x1,
            y1,
            x2,
            y2,
        ),
    )


# ============================================================
# IMAGE STATISTICS
# ============================================================

def _gray(
    image: np.ndarray,
) -> np.ndarray:

    if image.ndim == 2:
        return image

    return cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY,
    )


def _laplacian_variance(
    image: np.ndarray,
) -> float:

    gray = _gray(
        image
    )

    if gray.size == 0:
        return 0.0

    return float(
        cv2.Laplacian(
            gray,
            cv2.CV_64F,
        ).var()
    )


def _noise_std(
    image: np.ndarray,
) -> float:

    gray = _gray(
        image
    )

    if gray.size == 0:
        return 0.0

    blurred = cv2.GaussianBlur(
        gray,
        (3, 3),
        0,
    )

    residual = (
        gray.astype(
            np.float32
        )
        - blurred.astype(
            np.float32
        )
    )

    return float(
        np.std(
            residual
        )
    )


def _edge_density(
    image: np.ndarray,
) -> float:

    gray = _gray(
        image
    )

    if gray.size == 0:
        return 0.0

    edges = cv2.Canny(
        gray,
        50,
        150,
    )

    return float(
        np.mean(
            edges > 0
        )
    )


def _luminance(
    image: np.ndarray,
) -> float:

    gray = _gray(
        image
    )

    if gray.size == 0:
        return 0.0

    return float(
        np.mean(
            gray
        )
    )


def _contrast(
    image: np.ndarray,
) -> float:

    gray = _gray(
        image
    )

    if gray.size == 0:
        return 0.0

    return float(
        np.std(
            gray
        )
    )


# ============================================================
# LOCAL JPEG ERROR
# ============================================================

def _jpeg_error(
    image: np.ndarray,
    quality: int = 90,
) -> tuple[float, float]:

    if (
        image is None
        or image.size == 0
    ):
        return (
            0.0,
            0.0,
        )

    if image.ndim == 2:

        working = cv2.cvtColor(
            image,
            cv2.COLOR_GRAY2BGR,
        )

    else:

        working = image

    ok, encoded = cv2.imencode(
        ".jpg",
        working,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            quality,
        ],
    )

    if not ok:
        return (
            0.0,
            0.0,
        )

    reconstructed = cv2.imdecode(
        encoded,
        cv2.IMREAD_COLOR,
    )

    if reconstructed is None:
        return (
            0.0,
            0.0,
        )

    diff = cv2.absdiff(
        working,
        reconstructed,
    )

    diff_gray = (
        cv2.cvtColor(
            diff,
            cv2.COLOR_BGR2GRAY,
        )
        .astype(
            np.float32
        )
        / 255.0
    )

    if diff_gray.size == 0:
        return (
            0.0,
            0.0,
        )

    return (
        float(
            np.mean(
                diff_gray
            )
        ),
        float(
            np.percentile(
                diff_gray,
                95,
            )
        ),
    )


# ============================================================
# REGION FORENSICS
# ============================================================

def _region_forensic_score(
    image: np.ndarray,
    region: dict,
) -> dict:

    crop, bounds = _crop_region(
        image,
        region,
        padding=6,
    )

    if crop is None:
        return {
            "anomaly_score": 0.0,
            "signals": {},
        }

    x1, y1, x2, y2 = bounds

    region_gray = _gray(
        crop
    )

    context_crop, _ = _crop_region(
        image,
        {
            "x": x1,
            "y": y1,
            "w": max(
                1,
                x2 - x1,
            ),
            "h": max(
                1,
                y2 - y1,
            ),
        },
        padding=24,
    )

    if context_crop is None:
        context_crop = crop

    context_gray = _gray(
        context_crop
    )

    region_sharpness = (
        _laplacian_variance(
            region_gray
        )
    )

    context_sharpness = (
        _laplacian_variance(
            context_gray
        )
    )

    region_noise = (
        _noise_std(
            region_gray
        )
    )

    context_noise = (
        _noise_std(
            context_gray
        )
    )

    region_luminance = (
        _luminance(
            region_gray
        )
    )

    context_luminance = (
        _luminance(
            context_gray
        )
    )

    region_contrast = (
        _contrast(
            region_gray
        )
    )

    context_contrast = (
        _contrast(
            context_gray
        )
    )

    region_edges = (
        _edge_density(
            region_gray
        )
    )

    context_edges = (
        _edge_density(
            context_gray
        )
    )

    jpeg_mean, jpeg_p95 = (
        _jpeg_error(
            crop,
            quality=90,
        )
    )

    sharpness_difference = (
        abs(
            region_sharpness
            - context_sharpness
        )
        / max(
            context_sharpness,
            1.0,
        )
    )

    noise_difference = (
        abs(
            region_noise
            - context_noise
        )
        / max(
            context_noise,
            0.5,
        )
    )

    luminance_difference = (
        abs(
            region_luminance
            - context_luminance
        )
        / 255.0
    )

    contrast_difference = (
        abs(
            region_contrast
            - context_contrast
        )
        / max(
            context_contrast,
            1.0,
        )
    )

    edge_difference = abs(
        region_edges
        - context_edges
    )

    sharpness_signal = _clip01(
        sharpness_difference / 4.0
    )

    noise_signal = _clip01(
        noise_difference / 2.5
    )

    luminance_signal = _clip01(
        luminance_difference / 0.50
    )

    contrast_signal = _clip01(
        contrast_difference / 2.5
    )

    edge_signal = _clip01(
        edge_difference / 0.30
    )

    jpeg_signal = _clip01(
        (
            jpeg_mean - 0.003
        )
        / 0.020
    )

    jpeg_tail_signal = _clip01(
        (
            jpeg_p95 - 0.010
        )
        / 0.050
    )

    field_name = str(
        region.get(
            "field",
            "unknown",
        )
    ).lower()

    text_like_fields = {
        "name",
        "dob",
        "document_number",
        "issue_date",
        "validity",
        "blood_group",
        "organ_donor",
        "relation",
        "address",
        "course",
        "issuer",
        "certificate_id",
    }

    if field_name in text_like_fields:

        anomaly_score = (
            jpeg_signal * 0.35
            + jpeg_tail_signal * 0.15
            + noise_signal * 0.25
            + luminance_signal * 0.10
            + contrast_signal * 0.08
            + edge_signal * 0.05
            + sharpness_signal * 0.02
        )

    else:

        anomaly_score = (
            jpeg_signal * 0.30
            + jpeg_tail_signal * 0.15
            + noise_signal * 0.25
            + luminance_signal * 0.10
            + contrast_signal * 0.10
            + edge_signal * 0.07
            + sharpness_signal * 0.03
        )

    anomaly_score = _clip01(
        anomaly_score
    )

    return {
        "anomaly_score": round(
            anomaly_score,
            4,
        ),

        "signals": {
            "field": field_name,

            "label": str(
                region.get(
                    "label",
                    field_name,
                )
            ),

            "value": str(
                region.get(
                    "value",
                    "",
                )
            ),

            "x": x1,
            "y": y1,

            "jpeg_recompression_mean": round(
                jpeg_mean,
                5,
            ),

            "jpeg_recompression_p95": round(
                jpeg_p95,
                5,
            ),

            "sharpness_difference": round(
                sharpness_difference,
                4,
            ),

            "noise_difference": round(
                noise_difference,
                4,
            ),

            "luminance_difference": round(
                luminance_difference,
                4,
            ),

            "contrast_difference": round(
                contrast_difference,
                4,
            ),

            "edge_difference": round(
                edge_difference,
                4,
            ),
        },
    }


# ============================================================
# OCR REGION FORENSICS
# ============================================================

def _analyze_ocr_regions(
    image: Optional[np.ndarray],
    ocr_regions: Optional[list[dict]],
) -> dict:

    regions = _valid_ocr_regions(
        ocr_regions
    )

    if (
        image is None
        or not isinstance(
            image,
            np.ndarray,
        )
        or image.size == 0
        or not regions
    ):
        return {
            "analyzed_count": 0,
            "highest_anomaly_score": 0.0,
            "average_anomaly_score": 0.0,
            "regions": [],
        }

    analyzed: list[dict] = []

    for region in regions:

        forensic = _region_forensic_score(
            image,
            region,
        )

        analyzed.append(
            {
                "field": region[
                    "field"
                ],
                "label": region[
                    "label"
                ],
                "value": region[
                    "value"
                ],
                "x": region[
                    "x"
                ],
                "y": region[
                    "y"
                ],
                "w": region[
                    "w"
                ],
                "h": region[
                    "h"
                ],
                "ocr_confidence": region[
                    "confidence"
                ],
                "anomaly_score": (
                    forensic[
                        "anomaly_score"
                    ]
                ),
                "signals": (
                    forensic[
                        "signals"
                    ]
                ),
            }
        )

    if analyzed:

        highest_score = max(
            item[
                "anomaly_score"
            ]
            for item in analyzed
        )

        average_score = (
            sum(
                item[
                    "anomaly_score"
                ]
                for item in analyzed
            )
            / len(analyzed)
        )

    else:

        highest_score = 0.0
        average_score = 0.0

    return {
        "analyzed_count": len(
            analyzed
        ),
        "highest_anomaly_score": round(
            highest_score,
            4,
        ),
        "average_anomaly_score": round(
            average_score,
            4,
        ),
        "regions": analyzed,
    }


# ============================================================
# LOCALIZED TAMPERING EVIDENCE
# ============================================================

def _localized_tampering_evidence(
    ocr_region_analysis: dict,
) -> float:

    regions = (
        ocr_region_analysis.get(
            "regions",
            [],
        )
        or []
    )

    if not regions:
        return 0.0

    scores = sorted(
        (
            _clip01(
                _safe_float(
                    region.get(
                        "anomaly_score",
                        0.0,
                    )
                )
            )
            for region in regions
        ),
        reverse=True,
    )

    highest = (
        scores[0]
        if scores
        else 0.0
    )

    second = (
        scores[1]
        if len(scores) > 1
        else 0.0
    )

    third = (
        scores[2]
        if len(scores) > 2
        else 0.0
    )

    single_signal = (
        highest * 0.45
    )

    repeated_signal = (
        second * 0.25
        + third * 0.15
    )

    average_signal = (
        _clip01(
            _safe_float(
                ocr_region_analysis.get(
                    "average_anomaly_score",
                    0.0,
                )
            )
        )
        * 0.15
    )

    score = (
        single_signal
        + repeated_signal
        + average_signal
    )

    return round(
        _clip01(score),
        4,
    )


# ============================================================
# MAIN ANALYSIS
# ============================================================

def analyze(
    image: np.ndarray,
    perspective_corrected: bool,
    ocr_text: str,
    document_type: str = "unknown",
    face_boxes: Optional[list[dict]] = None,
    ocr_confidence: float = 0.0,
    ocr_regions: Optional[list[dict]] = None,
    image_quality: Optional[dict] = None,
) -> dict:

    # ========================================================
    # 1. GLOBAL FORENSICS
    # ========================================================

    result = analyze_document(
        image=image,
        ocr_confidence=ocr_confidence,
        ocr_text=ocr_text or "",
    )

    base_signals = dict(
        result.get(
            "signals",
            {},
        )
    )

    # ========================================================
    # 2. FACE AREA
    # ========================================================

    face_area_fraction = (
        _face_area_fraction(
            image,
            face_boxes,
        )
    )

    # ========================================================
    # 3. OCR REGIONS
    # ========================================================

    ocr_region_analysis = (
        _analyze_ocr_regions(
            image,
            ocr_regions,
        )
    )

    # ========================================================
    # 4. PRETRAINED ML FORGERY MODEL
    # ========================================================

    ml_forgery = analyze_ml_forgery(
        image
    )

    ml_forged_probability = _clip01(
        _safe_float(
            ml_forgery.get(
                "forged_probability",
                0.0,
            )
        )
    )

    # ========================================================
    # 5. LOCAL TAMPERING
    # ========================================================

    local_tampering = (
        _localized_tampering_evidence(
            ocr_region_analysis
        )
    )

    # ========================================================
    # 6. IMAGE QUALITY
    # ========================================================

    quality = image_quality or {}

    likely_cropped = bool(
        quality.get(
            "likely_cropped",
            False,
        )
    )

    crop_confidence = _clip01(
        _safe_float(
            quality.get(
                "crop_confidence",
                0.0,
            )
        )
    )

    sharpness_score = _clip01(
        _safe_float(
            quality.get(
                "sharpness_score",
                0.0,
            )
        )
    )

    brightness_score = _clip01(
        _safe_float(
            quality.get(
                "brightness_score",
                0.0,
            )
        )
    )

    contrast_score = _clip01(
        _safe_float(
            quality.get(
                "contrast_score",
                0.0,
            )
        )
    )

    noise_score = _clip01(
        _safe_float(
            quality.get(
                "noise_score",
                0.0,
            )
        )
    )

    # ========================================================
    # 7. GLOBAL TAMPERING
    # ========================================================

    global_tampering = _clip01(
        _safe_float(
            result.get(
                "tampering_evidence_score",
                0.0,
            )
        )
    )

    # ========================================================
    # 8. COMBINED TAMPERING
    # ========================================================

    combined_tampering = _clip01(
        global_tampering * 0.60
        + local_tampering * 0.20
        + ml_forged_probability * 0.20
    )

    # ========================================================
    # 9. QUALITY PENALTY
    # ========================================================

    quality_penalty = 0.0

    if likely_cropped:

        quality_penalty += (
            0.10
            * crop_confidence
        )

    if sharpness_score < 0.35:
        quality_penalty += 0.08

    if brightness_score < 0.35:
        quality_penalty += 0.05

    if contrast_score < 0.35:
        quality_penalty += 0.05

    if noise_score < 0.30:
        quality_penalty += 0.05

    quality_penalty = _clip01(
        quality_penalty
    )

    # ========================================================
    # 10. IMAGE QUALITY
    # ========================================================

    quality_score = (
        sharpness_score * 0.30
        + brightness_score * 0.15
        + contrast_score * 0.20
        + noise_score * 0.15
        + max(
            0.0,
            1.0 - quality_penalty,
        ) * 0.20
    )

    quality_score = _clip01(
        quality_score
    )

    # ========================================================
    # 11. WARNINGS
    # ========================================================

    warnings = list(
        result.get(
            "signals",
            {},
        ).get(
            "warnings",
            [],
        )
        or []
    )

    if likely_cropped:

        warnings.append(
            "Image may be cropped; authenticity "
            "verification confidence is reduced."
        )

    if sharpness_score < 0.35:

        warnings.append(
            "Image sharpness is low."
        )

    if ocr_confidence < 0.45:

        warnings.append(
            "OCR confidence is low; content validation "
            "is limited."
        )

    if not ml_forgery.get(
        "available",
        False,
    ):

        warnings.append(
            "Pretrained forgery model was unavailable; "
            "ML forgery evidence was not used."
        )

    warnings = list(
        dict.fromkeys(
            warnings
        )
    )

    # ========================================================
    # 12. SIGNALS
    # ========================================================

    base_signals.update(
        {
            "perspective_corrected": bool(
                perspective_corrected
            ),

            "face_area_fraction": (
                face_area_fraction
            ),

            "document_type_influence": 0.0,

            "ml_forgery_available": bool(
                ml_forgery.get(
                    "available",
                    False,
                )
            ),

            "ml_forged_probability": round(
                ml_forged_probability,
                4,
            ),

            "ml_real_probability": round(
                _safe_float(
                    ml_forgery.get(
                        "real_probability",
                        0.0,
                    )
                ),
                4,
            ),

            "sharpness_score": round(
                sharpness_score,
                4,
            ),

            "brightness_score": round(
                brightness_score,
                4,
            ),

            "contrast_score": round(
                contrast_score,
                4,
            ),

            "noise_score": round(
                noise_score,
                4,
            ),

            "likely_cropped": (
                likely_cropped
            ),

            "crop_confidence": round(
                crop_confidence,
                4,
            ),

            "ocr_region_count": (
                ocr_region_analysis[
                    "analyzed_count"
                ]
            ),

            "highest_ocr_region_anomaly": (
                ocr_region_analysis[
                    "highest_anomaly_score"
                ]
            ),

            "average_ocr_region_anomaly": (
                ocr_region_analysis[
                    "average_anomaly_score"
                ]
            ),
        }
    )

    # ========================================================
    # 13. RETURN
    # ========================================================

    return {
        "score": round(
            quality_score,
            4,
        ),

        "quality_score": round(
            quality_score,
            4,
        ),

        "tampering_probability": round(
            combined_tampering,
            4,
        ),

        "tampering_evidence_score": round(
            combined_tampering,
            4,
        ),

        "global_tampering_evidence": round(
            global_tampering,
            4,
        ),

        "local_tampering_evidence": round(
            local_tampering,
            4,
        ),

        "ml_forgery": ml_forgery,

        "signals": base_signals,

        "ocr_region_analysis": (
            ocr_region_analysis
        ),

        "quality_penalty": round(
            quality_penalty,
            4,
        ),

        "warnings": warnings,

        "note": (
            "Universal image-forensics analysis is "
            "document-type independent. Global image "
            "forensics, localized OCR-region analysis, "
            "and an independent pretrained ML forgery "
            "classifier are combined as evidence. "
            "These signals do not prove that a document "
            "is genuine or forged."
        ),
    }