# app/services/face_tampering.py

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np


# ============================================================
# RESULT
# ============================================================

@dataclass
class TamperResult:
    """
    Result of face-region forensic analysis.

    probability:
        Heuristic manipulation-evidence score in [0, 1].

    signals:
        Raw/derived forensic measurements.

    note:
        Important interpretation/limitations.
    """

    probability: float
    signals: dict
    note: str


# ============================================================
# HELPERS
# ============================================================

def _clip01(value: float) -> float:
    """
    Clamp a numeric value to [0, 1].
    """
    return float(
        np.clip(
            value,
            0.0,
            1.0,
        )
    )


def _gray(img: np.ndarray) -> np.ndarray:
    """
    Convert an image to grayscale safely.
    """
    if img is None:
        raise ValueError("Image cannot be None.")

    if not isinstance(img, np.ndarray):
        raise TypeError("Image must be a NumPy array.")

    if img.size == 0:
        raise ValueError("Image cannot be empty.")

    if img.ndim == 2:
        return img.copy()

    if img.ndim == 3 and img.shape[2] == 3:
        return cv2.cvtColor(
            img,
            cv2.COLOR_BGR2GRAY,
        )

    if img.ndim == 3 and img.shape[2] == 4:
        return cv2.cvtColor(
            img,
            cv2.COLOR_BGRA2GRAY,
        )

    raise ValueError(
        f"Unsupported image shape: {img.shape}"
    )


# ============================================================
# SHARPNESS
# ============================================================

def _laplacian_variance(
    img: np.ndarray,
) -> float:
    """
    Measure local sharpness using Laplacian variance.

    This is NOT an authenticity score.
    """

    gray = _gray(img)

    if gray.size == 0:
        return 0.0

    return float(
        cv2.Laplacian(
            gray,
            cv2.CV_64F,
        ).var()
    )


# ============================================================
# NOISE RESIDUAL
# ============================================================

def _noise_residual(
    img: np.ndarray,
) -> np.ndarray:
    """
    Estimate high-frequency noise residual.
    """

    gray = _gray(img)

    blur = cv2.GaussianBlur(
        gray,
        (0, 0),
        sigmaX=1.2,
    )

    residual = cv2.absdiff(
        gray,
        blur,
    )

    return residual


def _noise_mean(
    img: np.ndarray,
) -> float:
    """
    Mean normalized high-frequency residual.
    """

    residual = _noise_residual(
        img
    )

    if residual.size == 0:
        return 0.0

    return float(
        np.mean(residual)
    ) / 255.0


# ============================================================
# JPEG RECOMPRESSION / ELA
# ============================================================

def _recompression_error(
    img: np.ndarray,
    quality: int = 90,
) -> tuple[float, Optional[np.ndarray]]:
    """
    Recompress image as JPEG and measure pixel difference.

    This is similar to a simple ELA-style signal.

    IMPORTANT:
        It is only forensic evidence.
        It is not proof of editing.
    """

    if img is None or img.size == 0:
        return 0.0, None

    # Ensure we always have a 3-channel BGR image.
    if img.ndim == 2:
        working = cv2.cvtColor(
            img,
            cv2.COLOR_GRAY2BGR,
        )
    else:
        working = img

    ok, encoded = cv2.imencode(
        ".jpg",
        working,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            int(quality),
        ],
    )

    if not ok:
        return 0.0, None

    recompressed = cv2.imdecode(
        encoded,
        cv2.IMREAD_COLOR,
    )

    if recompressed is None:
        return 0.0, None

    diff = cv2.absdiff(
        working,
        recompressed,
    )

    mean_error = float(
        np.mean(diff)
    ) / 255.0

    return (
        mean_error,
        diff,
    )


def _local_error_score(
    face_crop: np.ndarray,
) -> tuple[float, float, float]:
    """
    Return:

        mean JPEG error
        p90 JPEG error
        hotspot ratio

    Hotspots identify unusually high local recompression error.
    """

    mean_error, diff = (
        _recompression_error(
            face_crop,
            quality=90,
        )
    )

    if diff is None or diff.size == 0:
        return (
            mean_error,
            mean_error,
            0.0,
        )

    gray_diff = (
        _gray(diff)
        .astype(
            np.float32
        )
        / 255.0
    )

    if gray_diff.size == 0:
        return (
            mean_error,
            mean_error,
            0.0,
        )

    p90 = float(
        np.percentile(
            gray_diff,
            90,
        )
    )

    p95 = float(
        np.percentile(
            gray_diff,
            95,
        )
    )

    # Conservative hotspot threshold.
    threshold = max(
        p95,
        0.08,
    )

    hotspot_ratio = float(
        np.mean(
            gray_diff >= threshold
        )
    )

    return (
        mean_error,
        p90,
        hotspot_ratio,
    )


# ============================================================
# BORDER / CORE STATISTICS
# ============================================================

def _ring_and_core_stats(
    face_crop: np.ndarray,
) -> dict:
    """
    Compare the center of the detected face with a surrounding
    ring.

    The goal is to find unusual transitions in:
        - noise
        - sharpness

    This is a heuristic signal.
    """

    gray = (
        _gray(face_crop)
        .astype(
            np.float32
        )
    )

    h, w = gray.shape[:2]

    if h < 24 or w < 24:
        return {
            "ring_core_noise_ratio": 1.0,
            "ring_core_sharpness_ratio": 1.0,
            "boundary_noise_difference": 0.0,
            "boundary_sharpness_difference": 0.0,
        }

    pad_y = max(
        3,
        int(
            h * 0.15
        ),
    )

    pad_x = max(
        3,
        int(
            w * 0.15
        ),
    )

    # Protect against over-large padding.
    if (
        2 * pad_y >= h
        or 2 * pad_x >= w
    ):
        return {
            "ring_core_noise_ratio": 1.0,
            "ring_core_sharpness_ratio": 1.0,
            "boundary_noise_difference": 0.0,
            "boundary_sharpness_difference": 0.0,
        }

    core = gray[
        pad_y:h - pad_y,
        pad_x:w - pad_x,
    ]

    # Ring around the core.
    ring_mask = np.ones(
        gray.shape,
        dtype=np.uint8,
    )

    ring_mask[
        pad_y:h - pad_y,
        pad_x:w - pad_x,
    ] = 0

    # Noise residual.
    blur = cv2.GaussianBlur(
        gray,
        (0, 0),
        sigmaX=1.2,
    )

    residual = cv2.absdiff(
        gray.astype(
            np.uint8
        ),
        blur.astype(
            np.uint8
        ),
    ).astype(
        np.float32
    )

    ring_pixels = (
        ring_mask > 0
    )

    core_pixels = (
        ring_mask == 0
    )

    if not np.any(ring_pixels):
        return {
            "ring_core_noise_ratio": 1.0,
            "ring_core_sharpness_ratio": 1.0,
            "boundary_noise_difference": 0.0,
            "boundary_sharpness_difference": 0.0,
        }

    ring_noise = (
        float(
            np.mean(
                residual[
                    ring_pixels
                ]
            )
        )
        + 1e-6
    )

    core_noise = (
        float(
            np.mean(
                residual[
                    core_pixels
                ]
            )
        )
        + 1e-6
    )

    # Sharpness of ring.
    ring_image = np.where(
        ring_mask > 0,
        gray,
        np.mean(gray),
    ).astype(
        np.float64
    )

    ring_sharpness = (
        float(
            cv2.Laplacian(
                ring_image,
                cv2.CV_64F,
            ).var()
        )
        + 1e-6
    )

    core_sharpness = (
        float(
            cv2.Laplacian(
                core.astype(
                    np.float64
                ),
                cv2.CV_64F,
            ).var()
        )
        + 1e-6
    )

    return {
        "ring_core_noise_ratio": (
            ring_noise
            / core_noise
        ),

        "ring_core_sharpness_ratio": (
            ring_sharpness
            / core_sharpness
        ),

        "boundary_noise_difference": abs(
            ring_noise
            - core_noise
        )
        / max(
            ring_noise,
            core_noise,
            1e-6,
        ),

        "boundary_sharpness_difference": abs(
            ring_sharpness
            - core_sharpness
        )
        / max(
            ring_sharpness,
            core_sharpness,
            1e-6,
        ),
    }


# ============================================================
# COLOR CONSISTENCY
# ============================================================

def _color_consistency_score(
    face_crop: np.ndarray,
    document_image: np.ndarray,
) -> tuple[float, float]:
    """
    Compare normalized color statistics between face and document.

    This signal is deliberately weak because face illumination,
    skin tone, and document design can naturally differ.

    Returns:
        mean difference
        anomaly score
    """

    if (
        face_crop is None
        or document_image is None
        or face_crop.size == 0
        or document_image.size == 0
    ):
        return 0.0, 0.0

    try:

        face_bgr = (
            face_crop
            if face_crop.ndim == 3
            else cv2.cvtColor(
                face_crop,
                cv2.COLOR_GRAY2BGR,
            )
        )

        doc_bgr = (
            document_image
            if document_image.ndim == 3
            else cv2.cvtColor(
                document_image,
                cv2.COLOR_GRAY2BGR,
            )
        )

        face_lab = cv2.cvtColor(
            face_bgr,
            cv2.COLOR_BGR2LAB,
        )

        doc_lab = cv2.cvtColor(
            doc_bgr,
            cv2.COLOR_BGR2LAB,
        )

        face_mean = np.mean(
            face_lab.reshape(
                -1,
                3,
            ),
            axis=0,
        )

        doc_mean = np.mean(
            doc_lab.reshape(
                -1,
                3,
            ),
            axis=0,
        )

        diff = float(
            np.mean(
                np.abs(
                    face_mean
                    - doc_mean
                )
            )
        ) / 255.0

        # Keep this contribution weak.
        anomaly = _clip01(
            diff / 0.35
        )

        return (
            diff,
            anomaly,
        )

    except Exception:
        return 0.0, 0.0


# ============================================================
# MULTI-SCALE FACE ANALYSIS
# ============================================================

def _resize_face(
    face_crop: np.ndarray,
    minimum_size: int = 256,
) -> np.ndarray:
    """
    Upscale small faces for more stable statistical analysis.
    """

    if face_crop is None:
        return face_crop

    h, w = face_crop.shape[:2]

    if h <= 0 or w <= 0:
        return face_crop

    scale = max(
        1.0,
        minimum_size / max(
            min(
                h,
                w,
            ),
            1,
        ),
    )

    if scale == 1.0:
        return face_crop.copy()

    return cv2.resize(
        face_crop,
        None,
        fx=scale,
        fy=scale,
        interpolation=cv2.INTER_CUBIC,
    )


# ============================================================
# MAIN ANALYSIS
# ============================================================

def analyze(
    face_crop: Optional[np.ndarray],
    document_image: Optional[np.ndarray],
) -> TamperResult:
    """
    Analyze an embedded face region for manipulation evidence.

    IMPORTANT:

    This function:
        - does NOT depend on document type
        - does NOT identify the person
        - does NOT claim authenticity
        - does NOT claim a face is fake based on one signal

    It combines several weak forensic indicators.
    """

    # --------------------------------------------------------
    # No face available
    # --------------------------------------------------------

    if (
        face_crop is None
        or not isinstance(
            face_crop,
            np.ndarray,
        )
        or face_crop.size == 0
    ):
        return TamperResult(
            probability=0.0,

            signals={
                "available": False,
                "heuristic_only": True,
            },

            note=(
                "No face region was available. "
                "Face-manipulation analysis was not performed."
            ),
        )

    # --------------------------------------------------------
    # Document image validation
    # --------------------------------------------------------

    if (
        document_image is None
        or not isinstance(
            document_image,
            np.ndarray,
        )
        or document_image.size == 0
    ):
        return TamperResult(
            probability=0.0,

            signals={
                "available": True,
                "document_reference_available": False,
                "heuristic_only": True,
            },

            note=(
                "A face region was detected, but a valid document "
                "reference image was not available for comparison."
            ),
        )

    # --------------------------------------------------------
    # Normalize small face crops
    # --------------------------------------------------------

    analysis_face = _resize_face(
        face_crop,
        minimum_size=256,
    )

    # --------------------------------------------------------
    # Sharpness
    # --------------------------------------------------------

    face_variance = (
        _laplacian_variance(
            analysis_face
        )
    )

    document_variance = (
        _laplacian_variance(
            document_image
        )
    )

    sharpness_ratio = (
        face_variance
        / max(
            document_variance,
            1e-6,
        )
    )

    # --------------------------------------------------------
    # Noise
    # --------------------------------------------------------

    noise_mean = _noise_mean(
        analysis_face
    )

    # --------------------------------------------------------
    # JPEG recompression
    # --------------------------------------------------------

    (
        ela_mean,
        ela_p90,
        ela_hotspots,
    ) = _local_error_score(
        analysis_face
    )

    # --------------------------------------------------------
    # Ring/core analysis
    # --------------------------------------------------------

    local = _ring_and_core_stats(
        analysis_face
    )

    # --------------------------------------------------------
    # Color consistency
    # --------------------------------------------------------

    (
        color_difference,
        color_signal,
    ) = _color_consistency_score(
        analysis_face,
        document_image,
    )

    # ========================================================
    # SIGNAL TRANSFORMATION
    # ========================================================

    # --------------------------------------------------------
    # ELA / recompression signal
    # --------------------------------------------------------

    ela_signal = _clip01(
        (
            ela_mean
            - 0.006
        )
        / 0.024
    )

    # --------------------------------------------------------
    # JPEG hotspot signal
    # --------------------------------------------------------

    hotspot_signal = _clip01(
        (
            ela_hotspots
            - 0.08
        )
        / 0.30
    )

    # --------------------------------------------------------
    # Noise signal
    # --------------------------------------------------------

    noise_signal = _clip01(
        (
            noise_mean
            - 0.010
        )
        / 0.055
    )

    # --------------------------------------------------------
    # Ring/core noise signal
    # --------------------------------------------------------

    noise_ratio = max(
        local[
            "ring_core_noise_ratio"
        ],
        1e-6,
    )

    noise_ratio_signal = _clip01(
        abs(
            np.log(
                noise_ratio
            )
        )
        / 1.8
    )

    # --------------------------------------------------------
    # Ring/core sharpness signal
    # --------------------------------------------------------

    sharpness_core_ratio = max(
        local[
            "ring_core_sharpness_ratio"
        ],
        1e-6,
    )

    boundary_sharpness_signal = _clip01(
        abs(
            np.log(
                sharpness_core_ratio
            )
        )
        / 2.2
    )

    # --------------------------------------------------------
    # Face/document sharpness signal
    # --------------------------------------------------------

    face_document_sharpness_signal = _clip01(
        abs(
            np.log(
                max(
                    sharpness_ratio,
                    1e-6,
                )
            )
        )
        / 2.2
    )

    # --------------------------------------------------------
    # Boundary noise signal
    # --------------------------------------------------------

    boundary_noise_signal = _clip01(
        local[
            "boundary_noise_difference"
        ]
        / 0.70
    )

    # --------------------------------------------------------
    # Color signal
    # --------------------------------------------------------

    color_signal = _clip01(
        color_signal
    )

    # ========================================================
    # FINAL HEURISTIC SCORE
    # ========================================================
    #
    # No individual signal dominates.
    #
    # These weights are engineering heuristics and should later
    # be calibrated against labeled genuine/manipulated samples.
    # ========================================================

    score = (
        ela_signal * 0.24
        + hotspot_signal * 0.14
        + noise_signal * 0.14
        + noise_ratio_signal * 0.12
        + boundary_noise_signal * 0.10
        + boundary_sharpness_signal * 0.10
        + face_document_sharpness_signal * 0.10
        + color_signal * 0.06
    )

    probability = _clip01(
        score
    )

    # --------------------------------------------------------
    # Confidence/quality notes
    # --------------------------------------------------------

    face_h, face_w = (
        analysis_face.shape[:2]
    )

    warnings: list[str] = []

    if min(
        face_h,
        face_w,
    ) < 80:

        warnings.append(
            "Detected face region is very small; "
            "forensic confidence is limited."
        )

    if document_variance < 20:

        warnings.append(
            "Reference document image is very smooth/blurred; "
            "sharpness comparison is limited."
        )

    if ela_mean < 0.003:

        warnings.append(
            "JPEG recompression signal is weak."
        )

    # --------------------------------------------------------
    # Return
    # --------------------------------------------------------

    return TamperResult(
        probability=round(
            probability,
            4,
        ),

        signals={
            "available": True,

            "jpeg_recompression_error_mean": round(
                ela_mean,
                5,
            ),

            "jpeg_recompression_error_p90": round(
                ela_p90,
                5,
            ),

            "jpeg_error_hotspot_ratio": round(
                ela_hotspots,
                5,
            ),

            "noise_residual_mean": round(
                noise_mean,
                5,
            ),

            "ring_core_noise_ratio": round(
                local[
                    "ring_core_noise_ratio"
                ],
                4,
            ),

            "ring_core_sharpness_ratio": round(
                local[
                    "ring_core_sharpness_ratio"
                ],
                4,
            ),

            "boundary_noise_difference": round(
                local[
                    "boundary_noise_difference"
                ],
                4,
            ),

            "boundary_sharpness_difference": round(
                local[
                    "boundary_sharpness_difference"
                ],
                4,
            ),

            "face_sharpness_variance": round(
                face_variance,
                3,
            ),

            "document_sharpness_variance": round(
                document_variance,
                3,
            ),

            "face_document_sharpness_ratio": round(
                sharpness_ratio,
                4,
            ),

            "color_mean_difference": round(
                color_difference,
                5,
            ),

            "heuristic_only": True,

            "warnings": warnings,
        },

        note=(
            "Face manipulation is estimated from multiple local "
            "image-forensics signals including recompression error, "
            "noise consistency, boundary/core differences, sharpness "
            "differences, and weak color statistics. These signals "
            "are heuristic evidence only. A low score means that this "
            "heuristic did not find strong manipulation evidence; it "
            "does not prove that the face or document is genuine. "
            "A validated face-forgery/forensic model should supplement "
            "or replace these heuristics before production use."
        ),
    )