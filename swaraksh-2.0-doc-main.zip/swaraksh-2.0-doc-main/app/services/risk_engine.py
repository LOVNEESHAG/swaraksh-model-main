# app/services/risk_engine.py

from __future__ import annotations

from typing import Any


# ============================================================
# HELPERS
# ============================================================

def clamp(
    value: Any,
) -> float:
    """
    Clamp a value to the range [0, 1].

    Invalid or missing values become 0.0.
    """

    try:
        value = float(value)

    except (
        TypeError,
        ValueError,
    ):
        return 0.0

    return max(
        0.0,
        min(
            1.0,
            value,
        ),
    )


def _bool(
    value: Any,
) -> bool:
    """
    Safely convert a value to boolean.
    """

    return bool(value)


def _add_reason(
    reasons: list[str],
    reason: str,
) -> None:
    """
    Add a reason without duplicating it.
    """

    if reason not in reasons:
        reasons.append(
            reason
        )


# ============================================================
# RISK ENGINE
# ============================================================

def calculate(
    ocr_confidence: float,
    validation: dict,
    face_analysis: dict,
    integrity: dict,
    cross: dict,
    document_type: str = "unknown",
) -> dict:
    """
    UNIVERSAL EVIDENCE / RISK ENGINE.

    The engine combines:

        OCR quality
        Image quality
        Global image forensics
        Local OCR-region forensics
        Pretrained ML forgery evidence
        Face analysis
        Content validation
        Optional reference-data comparison

    IMPORTANT:

        Document type is informational only.

        Document-format matching is NOT an authenticity gate.

        No single signal automatically determines that a
        document is fake.

    risk_score:
        Amount of suspicious/negative evidence.

    verification_confidence:
        Amount of usable evidence available to support
        a reliable decision.
    """

    validation = validation or {}
    face_analysis = face_analysis or {}
    integrity = integrity or {}
    cross = cross or {}

    reasons: list[str] = []

    # ========================================================
    # 1. OCR
    # ========================================================

    ocr_conf = clamp(
        ocr_confidence
    )

    ocr_risk = (
        1.0
        - ocr_conf
    )

    # ========================================================
    # 2. IMAGE QUALITY
    # ========================================================

    image_quality = clamp(
        integrity.get(
            "quality_score",
            integrity.get(
                "score",
                0.0,
            ),
        )
    )

    image_quality_risk = (
        1.0
        - image_quality
    )

    # ========================================================
    # 3. TAMPERING EVIDENCE
    # ========================================================

    tamper_evidence = clamp(
        integrity.get(
            "tampering_evidence_score",
            integrity.get(
                "tampering_probability",
                0.0,
            ),
        )
    )

    # --------------------------------------------------------
    # Individual forensic components
    # --------------------------------------------------------

    global_tampering = clamp(
        integrity.get(
            "global_tampering_evidence",
            0.0,
        )
    )

    local_tampering = clamp(
        integrity.get(
            "local_tampering_evidence",
            0.0,
        )
    )

    # --------------------------------------------------------
    # Pretrained ML evidence
    # --------------------------------------------------------

    ml_forgery = integrity.get(
        "ml_forgery",
        {},
    )

    if not isinstance(
        ml_forgery,
        dict,
    ):
        ml_forgery = {}

    ml_available = _bool(
        ml_forgery.get(
            "available",
            False,
        )
    )

    ml_forged_probability = clamp(
        ml_forgery.get(
            "forged_probability",
            0.0,
        )
    )

    ml_real_probability = clamp(
        ml_forgery.get(
            "real_probability",
            0.0,
        )
    )

    # --------------------------------------------------------
    # IMPORTANT
    #
    # document_integrity.py has already combined:
    #
    #     global
    #     local
    #     ML
    #
    # therefore risk_engine MUST prefer that combined result.
    # --------------------------------------------------------

    if "tampering_evidence_score" in integrity:

        combined_tampering = tamper_evidence

    else:

        # Compatibility fallback for older integrity output.
        combined_tampering = clamp(
            global_tampering * 0.60
            + local_tampering * 0.20
            + ml_forged_probability * 0.20
        )

    # ========================================================
    # 4. FACE ANALYSIS
    # ========================================================

    face_present = _bool(
        face_analysis.get(
            "face_detected",
            False,
        )
    )

    if face_present:

        face_risk = clamp(
            face_analysis.get(
                "manipulation_probability",
                0.0,
            )
        )

    else:

        # Absence of a face is not fraud.
        face_risk = 0.0

    # ========================================================
    # 5. FIELD / CONTENT VALIDATION
    # ========================================================

    field_risk = 0.0

    content_quality = clamp(
        validation.get(
            "content_quality",
            0.0,
        )
    )

    validation_status = str(
        validation.get(
            "validation_status",
            "",
        )
        or ""
    ).upper()

    fields_present = validation.get(
        "required_fields_present"
    )

    fields_consistent = validation.get(
        "fields_consistent"
    )

    date_valid = validation.get(
        "date_valid"
    )

    # --------------------------------------------------------
    # Content quality
    # --------------------------------------------------------

    if content_quality > 0.0:

        content_risk = (
            1.0
            - content_quality
        )

        field_risk += (
            content_risk
            * 0.35
        )

    # --------------------------------------------------------
    # Missing content
    # --------------------------------------------------------

    if fields_present is False:

        field_risk = max(
            field_risk,
            0.30,
        )

        _add_reason(
            reasons,
            "Extracted content is insufficient for strong verification.",
        )

    # --------------------------------------------------------
    # Inconsistent content
    # --------------------------------------------------------

    if fields_consistent is False:

        field_risk = max(
            field_risk,
            0.25,
        )

        _add_reason(
            reasons,
            "Extracted content contains inconsistencies.",
        )

    # --------------------------------------------------------
    # Invalid date
    # --------------------------------------------------------

    if date_valid is False:

        field_risk = max(
            field_risk,
            0.25,
        )

        _add_reason(
            reasons,
            "An extracted date failed basic validity checks.",
        )

    # --------------------------------------------------------
    # Validation status
    # --------------------------------------------------------

    if validation_status in {
        "INCONSISTENT",
        "INSUFFICIENT",
    }:

        field_risk = max(
            field_risk,
            0.25,
        )

    field_risk = clamp(
        field_risk
    )

    # ========================================================
    # 6. CROSS VALIDATION
    # ========================================================

    cross_attempted = _bool(
        cross.get(
            "attempted",
            False,
        )
    )

    if cross_attempted:

        match_score = clamp(
            cross.get(
                "match_score",
                0.0,
            )
        )

        cross_risk = (
            1.0
            - match_score
        )

        if match_score < 0.50:

            _add_reason(
                reasons,
                "Supplied reference data does not sufficiently match the extracted content.",
            )

        elif match_score < 0.80:

            _add_reason(
                reasons,
                "Reference-data match is incomplete.",
            )

    else:

        # No reference data means no cross-validation penalty.
        cross_risk = 0.0

    cross_risk = clamp(
        cross_risk
    )

    # ========================================================
    # 7. IMAGE QUALITY / CROPPING
    # ========================================================

    signals = integrity.get(
        "signals",
        {},
    )

    if not isinstance(
        signals,
        dict,
    ):
        signals = {}

    likely_cropped = _bool(
        signals.get(
            "likely_cropped",
            integrity.get(
                "likely_cropped",
                False,
            ),
        )
    )

    crop_confidence = clamp(
        signals.get(
            "crop_confidence",
            integrity.get(
                "crop_confidence",
                0.0,
            ),
        )
    )

    image_quality_block = False

    if likely_cropped:

        image_quality_block = True

        _add_reason(
            reasons,
            "The uploaded image may be cropped or incomplete.",
        )

    if ocr_conf < 0.45:

        image_quality_block = True

        _add_reason(
            reasons,
            "OCR confidence is too low for a strong content-verification conclusion.",
        )

    if image_quality < 0.45:

        image_quality_block = True

        _add_reason(
            reasons,
            "Overall image quality is too low for a strong verification conclusion.",
        )

    # ========================================================
    # 8. TAMPERING REASONS
    # ========================================================

    if combined_tampering >= 0.75:

        _add_reason(
            reasons,
            "Strong global/local/model image-manipulation evidence was detected.",
        )

    elif combined_tampering >= 0.45:

        _add_reason(
            reasons,
            "Possible image-manipulation evidence was detected.",
        )

    # --------------------------------------------------------
    # ML-specific reason
    # --------------------------------------------------------

    if (
        ml_available
        and ml_forged_probability >= 0.80
    ):

        _add_reason(
            reasons,
            "The pretrained document-forgery model produced strong forgery evidence.",
        )

    elif (
        ml_available
        and ml_forged_probability >= 0.60
    ):

        _add_reason(
            reasons,
            "The pretrained document-forgery model produced moderate forgery evidence.",
        )

    # --------------------------------------------------------
    # Local OCR region
    # --------------------------------------------------------

    ocr_region_analysis = integrity.get(
        "ocr_region_analysis",
        {},
    )

    if not isinstance(
        ocr_region_analysis,
        dict,
    ):
        ocr_region_analysis = {}

    highest_region_anomaly = clamp(
        ocr_region_analysis.get(
            "highest_anomaly_score",
            0.0,
        )
    )

    if highest_region_anomaly >= 0.75:

        _add_reason(
            reasons,
            "A localized OCR field produced strong image-anomaly evidence.",
        )

    elif highest_region_anomaly >= 0.55:

        _add_reason(
            reasons,
            "A localized OCR field produced moderate image-anomaly evidence.",
        )

    # --------------------------------------------------------
    # Face
    # --------------------------------------------------------

    if (
        face_present
        and face_risk >= 0.80
    ):

        _add_reason(
            reasons,
            "The embedded face region produced a high manipulation heuristic score.",
        )

    elif (
        face_present
        and face_risk >= 0.50
    ):

        _add_reason(
            reasons,
            "The embedded face region produced a moderate manipulation heuristic score.",
        )

    # ========================================================
    # 9. WEIGHTED RISK SCORE
    # ========================================================
    #
    # Prototype engineering weights.
    #
    # These must eventually be calibrated against a labeled
    # validation dataset containing:
    #
    #   genuine images
    #   compressed images
    #   photographed images
    #   cropped images
    #   edited images
    #   AI-edited images
    #
    # Document type contributes ZERO.
    # ========================================================

    risk = (
        0.15 * ocr_risk
        + 0.15 * image_quality_risk
        + 0.35 * combined_tampering
        + 0.15 * face_risk
        + 0.15 * field_risk
        + 0.05 * cross_risk
    )

    risk = clamp(
        risk
    )

    # ========================================================
    # 10. VERIFICATION CONFIDENCE
    # ========================================================

    evidence_components = [
        ocr_conf,
        image_quality,
        content_quality,
    ]

    if fields_present is not None:

        evidence_components.append(
            1.0
            if fields_present
            else 0.0
        )

    if fields_consistent is not None:

        evidence_components.append(
            1.0
            if fields_consistent
            else 0.0
        )

    # --------------------------------------------------------
    # ML model availability contributes to evidence availability
    # but absence of ML does NOT make the document suspicious.
    # --------------------------------------------------------

    if ml_available:

        evidence_components.append(
            max(
                ml_real_probability,
                ml_forged_probability,
            )
        )

    evidence_confidence = (
        sum(
            evidence_components
        )
        / max(
            len(
                evidence_components
            ),
            1,
        )
    )

    # Cropping reduces confidence.
    if likely_cropped:

        evidence_confidence *= (
            1.0
            - 0.25 * crop_confidence
        )

    # Strong manipulation evidence reduces confidence that the
    # document can receive a genuine PASS.
    evidence_confidence *= (
        1.0
        - 0.50 * combined_tampering
    )

    verification_confidence = clamp(
        evidence_confidence
    )

    # ========================================================
    # 11. VERIFICATION BLOCKS
    # ========================================================

    verification_blocked: list[str] = []

    # --------------------------------------------------------
    # Low OCR
    # --------------------------------------------------------

    if ocr_conf < 0.45:

        verification_blocked.append(
            "Low OCR confidence"
        )

    # --------------------------------------------------------
    # Low image quality
    # --------------------------------------------------------

    if image_quality < 0.45:

        verification_blocked.append(
            "Low image quality"
        )

    # --------------------------------------------------------
    # Potentially cropped
    # --------------------------------------------------------

    if likely_cropped:

        verification_blocked.append(
            "Potentially cropped/incomplete image"
        )

    # --------------------------------------------------------
    # Insufficient extracted content
    # --------------------------------------------------------

    if fields_present is False:

        verification_blocked.append(
            "Insufficient extracted content"
        )

    # --------------------------------------------------------
    # Inconsistent extracted content
    #
    # IMPORTANT:
    #
    # Bad extraction must not silently become PASS.
    # --------------------------------------------------------

    if fields_consistent is False:

        verification_blocked.append(
            "Inconsistent extracted content"
        )

    # --------------------------------------------------------
    # Invalid dates
    # --------------------------------------------------------

    if date_valid is False:

        verification_blocked.append(
            "Invalid extracted date"
        )

    # --------------------------------------------------------
    # Low confidence
    # --------------------------------------------------------

    if verification_confidence < 0.55:

        verification_blocked.append(
            "Low verification confidence"
        )

    verification_blocked = list(
        dict.fromkeys(
            verification_blocked
        )
    )

    # ========================================================
    # 12. FINAL DECISION
    # ========================================================

    # --------------------------------------------------------
    # FAIL
    # --------------------------------------------------------

    if (
        combined_tampering >= 0.80
        or face_risk >= 0.85
        or (
            ml_available
            and ml_forged_probability >= 0.95
        )
        or (
            cross_attempted
            and cross_risk >= 0.85
        )
    ):

        level = "HIGH"
        decision = "FAIL"

    # --------------------------------------------------------
    # REVIEW
    # --------------------------------------------------------

    elif (
        verification_blocked
        or risk >= 0.30
        or combined_tampering >= 0.45
    ):

        level = "MEDIUM"
        decision = "REVIEW"

    # --------------------------------------------------------
    # PASS
    # --------------------------------------------------------

    else:

        level = "LOW"
        decision = "PASS"

    # ========================================================
    # 13. FINAL PASS SAFETY GATE
    # ========================================================

    if (
        decision == "PASS"
        and verification_confidence < 0.65
    ):

        level = "MEDIUM"
        decision = "REVIEW"

        _add_reason(
            reasons,
            "Verification confidence is insufficient for a PASS decision.",
        )

    # ========================================================
    # 14. ML AVAILABILITY SAFETY INFORMATION
    # ========================================================

    if not ml_available:

        _add_reason(
            reasons,
            "Pretrained forgery model was unavailable; this verification used the remaining evidence sources.",
        )

    # ========================================================
    # 15. UNIVERSAL DOCUMENT-TYPE POLICY
    # ========================================================

    document_type_influence = 0.0

    # Explicitly do not add document_type to risk.
    _ = document_type

    # ========================================================
    # 16. FINAL REASONS
    # ========================================================

    if verification_blocked:

        _add_reason(
            reasons,
            "Verification evidence is insufficient for an automatic PASS decision.",
        )

    if not reasons:

        reasons.append(
            "No strong manipulation or content inconsistency was detected by the available evidence."
        )

    # ========================================================
    # 17. RETURN
    # ========================================================

    return {
        "risk_score": round(
            risk,
            4,
        ),

        "risk_level": level,

        "decision": decision,

        "verification_confidence": round(
            verification_confidence,
            4,
        ),

        "verification_blocked": (
            len(
                verification_blocked
            )
            > 0
        ),

        "verification_block_reasons": (
            verification_blocked
        ),

        "reasons": reasons,

        "signals": {
            "ocr_risk": round(
                ocr_risk,
                4,
            ),

            "image_quality_risk": round(
                image_quality_risk,
                4,
            ),

            "tamper_evidence": round(
                combined_tampering,
                4,
            ),

            "global_tampering_evidence": round(
                global_tampering,
                4,
            ),

            "local_tampering_evidence": round(
                local_tampering,
                4,
            ),

            "ml_forged_probability": round(
                ml_forged_probability,
                4,
            ),

            "ml_real_probability": round(
                ml_real_probability,
                4,
            ),

            "ml_forgery_available": (
                ml_available
            ),

            "face_risk": round(
                face_risk,
                4,
            ),

            "field_risk": round(
                field_risk,
                4,
            ),

            "cross_validation_risk": round(
                cross_risk,
                4,
            ),

            "content_quality": round(
                content_quality,
                4,
            ),

            "image_quality": round(
                image_quality,
                4,
            ),

            "ocr_confidence": round(
                ocr_conf,
                4,
            ),

            "likely_cropped": (
                likely_cropped
            ),

            "crop_confidence": round(
                crop_confidence,
                4,
            ),

            "highest_ocr_region_anomaly": round(
                highest_region_anomaly,
                4,
            ),

            "face_present": (
                face_present
            ),

            "cross_validation_attempted": (
                cross_attempted
            ),

            "document_type_influence": (
                document_type_influence
            ),
        },

        "document_type": (
            document_type
            or "unknown"
        ),
    }