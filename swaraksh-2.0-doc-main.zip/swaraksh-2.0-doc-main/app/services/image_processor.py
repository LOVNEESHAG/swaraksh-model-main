# app/services/image_processor.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np


# ============================================================
# PROCESSED IMAGE RESULT
# ============================================================

@dataclass
class ProcessedImage:
    """
    Result of the universal image-processing stage.

    This stage does NOT determine whether a document is genuine
    or forged.

    It prepares the image and calculates image-quality metadata.
    """

    original: np.ndarray

    gray: np.ndarray

    enhanced: np.ndarray

    document_crop: np.ndarray

    perspective_corrected: bool

    # Final analysis image dimensions.
    width: int

    height: int

    # Quality metrics calculated on document_crop.
    sharpness_score: float

    brightness_score: float

    contrast_score: float

    noise_score: float

    # Document completeness/cropping.
    document_boundary_detected: bool

    likely_cropped: bool

    crop_confidence: float

    # Original image -> document crop area.
    original_area_fraction: float

    warnings: list[str]


# ============================================================
# IMAGE DECODING
# ============================================================

def decode_image(
    data: bytes,
) -> np.ndarray:
    """
    Decode uploaded bytes into a BGR OpenCV image.
    """

    if not data:
        raise ValueError(
            "No image data was provided."
        )

    arr = np.frombuffer(
        data,
        dtype=np.uint8,
    )

    if arr.size == 0:
        raise ValueError(
            "Uploaded image data is empty."
        )

    image = cv2.imdecode(
        arr,
        cv2.IMREAD_COLOR,
    )

    if image is None:
        raise ValueError(
            "Could not decode image."
        )

    if image.size == 0:
        raise ValueError(
            "Decoded image is empty."
        )

    return image


# ============================================================
# GRAYSCALE
# ============================================================

def _to_gray(
    image: np.ndarray,
) -> np.ndarray:

    if image is None:
        raise ValueError(
            "Image cannot be None."
        )

    if image.ndim == 2:
        return image.copy()

    if (
        image.ndim == 3
        and image.shape[2] == 3
    ):

        return cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY,
        )

    if (
        image.ndim == 3
        and image.shape[2] == 4
    ):

        return cv2.cvtColor(
            image,
            cv2.COLOR_BGRA2GRAY,
        )

    raise ValueError(
        f"Unsupported image shape: {image.shape}"
    )


# ============================================================
# PERSPECTIVE TRANSFORM
# ============================================================

def _order_points(
    pts: np.ndarray,
) -> np.ndarray:
    """
    Order points:

        top-left
        top-right
        bottom-right
        bottom-left
    """

    pts = np.asarray(
        pts,
        dtype=np.float32,
    )

    if pts.shape != (4, 2):
        raise ValueError(
            "Perspective transform requires exactly 4 points."
        )

    coordinate_sum = pts.sum(
        axis=1
    )

    coordinate_diff = np.diff(
        pts,
        axis=1,
    ).reshape(-1)

    rect = np.zeros(
        (4, 2),
        dtype=np.float32,
    )

    rect[0] = pts[
        np.argmin(
            coordinate_sum
        )
    ]

    rect[2] = pts[
        np.argmax(
            coordinate_sum
        )
    ]

    rect[1] = pts[
        np.argmin(
            coordinate_diff
        )
    ]

    rect[3] = pts[
        np.argmax(
            coordinate_diff
        )
    ]

    return rect


def _four_point_transform(
    image: np.ndarray,
    pts: np.ndarray,
) -> np.ndarray:
    """
    Perspective-correct a detected document quadrilateral.
    """

    rect = _order_points(
        pts
    )

    top_left, top_right, bottom_right, bottom_left = rect

    width_a = np.linalg.norm(
        bottom_right - bottom_left
    )

    width_b = np.linalg.norm(
        top_right - top_left
    )

    max_width = max(
        int(round(width_a)),
        int(round(width_b)),
    )

    height_a = np.linalg.norm(
        top_right - bottom_right
    )

    height_b = np.linalg.norm(
        top_left - bottom_left
    )

    max_height = max(
        int(round(height_a)),
        int(round(height_b)),
    )

    # Reject obviously unreasonable transformations.
    if (
        max_width < 100
        or max_height < 100
        or max_width > 10000
        or max_height > 10000
    ):
        return image.copy()

    destination = np.array(
        [
            [0, 0],
            [max_width - 1, 0],
            [max_width - 1, max_height - 1],
            [0, max_height - 1],
        ],
        dtype=np.float32,
    )

    matrix = cv2.getPerspectiveTransform(
        rect,
        destination,
    )

    transformed = cv2.warpPerspective(
        image,
        matrix,
        (
            max_width,
            max_height,
        ),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )

    if (
        transformed is None
        or transformed.size == 0
    ):
        return image.copy()

    return transformed


# ============================================================
# DOCUMENT BOUNDARY DETECTION
# ============================================================

def _detect_document_boundary(
    image: np.ndarray,
) -> tuple[
    Optional[np.ndarray],
    float,
]:

    gray = _to_gray(
        image
    )

    # Mild blur before edge detection.
    blurred = cv2.GaussianBlur(
        gray,
        (5, 5),
        0,
    )

    edges = cv2.Canny(
        blurred,
        50,
        150,
    )

    contours, _ = cv2.findContours(
        edges,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE,
    )

    image_area = float(
        image.shape[0]
        * image.shape[1]
    )

    if image_area <= 0:
        return None, 0.0

    best_points: Optional[
        np.ndarray
    ] = None

    best_fraction = 0.0

    for contour in contours:

        area = cv2.contourArea(
            contour
        )

        fraction = (
            area
            / image_area
        )

        # Ignore tiny regions.
        if fraction < 0.20:
            continue

        perimeter = cv2.arcLength(
            contour,
            True,
        )

        if perimeter <= 0:
            continue

        approximation = cv2.approxPolyDP(
            contour,
            0.02 * perimeter,
            True,
        )

        if len(approximation) != 4:
            continue

        candidate = (
            approximation
            .reshape(4, 2)
            .astype(np.float32)
        )

        if fraction > best_fraction:

            best_points = candidate

            best_fraction = fraction

    return (
        best_points,
        best_fraction,
    )


# ============================================================
# SHARPNESS
# ============================================================

def _laplacian_variance(
    gray: np.ndarray,
) -> float:

    if gray.size == 0:
        return 0.0

    value = cv2.Laplacian(
        gray,
        cv2.CV_64F,
    ).var()

    return float(
        max(
            0.0,
            value,
        )
    )


def _sharpness_score(
    variance: float,
) -> float:
    """
    Usability score, not authenticity.
    """

    score = (
        variance
        / (
            variance
            + 150.0
        )
    )

    return float(
        np.clip(
            score,
            0.0,
            1.0,
        )
    )


# ============================================================
# BRIGHTNESS
# ============================================================

def _brightness_score(
    gray: np.ndarray,
) -> float:

    if gray.size == 0:
        return 0.0

    mean_value = float(
        np.mean(gray)
    )

    distance = abs(
        mean_value
        - 127.5
    )

    score = (
        1.0
        - distance / 127.5
    )

    return float(
        np.clip(
            score,
            0.0,
            1.0,
        )
    )


# ============================================================
# CONTRAST
# ============================================================

def _contrast_score(
    gray: np.ndarray,
) -> float:

    if gray.size == 0:
        return 0.0

    standard_deviation = float(
        np.std(gray)
    )

    score = (
        standard_deviation
        / (
            standard_deviation
            + 35.0
        )
    )

    return float(
        np.clip(
            score,
            0.0,
            1.0,
        )
    )


# ============================================================
# NOISE
# ============================================================

def _noise_score(
    gray: np.ndarray,
) -> float:

    if gray.size == 0:
        return 0.0

    blurred = cv2.GaussianBlur(
        gray,
        (3, 3),
        0,
    )

    residual = (
        gray.astype(
            np.float32
        )
        - blurred.astype(
            np.float32
        )
    )

    noise_std = float(
        np.std(
            residual
        )
    )

    score = (
        1.0
        / (
            1.0
            + noise_std / 10.0
        )
    )

    return float(
        np.clip(
            score,
            0.0,
            1.0,
        )
    )


# ============================================================
# BORDER EDGE STRENGTH
# ============================================================

def _border_edge_strength(
    gray: np.ndarray,
    fraction: float = 0.03,
) -> tuple[float, float]:

    if gray.size == 0:
        return (
            0.0,
            0.0,
        )

    height, width = (
        gray.shape[:2]
    )

    border_h = max(
        3,
        int(
            height
            * fraction
        ),
    )

    border_w = max(
        3,
        int(
            width
            * fraction
        ),
    )

    top = gray[
        :border_h,
        :
    ]

    bottom = gray[
        height - border_h:,
        :
    ]

    left = gray[
        :,
        :border_w
    ]

    right = gray[
        :,
        width - border_w:
    ]

    def edge_mean(
        region: np.ndarray,
    ) -> float:

        if region.size == 0:
            return 0.0

        edges = cv2.Canny(
            region,
            50,
            150,
        )

        return float(
            np.mean(
                edges > 0
            )
        )

    horizontal = (
        edge_mean(top)
        + edge_mean(bottom)
    ) / 2.0

    vertical = (
        edge_mean(left)
        + edge_mean(right)
    ) / 2.0

    return (
        horizontal,
        vertical,
    )


# ============================================================
# CROPPING ESTIMATION
# ============================================================

def _estimate_cropping(
    image: np.ndarray,
    boundary: Optional[np.ndarray],
    boundary_fraction: float,
) -> tuple[
    bool,
    float,
]:

    height, width = (
        image.shape[:2]
    )

    if (
        height <= 0
        or width <= 0
    ):
        return (
            False,
            0.0,
        )

    # --------------------------------------------------------
    # No boundary found.
    # --------------------------------------------------------

    if boundary is None:

        gray = _to_gray(
            image
        )

        border_h, border_v = (
            _border_edge_strength(
                gray
            )
        )

        raw = min(
            1.0,
            (
                border_h
                + border_v
            ) * 8.0,
        )

        confidence = (
            0.35
            + 0.35 * raw
        )

        return (
            raw > 0.45,
            round(
                float(
                    confidence
                ),
                4,
            ),
        )

    # --------------------------------------------------------
    # Boundary exists.
    # --------------------------------------------------------

    points = boundary.astype(
        np.float32
    )

    xs = points[
        :,
        0
    ]

    ys = points[
        :,
        1
    ]

    min_x = float(
        np.min(xs)
    )

    max_x = float(
        np.max(xs)
    )

    min_y = float(
        np.min(ys)
    )

    max_y = float(
        np.max(ys)
    )

    left_margin = (
        min_x / width
    )

    right_margin = (
        (width - max_x)
        / width
    )

    top_margin = (
        min_y / height
    )

    bottom_margin = (
        (height - max_y)
        / height
    )

    margins = [
        left_margin,
        right_margin,
        top_margin,
        bottom_margin,
    ]

    near_edge_count = sum(
        margin < 0.01
        for margin in margins
    )

    if near_edge_count >= 2:

        confidence = min(
            0.95,
            0.55
            + near_edge_count
            * 0.10,
        )

        return (
            True,
            round(
                confidence,
                4,
            ),
        )

    if boundary_fraction >= 0.95:

        return (
            True,
            0.60,
        )

    return (
        False,
        0.10,
    )


# ============================================================
# PREPROCESS
# ============================================================

def preprocess(
    data: bytes,
) -> ProcessedImage:
    """
    Universal preprocessing.

    Document type is NOT used here.

    The final document_crop is the image that downstream OCR
    and forensic analysis should use.
    """

    # ========================================================
    # 1. Decode original
    # ========================================================

    original = decode_image(
        data
    )

    original_height, original_width = (
        original.shape[:2]
    )

    if (
        original_height < 100
        or original_width < 100
    ):

        raise ValueError(
            "Image resolution is too small for reliable analysis."
        )

    # ========================================================
    # 2. Find document boundary
    # ========================================================

    boundary, boundary_fraction = (
        _detect_document_boundary(
            original
        )
    )

    # ========================================================
    # 3. Estimate cropping on ORIGINAL
    # ========================================================

    likely_cropped, crop_confidence = (
        _estimate_cropping(
            original,
            boundary,
            boundary_fraction,
        )
    )

    # ========================================================
    # 4. Perspective correction
    # ========================================================

    perspective_corrected = False

    if boundary is not None:

        transformed = (
            _four_point_transform(
                original,
                boundary,
            )
        )

        if (
            transformed is not None
            and transformed.size > 0
        ):

            document_crop = (
                transformed
            )

            perspective_corrected = (
                transformed.shape[:2]
                != original.shape[:2]
            )

        else:

            document_crop = (
                original.copy()
            )

    else:

        document_crop = (
            original.copy()
        )

    # ========================================================
    # 5. Limit FINAL document-crop size
    # ========================================================

    max_side = 2400

    crop_height, crop_width = (
        document_crop.shape[:2]
    )

    largest_side = max(
        crop_height,
        crop_width,
    )

    resize_scale = min(
        1.0,
        max_side
        / max(
            largest_side,
            1,
        ),
    )

    if resize_scale < 1.0:

        document_crop = cv2.resize(
            document_crop,
            (
                max(
                    1,
                    int(
                        crop_width
                        * resize_scale
                    ),
                ),
                max(
                    1,
                    int(
                        crop_height
                        * resize_scale
                    ),
                ),
            ),
            interpolation=cv2.INTER_AREA,
        )

    # ========================================================
    # 6. FINAL ANALYSIS IMAGE
    # ========================================================

    final_height, final_width = (
        document_crop.shape[:2]
    )

    final_gray = _to_gray(
        document_crop
    )

    # ========================================================
    # 7. Enhancement for metadata / OCR support
    # ========================================================

    denoised = (
        cv2.fastNlMeansDenoising(
            final_gray,
            None,
            10,
            7,
            21,
        )
    )

    clahe = cv2.createCLAHE(
        clipLimit=2.0,
        tileGridSize=(8, 8),
    )

    enhanced_gray = clahe.apply(
        denoised
    )

    enhanced = cv2.cvtColor(
        enhanced_gray,
        cv2.COLOR_GRAY2BGR,
    )

    # ========================================================
    # 8. Quality metrics on FINAL analysis image
    # ========================================================

    sharpness_raw = (
        _laplacian_variance(
            final_gray
        )
    )

    sharpness_score = (
        _sharpness_score(
            sharpness_raw
        )
    )

    brightness_score = (
        _brightness_score(
            final_gray
        )
    )

    contrast_score = (
        _contrast_score(
            final_gray
        )
    )

    noise_score = (
        _noise_score(
            final_gray
        )
    )

    # ========================================================
    # 9. Warnings
    # ========================================================

    warnings: list[str] = []

    if sharpness_score < 0.35:

        warnings.append(
            "Image sharpness is low."
        )

    if brightness_score < 0.35:

        warnings.append(
            "Image brightness may limit analysis."
        )

    if contrast_score < 0.35:

        warnings.append(
            "Image contrast is low."
        )

    if noise_score < 0.30:

        warnings.append(
            "Image contains substantial noise."
        )

    if boundary is None:

        warnings.append(
            "Document boundary could not be confidently detected."
        )

    if likely_cropped:

        warnings.append(
            "Image may be cropped or may not contain "
            "the complete document boundary."
        )

    # ========================================================
    # 10. Original/document area fraction
    # ========================================================

    original_area = float(
        original_width
        * original_height
    )

    pre_resize_crop_area = float(
        crop_width
        * crop_height
    )

    if original_area > 0:

        original_area_fraction = (
            pre_resize_crop_area
            / original_area
        )

    else:

        original_area_fraction = 1.0

    # ========================================================
    # 11. Return
    # ========================================================

    return ProcessedImage(
        original=original,

        gray=final_gray,

        enhanced=enhanced,

        document_crop=document_crop,

        perspective_corrected=(
            perspective_corrected
        ),

        width=final_width,

        height=final_height,

        sharpness_score=round(
            sharpness_score,
            4,
        ),

        brightness_score=round(
            brightness_score,
            4,
        ),

        contrast_score=round(
            contrast_score,
            4,
        ),

        noise_score=round(
            noise_score,
            4,
        ),

        document_boundary_detected=(
            boundary is not None
        ),

        likely_cropped=(
            likely_cropped
        ),

        crop_confidence=round(
            crop_confidence,
            4,
        ),

        original_area_fraction=round(
            float(
                original_area_fraction
            ),
            4,
        ),

        warnings=warnings,
    )