# app/services/field_extractor.py

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from .ocr_service import OCRResult


# ============================================================
# DATE PATTERNS
# ============================================================

DATE_PATTERNS = [
    re.compile(
        r"\b\d{2}[/-]\d{2}[/-]\d{4}\b"
    ),
    re.compile(
        r"\b\d{4}[/-]\d{2}[/-]\d{2}\b"
    ),
    re.compile(
        r"\b\d{1,2}[./-]\d{1,2}[./-]\d{4}\b"
    ),
    re.compile(
        r"\b(?:"
        r"jan(?:uary)?|"
        r"feb(?:ruary)?|"
        r"mar(?:ch)?|"
        r"apr(?:il)?|"
        r"may|"
        r"jun(?:e)?|"
        r"jul(?:y)?|"
        r"aug(?:ust)?|"
        r"sep(?:tember)?|"
        r"oct(?:ober)?|"
        r"nov(?:ember)?|"
        r"dec(?:ember)?"
        r")"
        r"\s+\d{1,2}"
        r"(?:,)?"
        r"\s+\d{4}\b",
        re.IGNORECASE,
    ),
]


DATE_FORMATS = (
    "%d/%m/%Y",
    "%d-%m-%Y",
    "%d.%m.%Y",
    "%Y/%m/%d",
    "%Y-%m-%d",
    "%Y.%m.%d",
    "%B %d, %Y",
    "%B %d %Y",
    "%b %d, %Y",
    "%b %d %Y",
)


# ============================================================
# SEMANTIC FIELD LABELS
# ============================================================

FIELD_LABELS = {
    "name": [
        "full name",
        "holder name",
        "card holder",
        "cardholder",
        "name",
    ],

    "dob": [
        "date of birth",
        "birth date",
        "dob",
        "born",
    ],

    "document_number": [
        "document number",
        "document no",
        "document id",
        "license number",
        "licence number",
        "license no",
        "licence no",
        "driving license number",
        "driving licence number",
        "driving license no",
        "driving licence no",
        "id number",
        "id no",
        "card number",
        "card no",
    ],

    "issue_date": [
        "date of first issue",
        "date of issue",
        "issue date",
        "date issued",
        "issued on",
        "awarded on",
        "completion date",
        "date of completion",
        "completed on",
    ],

    "validity": [
        "validity",
        "valid till",
        "valid upto",
        "valid up to",
        "expiry date",
        "expires on",
        "valid through",
        "id valid upto",
        "id valid up to",
    ],

    "blood_group": [
        "blood group",
        "blood type",
    ],

    "organ_donor": [
        "organ donor",
        "organ donor status",
    ],

    "relation": [
        "son/daughter/wife of",
        "son daughter wife of",
        "daughter of",
        "son of",
        "wife of",
        "father name",
        "father's name",
        "father",
    ],

    "address": [
        "address",
        "residential address",
        "permanent address",
    ],

    "course": [
        "course",
        "program",
        "programme",
    ],

    "issuer": [
        "issued by",
        "issuer",
        "issued from",
    ],

    "certificate_id": [
        "certificate id",
        "certificate no",
        "certificate number",
        "certification id",
        "certification no",
        "credential id",
        "credential no",
        "serial no",
        "serial number",
    ],
}


# ============================================================
# NAME EXCLUSIONS
# ============================================================

NAME_EXCLUSIONS = {
    "name",
    "full name",
    "holder",
    "holder name",
    "card holder",
    "cardholder",
    "passport",
    "aadhaar",
    "uidai",
    "government of india",
    "republic of india",
    "income tax department",
    "election commission",
    "certificate",
    "program completion certificate",
    "completion certificate",
    "internship certificate",
    "issued on",
    "date of birth",
    "dob",
    "data science",
    "holder's signature",
    "holders signature",
    "signature",
    "blood group",
    "organ donor",
    "address",
    "validity",
    "issue date",
}


# ============================================================
# BASIC CLEANING
# ============================================================

def clean(
    value: Optional[str],
) -> Optional[str]:

    if value is None:
        return None

    value = str(
        value
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    ).strip()

    # IMPORTANT:
    # Do not strip "-" because values such as O- and B-
    # may contain meaningful punctuation.
    value = value.strip(
        " \t\r\n:;|="
    )

    return value or None


def normalize_name(
    value: Optional[str],
) -> Optional[str]:

    value = clean(
        value
    )

    if not value:
        return None

    value = re.sub(
        r"[^A-Za-z .'-]",
        " ",
        value,
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    ).strip()

    if len(value) < 3:
        return None

    return value or None


def normalize_identifier(
    value: Optional[str],
) -> Optional[str]:

    value = clean(
        value
    )

    if not value:
        return None

    value = re.sub(
        r"\s+",
        " ",
        value,
    )

    return value


# ============================================================
# DATE EXTRACTION
# ============================================================

def extract_date_from_text(
    text: Optional[str],
) -> Optional[str]:

    if not text:
        return None

    for pattern in DATE_PATTERNS:

        match = pattern.search(
            text
        )

        if match:
            return match.group(
                0
            ).strip()

    return None


def extract_all_dates(
    text: Optional[str],
) -> list[str]:

    if not text:
        return []

    results: list[str] = []

    for pattern in DATE_PATTERNS:

        for match in pattern.finditer(
            text
        ):

            value = match.group(
                0
            ).strip()

            if (
                value
                and value not in results
            ):
                results.append(
                    value
                )

    return results


def parse_date(
    value: Optional[str],
) -> Optional[datetime]:

    extracted = extract_date_from_text(
        value
    )

    if not extracted:
        return None

    extracted = extracted.rstrip(
        "."
    )

    for fmt in DATE_FORMATS:

        try:

            return datetime.strptime(
                extracted,
                fmt,
            )

        except ValueError:

            continue

    return None


# ============================================================
# TOKENIZATION
# ============================================================

def _normalize_token(
    value: str,
) -> str:

    value = str(
        value or ""
    ).lower()

    value = re.sub(
        r"[^a-z0-9/+-]+",
        "",
        value,
    )

    return value


def _tokenize_text(
    text: str,
) -> list[str]:

    return [
        token
        for token in (
            _normalize_token(
                part
            )
            for part in text.split()
        )
        if token
    ]


def _label_tokens(
    label: str,
) -> list[str]:

    return _tokenize_text(
        label
    )


# ============================================================
# NAME EXTRACTION FROM PLAIN OCR TEXT
# ============================================================

def _find_label_value(
    text: str,
    labels: list[str],
    max_value_tokens: int = 8,
) -> Optional[str]:
    """
    Extract a value from plain OCR text.

    This function is kept for certificate/general text
    extraction. OCR-region extraction below uses actual
    bounding boxes and is more precise.
    """

    if not text:
        return None

    raw_tokens = [
        token
        for token in text.split()
        if token.strip()
    ]

    normalized_tokens = [
        _normalize_token(
            token
        )
        for token in raw_tokens
    ]

    label_entries = []

    for label in labels:

        tokens = _label_tokens(
            label
        )

        if tokens:

            label_entries.append(
                (
                    label,
                    tokens,
                )
            )

    label_entries.sort(
        key=lambda item: len(
            item[1]
        ),
        reverse=True,
    )

    for i in range(
        len(normalized_tokens)
    ):

        for label, wanted in label_entries:

            end = i + len(
                wanted
            )

            if end > len(
                normalized_tokens
            ):
                continue

            if normalized_tokens[
                i:end
            ] != wanted:
                continue

            value_tokens = []

            for j in range(
                end,
                min(
                    len(raw_tokens),
                    end + max_value_tokens,
                ),
            ):

                value_tokens.append(
                    raw_tokens[j]
                )

            candidate = clean(
                " ".join(
                    value_tokens
                )
            )

            if candidate:

                # Stop obvious contamination.
                candidate = re.split(
                    r"\bholder'?s?\s+signature\b"
                    r"|\bsignature\b"
                    r"|\bdate\s+of\s+birth\b"
                    r"|\bdob\b"
                    r"|\bblood\s+group\b"
                    r"|\borgan\s+donor\b"
                    r"|\baddress\b"
                    r"|\bissue\s+date\b"
                    r"|\bvalidity\b",
                    candidate,
                    maxsplit=1,
                    flags=re.IGNORECASE,
                )[0].strip()

                if candidate:
                    return candidate

    return None


# ============================================================
# CERTIFICATE NAME
# ============================================================

CERTIFICATE_NAME_PATTERNS = [
    re.compile(
        r"\b(?:awarded\s+to|presented\s+to|conferred\s+to)\s+"
        r"([A-Za-z][A-Za-z .'-]{2,80})",
        re.IGNORECASE,
    ),

    re.compile(
        r"\bcertificate\s+is\s+awarded\s+to\s+"
        r"([A-Za-z][A-Za-z .'-]{2,80})",
        re.IGNORECASE,
    ),

    re.compile(
        r"\bcertificate\s+is\s+(?:hereby\s+)?awarded\s+to\s+"
        r"([A-Za-z][A-Za-z .'-]{2,80})",
        re.IGNORECASE,
    ),
]


def extract_name(
    text: str,
) -> Optional[str]:

    if not text:
        return None

    # --------------------------------------------------------
    # Certificate-style name
    # --------------------------------------------------------

    for pattern in CERTIFICATE_NAME_PATTERNS:

        match = pattern.search(
            text
        )

        if not match:
            continue

        candidate = normalize_name(
            match.group(1)
        )

        if not candidate:
            continue

        candidate = re.split(
            r"\bfor successfully\b"
            r"|\bsuccessfully\b"
            r"|\bfor completing\b"
            r"|\bfor successfully completing\b",
            candidate,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0].strip()

        if candidate:
            return candidate

    # --------------------------------------------------------
    # Explicit name label
    # --------------------------------------------------------

    labelled = _find_label_value(
        text,
        FIELD_LABELS["name"],
        max_value_tokens=6,
    )

    if labelled:

        candidate = normalize_name(
            labelled
        )

        if candidate:

            candidate = re.split(
                r"\bholder'?s?\s+signature\b"
                r"|\bsignature\b"
                r"|\bdate\s+of\s+birth\b"
                r"|\bdob\b"
                r"|\bblood\s+group\b"
                r"|\borgan\s+donor\b"
                r"|\baddress\b"
                r"|\bissue\s+date\b"
                r"|\bvalidity\b",
                candidate,
                maxsplit=1,
                flags=re.IGNORECASE,
            )[0].strip()

            if (
                candidate
                and candidate.lower()
                not in NAME_EXCLUSIONS
            ):

                words = candidate.split()

                if 1 <= len(words) <= 5:
                    return candidate

    # --------------------------------------------------------
    # Conservative line-based fallback
    # --------------------------------------------------------

    lines = [
        clean(line) or ""
        for line in text.splitlines()
        if line.strip()
    ]

    for line in lines:

        candidate = normalize_name(
            line
        )

        if not candidate:
            continue

        if (
            candidate.lower()
            in NAME_EXCLUSIONS
        ):
            continue

        # Don't allow a line containing dates/labels to become
        # a person's name.
        if extract_date_from_text(
            candidate
        ):
            continue

        if _contains_any_label(
            candidate
        ):
            continue

        words = candidate.split()

        if not 2 <= len(words) <= 5:
            continue

        if len(candidate) > 60:
            continue

        if not all(
            re.fullmatch(
                r"[A-Za-z][A-Za-z.'-]*",
                word,
            )
            for word in words
        ):
            continue

        return candidate

    return None


# ============================================================
# GENERIC LABEL CHECK
# ============================================================

def _contains_any_label(
    text: str,
) -> bool:

    lowered = text.lower()

    bad_phrases = [
        "holder's signature",
        "holders signature",
        "signature",
        "date of birth",
        "blood group",
        "organ donor",
        "issue date",
        "validity",
        "valid upto",
        "valid up to",
        "address",
        "government of india",
        "passport",
        "aadhaar",
    ]

    return any(
        phrase in lowered
        for phrase in bad_phrases
    )


# ============================================================
# IDENTIFIER
# ============================================================

_DATE_ONLY_RE = re.compile(
    r"^\d{1,4}[./-]\d{1,2}[./-]\d{2,4}$"
)


def _looks_like_identifier(
    value: str,
) -> bool:

    value = clean(
        value
    ) or ""

    if not value:
        return False

    if _DATE_ONLY_RE.fullmatch(
        value
    ):
        return False

    compact = re.sub(
        r"[^A-Za-z0-9]",
        "",
        value,
    )

    if len(compact) < 4:
        return False

    if len(compact) > 40:
        return False

    # Pure words are generally not identifiers.
    if compact.isalpha():
        return False

    # Pure numeric identifiers are possible.
    if compact.isdigit():
        return len(compact) >= 6

    # Mixed alphanumeric is useful.
    return (
        any(
            char.isalpha()
            for char in compact
        )
        and any(
            char.isdigit()
            for char in compact
        )
    )


def extract_identifier_observation(
    text: str,
) -> Optional[str]:

    if not text:
        return None

    labelled = _find_label_value(
        text,
        FIELD_LABELS["document_number"],
        max_value_tokens=4,
    )

    if labelled:

        candidate = normalize_identifier(
            labelled
        )

        if candidate:

            # Prevent another field from leaking in.
            candidate = re.split(
                r"\bdate\s+of\s+birth\b"
                r"|\bdob\b"
                r"|\bblood\s+group\b"
                r"|\baddress\b"
                r"|\bvalidity\b"
                r"|\bissued\b"
                r"|\bissue\s+date\b",
                candidate,
                maxsplit=1,
                flags=re.IGNORECASE,
            )[0].strip()

            if _looks_like_identifier(
                candidate
            ):
                return candidate

    candidates: list[str] = []

    patterns = [
        re.compile(
            r"\b[A-Za-z]{1,5}"
            r"(?:[\s-]*\d{2,6})"
            r"(?:[\s-]*\d{2,20})\b"
        ),

        re.compile(
            r"\b[A-Za-z0-9][A-Za-z0-9/-]{5,29}\b"
        ),
    ]

    for pattern in patterns:

        for match in pattern.finditer(
            text
        ):

            candidate = normalize_identifier(
                match.group(0)
            )

            if not candidate:
                continue

            if (
                _DATE_ONLY_RE.fullmatch(
                    candidate
                )
            ):
                continue

            if _looks_like_identifier(
                candidate
            ):
                candidates.append(
                    candidate
                )

    if not candidates:
        return None

    def score(
        value: str,
    ) -> tuple[int, int]:

        compact = re.sub(
            r"[^A-Za-z0-9]",
            "",
            value,
        )

        digits = sum(
            char.isdigit()
            for char in compact
        )

        return (
            digits,
            len(compact),
        )

    candidates.sort(
        key=score,
        reverse=True,
    )

    return candidates[0]


# ============================================================
# CERTIFICATE EXTRACTION
# ============================================================

def extract_certificate_fields(
    text: str,
) -> dict:

    issue_date: Optional[str] = None
    certificate_id: Optional[str] = None
    course: Optional[str] = None
    issuer: Optional[str] = None

    issue_value = _find_label_value(
        text,
        FIELD_LABELS["issue_date"],
        max_value_tokens=5,
    )

    if issue_value:
        issue_date = extract_date_from_text(
            issue_value
        )

    certificate_id_value = _find_label_value(
        text,
        FIELD_LABELS["certificate_id"],
        max_value_tokens=3,
    )

    if certificate_id_value:

        match = re.search(
            r"[A-Za-z0-9][A-Za-z0-9_./-]{2,50}",
            certificate_id_value,
        )

        if match:
            certificate_id = match.group(
                0
            )

    course_value = _find_label_value(
        text,
        FIELD_LABELS["course"],
        max_value_tokens=10,
    )

    if course_value:

        course = re.split(
            r"\bon\b"
            r"|\bissued\b"
            r"|\bissued\s+on\b"
            r"|\bdate\b",
            course_value,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0].strip()

        if len(course) > 120:
            course = course[:120].strip()

    issuer_value = _find_label_value(
        text,
        FIELD_LABELS["issuer"],
        max_value_tokens=8,
    )

    if issuer_value:
        issuer = clean(
            issuer_value
        )

    if not issuer:

        match = re.search(
            r"\bInfosys\s+Limited\b",
            text,
            re.IGNORECASE,
        )

        if match:
            issuer = clean(
                match.group(0)
            )

    return {
        "issue_date": issue_date,
        "certificate_id": certificate_id,
        "course": course,
        "issuer": issuer,
    }


# ============================================================
# OCR WORD HELPERS
# ============================================================

def _word_text(
    word: Any,
) -> str:

    return str(
        getattr(
            word,
            "text",
            "",
        )
        or ""
    ).strip()


def _word_confidence(
    word: Any,
) -> float:

    try:

        return max(
            0.0,
            min(
                1.0,
                float(
                    getattr(
                        word,
                        "confidence",
                        0.0,
                    )
                ),
            ),
        )

    except (
        TypeError,
        ValueError,
    ):

        return 0.0


def _word_box(
    word: Any,
) -> tuple[int, int, int, int]:

    try:

        x = int(
            getattr(
                word,
                "x",
                0,
            )
        )

        y = int(
            getattr(
                word,
                "y",
                0,
            )
        )

        w = int(
            getattr(
                word,
                "w",
                0,
            )
        )

        h = int(
            getattr(
                word,
                "h",
                0,
            )
        )

    except (
        TypeError,
        ValueError,
    ):

        return (
            0,
            0,
            0,
            0,
        )

    return (
        x,
        y,
        max(
            0,
            w,
        ),
        max(
            0,
            h,
        ),
    )


# ============================================================
# OCR LINE BUILDING
# ============================================================

def _group_words_into_lines(
    words: list[Any],
) -> list[list[Any]]:
    """
    Group OCR words by approximate visual line.

    This is critical.

    We do NOT assume that every token after a label belongs
    to the field.

    Example:

        ID valid upto: 15/07/2028

    should produce one line containing those tokens.

    The next unrelated line should not be included.
    """

    valid_words: list[Any] = []

    for word in words:

        text = _word_text(
            word
        )

        if not text:
            continue

        x, y, w, h = _word_box(
            word
        )

        if w <= 0 or h <= 0:
            continue

        valid_words.append(
            word
        )

    # Read from top to bottom, left to right.
    valid_words.sort(
        key=lambda word: (
            _word_box(word)[1],
            _word_box(word)[0],
        )
    )

    lines: list[list[Any]] = []

    for word in valid_words:

        _, y, _, h = _word_box(
            word
        )

        center_y = (
            y + h / 2.0
        )

        best_line = None
        best_distance = None

        for line in lines:

            centers = []

            for existing in line:

                _, ey, _, eh = _word_box(
                    existing
                )

                centers.append(
                    ey + eh / 2.0
                )

            line_center = (
                sum(centers)
                / len(centers)
            )

            # Adaptive tolerance.
            average_height = (
                sum(
                    _word_box(existing)[3]
                    for existing in line
                )
                / max(
                    len(line),
                    1,
                )
            )

            tolerance = max(
                8.0,
                average_height * 0.60,
            )

            distance = abs(
                center_y
                - line_center
            )

            if distance <= tolerance:

                if (
                    best_distance is None
                    or distance < best_distance
                ):

                    best_line = line
                    best_distance = distance

        if best_line is not None:

            best_line.append(
                word
            )

        else:

            lines.append(
                [word]
            )

    for line in lines:

        line.sort(
            key=lambda word: _word_box(
                word
            )[0]
        )

    lines.sort(
        key=lambda line: _word_box(
            line[0]
        )[1]
    )

    return lines


# ============================================================
# FIND LABEL INSIDE OCR LINE
# ============================================================

def _find_label_in_line(
    line: list[Any],
) -> list[
    tuple[str, int, int]
]:
    """
    Find semantic labels inside one OCR line.

    Returns:

        field_name
        label_start_index
        label_end_index
    """

    tokens = [
        _normalize_token(
            _word_text(word)
        )
        for word in line
    ]

    matches: list[
        tuple[str, int, int]
    ] = []

    entries = []

    for field_name, labels in FIELD_LABELS.items():

        for label in labels:

            label_tokens = _label_tokens(
                label
            )

            if label_tokens:

                entries.append(
                    (
                        field_name,
                        label_tokens,
                    )
                )

    # Longest labels first.
    entries.sort(
        key=lambda item: len(
            item[1]
        ),
        reverse=True,
    )

    for i in range(
        len(tokens)
    ):

        for field_name, wanted in entries:

            end = i + len(
                wanted
            )

            if end > len(tokens):
                continue

            if tokens[
                i:end
            ] == wanted:

                matches.append(
                    (
                        field_name,
                        i,
                        end,
                    )
                )

                break

    matches.sort(
        key=lambda item: item[1]
    )

    return matches


# ============================================================
# FIELD VALUE WORDS ON SAME LINE
# ============================================================

def _value_words_after_label(
    line: list[Any],
    label_end: int,
    next_label_start: Optional[int],
) -> list[Any]:
    """
    Return only words belonging to a field value.

    The next semantic label on the same line is a hard stop.
    """

    end = (
        next_label_start
        if next_label_start is not None
        else len(line)
    )

    value_words = line[
        label_end:end
    ]

    # Remove punctuation-only words.
    value_words = [
        word
        for word in value_words
        if _word_text(
            word
        ).strip(
            " :;|="
        )
    ]

    return value_words


# ============================================================
# UNION OCR BOX
# ============================================================

def _union_boxes(
    words: list[Any],
) -> tuple[int, int, int, int]:

    boxes = []

    for word in words:

        x, y, w, h = _word_box(
            word
        )

        if w <= 0 or h <= 0:
            continue

        boxes.append(
            (
                x,
                y,
                w,
                h,
            )
        )

    if not boxes:

        return (
            0,
            0,
            0,
            0,
        )

    left = min(
        box[0]
        for box in boxes
    )

    top = min(
        box[1]
        for box in boxes
    )

    right = max(
        box[0] + box[2]
        for box in boxes
    )

    bottom = max(
        box[1] + box[3]
        for box in boxes
    )

    return (
        left,
        top,
        max(
            1,
            right - left,
        ),
        max(
            1,
            bottom - top,
        ),
    )


# ============================================================
# FIELD-SPECIFIC VALUE CLEANUP
# ============================================================

def _clean_field_value(
    field_name: str,
    value: str,
) -> Optional[str]:

    value = clean(
        value
    )

    if not value:
        return None

    # --------------------------------------------------------
    # DOB
    # --------------------------------------------------------

    if field_name == "dob":

        return extract_date_from_text(
            value
        )

    # --------------------------------------------------------
    # Issue date
    # --------------------------------------------------------

    if field_name == "issue_date":

        return extract_date_from_text(
            value
        )

    # --------------------------------------------------------
    # Validity
    # --------------------------------------------------------

    if field_name == "validity":

        return extract_date_from_text(
            value
        )

    # --------------------------------------------------------
    # Blood group
    # --------------------------------------------------------

    if field_name == "blood_group":

        match = re.search(
            r"\b(?:A|B|AB|O)"
            r"[+-]?\b",
            value,
            re.IGNORECASE,
        )

        if match:

            return match.group(
                0
            ).upper()

        return value

    # --------------------------------------------------------
    # Name
    # --------------------------------------------------------

    if field_name == "name":

        return normalize_name(
            value
        )

    # --------------------------------------------------------
    # Identifier
    # --------------------------------------------------------

    if field_name == "document_number":

        value = normalize_identifier(
            value
        )

        if value and _looks_like_identifier(
            value
        ):
            return value

        return None

    return value


# ============================================================
# SEMANTIC OCR REGIONS
# ============================================================

def extract_ocr_regions(
    ocr_result: Optional[OCRResult],
) -> list[dict]:
    """
    Build semantic OCR regions from actual OCR word boxes.

    IMPORTANT:

        The region contains the VALUE only.

    Example:

        Blood Group: O-

    becomes:

        field      = blood_group
        value      = O-
        box        = box around O-

    It does NOT create a huge box containing the rest of
    the document.
    """

    if not ocr_result:
        return []

    words = list(
        getattr(
            ocr_result,
            "words",
            [],
        )
        or []
    )

    if not words:
        return []

    lines = _group_words_into_lines(
        words
    )

    regions: list[dict] = []

    for line in lines:

        matches = _find_label_in_line(
            line
        )

        if not matches:
            continue

        for match_index, (
            field_name,
            _label_start,
            label_end,
        ) in enumerate(matches):

            next_label_start = None

            if (
                match_index + 1
                < len(matches)
            ):

                next_label_start = (
                    matches[
                        match_index + 1
                    ][1]
                )

            value_words = (
                _value_words_after_label(
                    line,
                    label_end,
                    next_label_start,
                )
            )

            if not value_words:
                continue

            # ------------------------------------------------
            # Keep the value compact.
            # ------------------------------------------------

            max_tokens = {
                "name": 5,
                "dob": 3,
                "document_number": 5,
                "issue_date": 4,
                "validity": 4,
                "blood_group": 2,
                "organ_donor": 3,
                "relation": 8,
                "address": 12,
                "course": 8,
                "issuer": 6,
                "certificate_id": 4,
            }.get(
                field_name,
                6,
            )

            value_words = value_words[
                :max_tokens
            ]

            raw_value = " ".join(
                _word_text(word)
                for word in value_words
            )

            value = _clean_field_value(
                field_name,
                raw_value,
            )

            if not value:
                continue

            x, y, w, h = _union_boxes(
                value_words
            )

            if w <= 0 or h <= 0:
                continue

            confidence_values = [
                _word_confidence(word)
                for word in value_words
            ]

            confidence = (
                sum(confidence_values)
                / max(
                    len(
                        confidence_values
                    ),
                    1,
                )
            )

            label_text = " ".join(
                _word_text(
                    line[index]
                )
                for index in range(
                    _label_start,
                    label_end,
                )
            )

            regions.append(
                {
                    "field": field_name,
                    "label": label_text,
                    "value": value,
                    "x": x,
                    "y": y,
                    "w": w,
                    "h": h,
                    "confidence": round(
                        confidence,
                        4,
                    ),
                }
            )

    # --------------------------------------------------------
    # Remove duplicates.
    # --------------------------------------------------------

    unique: list[dict] = []
    seen: set[tuple] = set()

    for region in regions:

        key = (
            region["field"],
            region["value"],
            region["x"],
            region["y"],
            region["w"],
            region["h"],
        )

        if key in seen:
            continue

        seen.add(
            key
        )

        unique.append(
            region
        )

    return unique


# ============================================================
# DATE REGIONS
# ============================================================

def find_date_regions(
    ocr_result: OCRResult,
) -> list[dict]:

    regions: list[dict] = []

    if not ocr_result:
        return regions

    for word in (
        getattr(
            ocr_result,
            "words",
            [],
        )
        or []
    ):

        text = _word_text(
            word
        )

        value = extract_date_from_text(
            text
        )

        if not value:
            continue

        x, y, w, h = _word_box(
            word
        )

        if w <= 0 or h <= 0:
            continue

        regions.append(
            {
                "field": "date",
                "label": "date",
                "value": value,
                "x": x,
                "y": y,
                "w": w,
                "h": h,
                "confidence": _word_confidence(
                    word
                ),
            }
        )

    return regions


# ============================================================
# MAIN FIELD EXTRACTION
# ============================================================

def extract_fields(
    text_or_ocr,
    document_type: Optional[str] = None,
) -> dict:
    """
    Generic document field extraction.

    Document type is informational only.

    This function performs:
        OCR interpretation
        semantic field extraction
        OCR-region generation

    It does NOT determine authenticity.
    It does NOT perform PAN/Aadhaar/passport/DL format
    authenticity validation.
    """

    # --------------------------------------------------------
    # OCRResult
    # --------------------------------------------------------

    if isinstance(
        text_or_ocr,
        OCRResult,
    ):

        ocr_result = text_or_ocr

        text = (
            ocr_result.text
            or ""
        ).strip()

    else:

        ocr_result = None

        text = str(
            text_or_ocr
            or ""
        ).strip()

    if not text:

        return {
            "name": None,
            "dob": None,
            "document_number": None,
            "issue_date": None,
            "certificate_id": None,
            "course": None,
            "issuer": None,
            "date_regions": [],
            "ocr_regions": [],
            "raw_text": "",
        }

    # ========================================================
    # SEMANTIC OCR REGIONS FIRST
    # ========================================================

    if ocr_result:

        ocr_regions = extract_ocr_regions(
            ocr_result
        )

        date_regions = find_date_regions(
            ocr_result
        )

    else:

        ocr_regions = []
        date_regions = []

    # ========================================================
    # NAME
    # ========================================================

    name = extract_name(
        text
    )

    # Prefer semantic OCR region when available.
    for region in ocr_regions:

        if region.get(
            "field"
        ) != "name":
            continue

        candidate = normalize_name(
            region.get(
                "value"
            )
        )

        if candidate:

            if (
                candidate.lower()
                not in NAME_EXCLUSIONS
            ):

                name = candidate
                break

    # ========================================================
    # DOB
    # ========================================================
    #
    # IMPORTANT:
    #
    # We NO LONGER use:
    #
    #     "only one date exists -> DOB"
    #
    # because a sole validity/expiry date must not become DOB.
    # ========================================================

    dob: Optional[str] = None

    for region in ocr_regions:

        if region.get(
            "field"
        ) != "dob":
            continue

        candidate = (
            extract_date_from_text(
                region.get(
                    "value"
                )
            )
        )

        if candidate:

            dob = candidate
            break

    if not dob:

        dob_value = _find_label_value(
            text,
            FIELD_LABELS["dob"],
            max_value_tokens=3,
        )

        if dob_value:

            dob = extract_date_from_text(
                dob_value
            )

    # ========================================================
    # DOCUMENT NUMBER
    # ========================================================

    document_number = None

    for region in ocr_regions:

        if region.get(
            "field"
        ) != "document_number":
            continue

        candidate = normalize_identifier(
            region.get(
                "value"
            )
        )

        if (
            candidate
            and _looks_like_identifier(
                candidate
            )
        ):

            document_number = candidate
            break

    if not document_number:

        document_number = (
            extract_identifier_observation(
                text
            )
        )

    # ========================================================
    # VALIDITY / ISSUE DATE
    # ========================================================

    issue_date: Optional[str] = None

    validity_date: Optional[str] = None

    for region in ocr_regions:

        field_name = region.get(
            "field"
        )

        value = region.get(
            "value"
        )

        if field_name == "issue_date":

            candidate = (
                extract_date_from_text(
                    value
                )
            )

            if candidate:
                issue_date = candidate

        elif field_name == "validity":

            candidate = (
                extract_date_from_text(
                    value
                )
            )

            if candidate:
                validity_date = candidate

    # ========================================================
    # CERTIFICATE FIELDS
    # ========================================================

    certificate = (
        extract_certificate_fields(
            text
        )
    )

    if issue_date:
        certificate[
            "issue_date"
        ] = issue_date

    # ========================================================
    # BLOOD GROUP / OTHER SEMANTIC FIELDS
    # ========================================================
    #
    # These are currently kept inside ocr_regions.
    # We don't force them into ExtractedFields because the
    # schema doesn't currently define blood_group/validity/etc.
    # ========================================================

    # ========================================================
    # IMPORTANT SAFETY:
    #
    # A validity date must never automatically become DOB.
    # ========================================================

    if (
        dob is not None
        and validity_date is not None
        and dob == validity_date
    ):

        # If the same date is clearly identified as validity,
        # do not claim that it is DOB unless DOB was explicitly
        # detected.
        explicit_dob = any(
            region.get(
                "field"
            ) == "dob"
            for region in ocr_regions
        )

        if not explicit_dob:

            dob = None

    # ========================================================
    # RETURN
    # ========================================================

    return {
        "name": name,

        "dob": dob,

        "document_number": (
            document_number
        ),

        "issue_date": (
            certificate[
                "issue_date"
            ]
        ),

        "certificate_id": (
            certificate[
                "certificate_id"
            ]
        ),

        "course": (
            certificate[
                "course"
            ]
        ),

        "issuer": (
            certificate[
                "issuer"
            ]
        ),

        "date_regions": (
            date_regions
        ),

        "ocr_regions": (
            ocr_regions
        ),

        "raw_text": text,
    }