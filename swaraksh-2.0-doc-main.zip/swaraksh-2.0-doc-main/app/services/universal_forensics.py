# app/services/universal_forensics.py

from __future__ import annotations

from typing import Any

import cv2
import numpy as np


# ============================================================
# BASIC HELPERS
# ============================================================

def clamp(
    value: float,
) -> float:
    return float(
        np.clip(
            float(value),
            0.0,
            1.0,
        )
    )


# ============================================================
# RECOMPRESSION MAP
# ============================================================

def _recompression_map(
    image: np.ndarray,
    quality: int = 90,
) -> np.ndarray | None:

    if (
        image is None
        or not isinstance(
            image,
            np.ndarray,
        )
        or image.size == 0
    ):
        return None

    ok, encoded = cv2.imencode(
        ".jpg",
        image,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            quality,
        ],
    )

    if not ok:
        return None

    recompressed = cv2.imdecode(
        encoded,
        cv2.IMREAD_COLOR,
    )

    if (
        recompressed is None
        or recompressed.shape != image.shape
    ):
        return None

    diff = cv2.absdiff(
        image,
        recompressed,
    )

    return (
        cv2.cvtColor(
            diff,
            cv2.COLOR_BGR2GRAY,
        )
        .astype(np.float32)
        / 255.0
    )


# ============================================================
# ROBUST GRID ANOMALY
# ============================================================

def _local_grid_stats(
    gray_map: np.ndarray,
    rows: int = 8,
    cols: int = 8,
) -> tuple[float, dict[str, Any]]:

    if (
        gray_map is None
        or gray_map.size == 0
    ):
        return (
            0.0,
            {
                "available": False,
            },
        )

    height, width = (
        gray_map.shape[:2]
    )

    cells: list[float] = []

    for r in range(rows):

        for c in range(cols):

            y0 = int(
                r
                * height
                / rows
            )

            y1 = int(
                (r + 1)
                * height
                / rows
            )

            x0 = int(
                c
                * width
                / cols
            )

            x1 = int(
                (c + 1)
                * width
                / cols
            )

            cell = gray_map[
                y0:y1,
                x0:x1,
            ]

            cells.append(
                float(
                    np.mean(cell)
                )
                if cell.size
                else 0.0
            )

    if not cells:

        return (
            0.0,
            {},
        )

    arr = np.asarray(
        cells,
        dtype=np.float32,
    )

    median = float(
        np.median(arr)
    )

    mad = float(
        np.median(
            np.abs(
                arr - median
            )
        )
    )

    # --------------------------------------------------------
    # IMPORTANT:
    #
    # Do not allow an extremely tiny MAD to create enormous
    # z-scores from ordinary JPEG compression differences.
    # --------------------------------------------------------

    robust_sigma = max(
        1.4826 * mad,
        0.0015,
    )

    z = (
        np.abs(
            arr - median
        )
        / robust_sigma
    )

    max_z = float(
        z.max()
    )

    # A cell must satisfy BOTH:
    #
    #   1. sufficiently large relative z-score
    #   2. sufficiently large absolute error
    #
    # This prevents tiny numerical differences from being
    # classified as strong anomalies.
    absolute_threshold = max(
        0.004,
        median * 4.0,
    )

    anomalous_mask = (
        (z >= 4.0)
        & (
            arr
            >= absolute_threshold
        )
    )

    anomalous = int(
        np.sum(
            anomalous_mask
        )
    )

    # --------------------------------------------------------
    # Convert anomaly into a conservative score.
    #
    # z-score alone is not enough.
    # --------------------------------------------------------

    z_signal = clamp(
        (
            max_z - 4.0
        )
        / 8.0
    )

    anomaly_density = (
        anomalous
        / max(
            rows * cols,
            1,
        )
    )

    density_signal = clamp(
        anomaly_density
        / 0.20
    )

    # Absolute image error signal.
    high_error = float(
        np.percentile(
            arr,
            90,
        )
    )

    absolute_signal = clamp(
        (
            high_error
            - 0.003
        )
        / 0.015
    )

    score = (
        z_signal * 0.35
        + density_signal * 0.30
        + absolute_signal * 0.35
    )

    return (
        round(
            clamp(score),
            4,
        ),
        {
            "grid_rows": rows,
            "grid_cols": cols,

            "grid_cells": [
                round(
                    float(value),
                    6,
                )
                for value in cells
            ],

            "grid_median_error": round(
                median,
                6,
            ),

            "grid_mad": round(
                mad,
                6,
            ),

            "robust_sigma_used": round(
                robust_sigma,
                6,
            ),

            "max_local_error_z": round(
                max_z,
                3,
            ),

            "absolute_error_threshold": round(
                absolute_threshold,
                6,
            ),

            "anomalous_grid_cells": anomalous,

            "anomaly_density": round(
                anomaly_density,
                4,
            ),

            "p90_error": round(
                high_error,
                6,
            ),
        },
    )


# ============================================================
# EDGE METRICS
# ============================================================

def _edge_metrics(
    gray: np.ndarray,
) -> tuple[float, float]:

    edges = cv2.Canny(
        gray,
        80,
        180,
    )

    edge_mask = (
        edges > 0
    )

    density = float(
        np.mean(
            edge_mask
        )
    )

    height, width = (
        gray.shape[:2]
    )

    local: list[float] = []

    for r in range(8):

        for c in range(8):

            y0 = int(
                r
                * height
                / 8
            )

            y1 = int(
                (r + 1)
                * height
                / 8
            )

            x0 = int(
                c
                * width
                / 8
            )

            x1 = int(
                (c + 1)
                * width
                / 8
            )

            cell = edge_mask[
                y0:y1,
                x0:x1,
            ]

            local.append(
                float(
                    np.mean(cell)
                )
                if cell.size
                else 0.0
            )

    variation = (
        float(
            np.std(
                np.asarray(
                    local,
                    dtype=np.float32,
                )
            )
        )
        if local
        else 0.0
    )

    return (
        density,
        variation,
    )


# ============================================================
# NOISE RESIDUAL
# ============================================================

def _noise_residual(
    gray: np.ndarray,
) -> np.ndarray:

    denoised = cv2.GaussianBlur(
        gray,
        (3, 3),
        0,
    )

    residual = (
        cv2.absdiff(
            gray,
            denoised,
        )
        .astype(
            np.float32
        )
        / 255.0
    )

    return residual


# ============================================================
# NOISE GRID
# ============================================================

def _noise_grid_stats(
    residual: np.ndarray,
    rows: int = 8,
    cols: int = 8,
) -> tuple[float, dict[str, Any]]:

    if (
        residual is None
        or residual.size == 0
    ):
        return (
            0.0,
            {
                "available": False,
            },
        )

    height, width = (
        residual.shape[:2]
    )

    cells: list[float] = []

    for r in range(rows):

        for c in range(cols):

            y0 = int(
                r
                * height
                / rows
            )

            y1 = int(
                (r + 1)
                * height
                / rows
            )

            x0 = int(
                c
                * width
                / cols
            )

            x1 = int(
                (c + 1)
                * width
                / cols
            )

            cell = residual[
                y0:y1,
                x0:x1,
            ]

            cells.append(
                float(
                    np.mean(cell)
                )
                if cell.size
                else 0.0
            )

    if not cells:

        return (
            0.0,
            {},
        )

    arr = np.asarray(
        cells,
        dtype=np.float32,
    )

    median = float(
        np.median(arr)
    )

    mad = float(
        np.median(
            np.abs(
                arr - median
            )
        )
    )

    # --------------------------------------------------------
    # Same protection as JPEG analysis.
    # --------------------------------------------------------

    robust_sigma = max(
        1.4826 * mad,
        0.0010,
    )

    z = (
        np.abs(
            arr - median
        )
        / robust_sigma
    )

    max_z = float(
        np.max(z)
    )

    absolute_threshold = max(
        0.003,
        median * 4.0,
    )

    anomalous_mask = (
        (z >= 4.0)
        & (
            arr
            >= absolute_threshold
        )
    )

    anomalous = int(
        np.sum(
            anomalous_mask
        )
    )

    z_signal = clamp(
        (
            max_z - 4.0
        )
        / 8.0
    )

    density = (
        anomalous
        / max(
            rows * cols,
            1,
        )
    )

    density_signal = clamp(
        density
        / 0.20
    )

    p90_error = float(
        np.percentile(
            arr,
            90,
        )
    )

    absolute_signal = clamp(
        (
            p90_error
            - 0.002
        )
        / 0.010
    )

    score = (
        z_signal * 0.35
        + density_signal * 0.30
        + absolute_signal * 0.35
    )

    return (
        round(
            clamp(score),
            4,
        ),
        {
            "noise_mean": round(
                float(
                    residual.mean()
                ),
                6,
            ),

            "noise_std": round(
                float(
                    residual.std()
                ),
                6,
            ),

            "noise_grid_median": round(
                median,
                6,
            ),

            "noise_grid_mad": round(
                mad,
                6,
            ),

            "noise_robust_sigma_used": round(
                robust_sigma,
                6,
            ),

            "noise_max_local_z": round(
                max_z,
                3,
            ),

            "noise_absolute_threshold": round(
                absolute_threshold,
                6,
            ),

            "noise_anomalous_grid_cells": (
                anomalous
            ),

            "noise_anomaly_density": round(
                density,
                4,
            ),

            "noise_p90_error": round(
                p90_error,
                6,
            ),
        },
    )


# ============================================================
# MAIN UNIVERSAL ANALYSIS
# ============================================================

def analyze_document(
    image: np.ndarray,
    ocr_confidence: float = 0.0,
    ocr_text: str = "",
) -> dict:

    """
    Universal document/image analysis.

    This analysis is document-type independent.

    It measures:

        - image quality
        - JPEG/recompression anomalies
        - noise anomalies
        - edge variation
        - OCR quality

    IMPORTANT:

        These are forensic evidence signals.

        They are NOT calibrated probabilities of forgery.
    """

    # ========================================================
    # INPUT CHECK
    # ========================================================

    if (
        image is None
        or not isinstance(
            image,
            np.ndarray,
        )
        or image.size == 0
    ):

        raise ValueError(
            "Empty image supplied to universal forensic analysis"
        )

    height, width = (
        image.shape[:2]
    )

    # ========================================================
    # GRAYSCALE
    # ========================================================

    if image.ndim == 2:

        gray = image

    else:

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY,
        )

    # ========================================================
    # EDGE
    # ========================================================

    (
        edge_density,
        edge_variation,
    ) = _edge_metrics(
        gray
    )

    # ========================================================
    # JPEG RECOMPRESSION
    # ========================================================

    recompression = (
        _recompression_map(
            image
        )
    )

    if recompression is not None:

        (
            jpeg_score,
            jpeg_signals,
        ) = _local_grid_stats(
            recompression
        )

    else:

        jpeg_score = 0.0

        jpeg_signals = {
            "available": False,
        }

    # ========================================================
    # NOISE
    # ========================================================

    residual = _noise_residual(
        gray
    )

    (
        noise_score,
        noise_signals,
    ) = _noise_grid_stats(
        residual
    )

    # ========================================================
    # BASIC IMAGE STATS
    # ========================================================

    lap_var = float(
        cv2.Laplacian(
            gray,
            cv2.CV_64F,
        ).var()
    )

    gray_mean = float(
        np.mean(
            gray
        )
    )

    gray_std = float(
        np.std(
            gray
        )
    )

    # ========================================================
    # OCR RISK
    # ========================================================

    ocr_confidence = clamp(
        ocr_confidence
    )

    ocr_risk = (
        1.0
        - ocr_confidence
    )

    # ========================================================
    # EDGE ANOMALY
    # ========================================================

    edge_anomaly = clamp(
        (
            edge_variation
            - 0.025
        )
        / 0.10
    )

    # ========================================================
    # GLOBAL IMAGE ANOMALY
    # ========================================================
    #
    # IMPORTANT:
    #
    # This is intentionally conservative.
    #
    # JPEG/noise scores alone should not dominate because
    # screenshots, WhatsApp images, phone cameras and ordinary
    # recompression can produce anomalies.
    # ========================================================

    local_anomaly = clamp(
        jpeg_score * 0.40
        + noise_score * 0.30
        + edge_anomaly * 0.30
    )

    # ========================================================
    # IMAGE QUALITY
    # ========================================================

    quality_penalty = 0.0

    warnings: list[str] = []

    if (
        width < 600
        or height < 400
    ):

        quality_penalty += 0.18

        warnings.append(
            "Image resolution is low for reliable forensic analysis."
        )

    if edge_density < 0.008:

        quality_penalty += 0.08

        warnings.append(
            "Image contains very little edge/detail information."
        )

    if len(
        (ocr_text or "").strip()
    ) < 10:

        quality_penalty += 0.10

        warnings.append(
            "OCR returned very little readable text."
        )

    if ocr_confidence < 0.45:

        quality_penalty += 0.12

        warnings.append(
            "OCR confidence is low; content validation is limited."
        )

    quality_score = clamp(
        1.0
        - quality_penalty
    )

    # ========================================================
    # RETURN
    # ========================================================

    return {
        "quality_score": round(
            quality_score,
            4,
        ),

        "tampering_evidence_score": round(
            local_anomaly,
            4,
        ),

        "signals": {
            "width": width,

            "height": height,

            "aspect_ratio": round(
                width
                / max(
                    height,
                    1,
                ),
                4,
            ),

            "edge_density": round(
                edge_density,
                6,
            ),

            "edge_density_variation": round(
                edge_variation,
                6,
            ),

            "jpeg_local_anomaly_score": round(
                jpeg_score,
                4,
            ),

            "noise_local_anomaly_score": round(
                noise_score,
                4,
            ),

            "sharpness_laplacian_variance": round(
                lap_var,
                4,
            ),

            "mean_luminance": round(
                gray_mean,
                4,
            ),

            "luminance_std": round(
                gray_std,
                4,
            ),

            "ocr_confidence": round(
                ocr_confidence,
                4,
            ),

            "ocr_risk": round(
                ocr_risk,
                4,
            ),

            "quality_warnings": warnings,

            "heuristic_only": True,

            **jpeg_signals,

            **noise_signals,
        },

        "note": (
            "Universal image-forensics signals are independent "
            "of document type. They measure image-quality and "
            "statistical anomaly evidence, but they do not prove "
            "that a document is genuine or forged."
        ),
    }