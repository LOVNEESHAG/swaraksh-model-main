# app/services/face_detector.py

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np


# ============================================================
# HAAR CASCADE CONFIGURATION
# ============================================================

CASCADE_DIR = Path(
    cv2.data.haarcascades
)

CASCADE_NAMES = [
    "haarcascade_frontalface_default.xml",
    "haarcascade_frontalface_alt2.xml",
]


# ============================================================
# FACE DETECTOR
# ============================================================

class FaceDetector:

    def __init__(
        self,
    ) -> None:

        self.classifiers: list[
            cv2.CascadeClassifier
        ] = []

        for name in CASCADE_NAMES:

            path = (
                CASCADE_DIR
                / name
            )

            classifier = (
                cv2.CascadeClassifier(
                    str(path)
                )
            )

            if not classifier.empty():

                self.classifiers.append(
                    classifier
                )

        if not self.classifiers:

            raise RuntimeError(
                "Unable to load any Haar face detector "
                f"from {CASCADE_DIR}"
            )

    # ========================================================
    # IMAGE VALIDATION
    # ========================================================

    @staticmethod
    def _validate_image(
        image: np.ndarray,
    ) -> None:

        if image is None:

            raise ValueError(
                "Face detector received a None image."
            )

        if not isinstance(
            image,
            np.ndarray,
        ):

            raise TypeError(
                "Face detector expects a NumPy array."
            )

        if image.size == 0:

            raise ValueError(
                "Face detector received an empty image."
            )

    # ========================================================
    # BOX IOU
    # ========================================================

    @staticmethod
    def _iou(
        a: list[int],
        b: list[int],
    ) -> float:

        ax, ay, aw, ah = a
        bx, by, bw, bh = b

        x1 = max(
            ax,
            bx,
        )

        y1 = max(
            ay,
            by,
        )

        x2 = min(
            ax + aw,
            bx + bw,
        )

        y2 = min(
            ay + ah,
            by + bh,
        )

        intersection = (
            max(
                0,
                x2 - x1,
            )
            * max(
                0,
                y2 - y1,
            )
        )

        area_a = aw * ah
        area_b = bw * bh

        union = (
            area_a
            + area_b
            - intersection
        )

        if union <= 0:
            return 0.0

        return (
            intersection
            / union
        )

    # ========================================================
    # DEDUPLICATION
    # ========================================================

    @classmethod
    def _dedupe(
        cls,
        boxes: list[list[int]],
    ) -> list[list[int]]:

        selected: list[
            list[int]
        ] = []

        # Larger faces first.
        boxes = sorted(
            boxes,
            key=lambda box:
                box[2] * box[3],
            reverse=True,
        )

        for box in boxes:

            if len(box) != 4:
                continue

            x, y, w, h = box

            if (
                w <= 0
                or h <= 0
            ):
                continue

            duplicate = False

            for selected_box in selected:

                if (
                    cls._iou(
                        box,
                        selected_box,
                    )
                    >= 0.35
                ):

                    duplicate = True
                    break

            if not duplicate:

                selected.append(
                    box
                )

        return selected

    # ========================================================
    # BOX CLAMPING
    # ========================================================

    @staticmethod
    def _clamp_box(
        box: list[int],
        image_width: int,
        image_height: int,
    ) -> list[int] | None:

        x, y, w, h = box

        if (
            w <= 0
            or h <= 0
        ):
            return None

        x1 = max(
            0,
            min(
                x,
                image_width - 1,
            ),
        )

        y1 = max(
            0,
            min(
                y,
                image_height - 1,
            ),
        )

        x2 = min(
            image_width,
            x + w,
        )

        y2 = min(
            image_height,
            y + h,
        )

        final_w = (
            x2 - x1
        )

        final_h = (
            y2 - y1
        )

        if (
            final_w <= 0
            or final_h <= 0
        ):
            return None

        return [
            x1,
            y1,
            final_w,
            final_h,
        ]

    # ========================================================
    # FACE DETECTION
    # ========================================================

    def detect(
        self,
        image: np.ndarray,
    ) -> list[list[int]]:

        self._validate_image(
            image
        )

        image_height, image_width = (
            image.shape[:2]
        )

        # ----------------------------------------------------
        # Convert to grayscale
        # ----------------------------------------------------

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY,
        )

        # ----------------------------------------------------
        # Mild normalization
        # ----------------------------------------------------

        gray = cv2.equalizeHist(
            gray
        )

        all_faces: list[
            list[int]
        ] = []

        # ----------------------------------------------------
        # Run multiple Haar classifiers
        # ----------------------------------------------------

        for classifier in self.classifiers:

            try:

                faces = (
                    classifier.detectMultiScale(
                        gray,
                        scaleFactor=1.05,
                        minNeighbors=5,
                        minSize=(40, 40),
                    )
                )

            except cv2.error:

                continue

            for face in faces:

                box = [
                    int(face[0]),
                    int(face[1]),
                    int(face[2]),
                    int(face[3]),
                ]

                clamped = (
                    self._clamp_box(
                        box,
                        image_width,
                        image_height,
                    )
                )

                if clamped is not None:

                    all_faces.append(
                        clamped
                    )

        # ----------------------------------------------------
        # Deduplicate
        # ----------------------------------------------------

        faces = self._dedupe(
            all_faces
        )

        # ----------------------------------------------------
        # Largest faces first
        # ----------------------------------------------------

        faces.sort(
            key=lambda box:
                box[2] * box[3],
            reverse=True,
        )

        return faces

    # ========================================================
    # PRIMARY FACE
    # ========================================================

    def extract_primary_face(
        self,
        image: np.ndarray,
    ) -> tuple[
        np.ndarray | None,
        list[dict[str, int]],
    ]:

        self._validate_image(
            image
        )

        faces = self.detect(
            image
        )

        if not faces:

            return (
                None,
                [],
            )

        # Largest detected face.
        x, y, w, h = faces[0]

        # ----------------------------------------------------
        # Add context around face.
        #
        # This context is useful for face tampering analysis.
        # ----------------------------------------------------

        margin = int(
            0.20
            * max(
                w,
                h,
            )
        )

        x0 = max(
            0,
            x - margin,
        )

        y0 = max(
            0,
            y - margin,
        )

        x1 = min(
            image.shape[1],
            x + w + margin,
        )

        y1 = min(
            image.shape[0],
            y + h + margin,
        )

        crop = image[
            y0:y1,
            x0:x1,
        ].copy()

        if crop.size == 0:

            return (
                None,
                [],
            )

        return (
            crop,
            [
                {
                    "x": int(x),
                    "y": int(y),
                    "w": int(w),
                    "h": int(h),
                }
            ],
        )