# app/services/file_validator.py

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


# ============================================================
# ALLOWED IMAGE TYPES
# ============================================================

ALLOWED_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".bmp",
    ".tif",
    ".tiff",
}

ALLOWED_MIME_PREFIXES = {
    "image/",
}


# ============================================================
# RESULT
# ============================================================

@dataclass
class ValidatedFile:
    data: bytes
    extension: str
    width: int
    height: int
    channels: int


# ============================================================
# ERROR
# ============================================================

class FileValidationError(ValueError):
    pass


# ============================================================
# IMAGE VALIDATION
# ============================================================

def validate_image_bytes(
    data: bytes,
    filename: str,
    content_type: str | None,
    max_bytes: int,
) -> ValidatedFile:
    """
    Validate that the uploaded input is a readable image.

    IMPORTANT:

        This function validates the upload itself.

        It does NOT attempt to determine whether the document
        is genuine, forged, AI-generated, edited, or tampered.

        Cropping, recompression, screenshots, and other image
        characteristics are intentionally handled later by
        the image-quality and forensic layers.
    """

    # ========================================================
    # 1. EMPTY FILE
    # ========================================================

    if not data:

        raise FileValidationError(
            "Uploaded file is empty."
        )

    # ========================================================
    # 2. FILE SIZE
    # ========================================================

    if len(data) > max_bytes:

        limit_mb = (
            max_bytes
            / (1024 * 1024)
        )

        raise FileValidationError(
            f"File exceeds the {limit_mb:.1f} MB limit."
        )

    # ========================================================
    # 3. EXTENSION
    # ========================================================

    extension = Path(
        filename or ""
    ).suffix.lower()

    if extension not in ALLOWED_EXTENSIONS:

        raise FileValidationError(
            "Unsupported extension: "
            f"{extension or 'none'}"
        )

    # ========================================================
    # 4. MIME TYPE
    # ========================================================

    if content_type:

        normalized_mime = (
            content_type
            .strip()
            .lower()
        )

        if not any(
            normalized_mime.startswith(
                prefix
            )
            for prefix in ALLOWED_MIME_PREFIXES
        ):

            raise FileValidationError(
                "Unsupported content type: "
                f"{content_type}"
            )

    # ========================================================
    # 5. DECODE IMAGE
    # ========================================================

    buffer = np.frombuffer(
        data,
        dtype=np.uint8,
    )

    image = cv2.imdecode(
        buffer,
        cv2.IMREAD_COLOR,
    )

    if image is None:

        raise FileValidationError(
            "The uploaded file is not a readable image."
        )

    # ========================================================
    # 6. IMAGE DIMENSIONS
    # ========================================================

    if image.ndim != 3:

        raise FileValidationError(
            "The uploaded image does not have a valid "
            "color-image representation."
        )

    height, width = (
        image.shape[:2]
    )

    channels = (
        image.shape[2]
    )

    # ========================================================
    # 7. MINIMUM SIZE
    # ========================================================

    if (
        width < 300
        or height < 200
    ):

        raise FileValidationError(
            "Image is too small for reliable document analysis."
        )

    # ========================================================
    # 8. MAXIMUM DIMENSIONS
    # ========================================================

    if (
        width > 10000
        or height > 10000
    ):

        raise FileValidationError(
            "Image dimensions are too large."
        )

    # ========================================================
    # 9. RETURN
    # ========================================================

    return ValidatedFile(
        data=data,
        extension=extension,
        width=width,
        height=height,
        channels=channels,
    )