# app/services/ocr_service.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import cv2
import numpy as np
import pytesseract
from pytesseract import Output


# ============================================================
# OCR WORD
# ============================================================

@dataclass
class OCRWord:
    """
    One OCR-recognized word and its location.

    Coordinates are stored in the OCR image coordinate system.
    """

    text: str

    x: int
    y: int
    w: int
    h: int

    confidence: float

    block_num: int = 0
    par_num: int = 0
    line_num: int = 0
    word_num: int = 0


# ============================================================
# OCR RESULT
# ============================================================

@dataclass
class OCRResult:
    """
    Complete OCR result.
    """

    text: str

    confidence: float

    word_confidences: list[float] = field(
        default_factory=list
    )

    words: list[OCRWord] = field(
        default_factory=list
    )

    psm: int = 6

    variant: str = "grayscale"

    scale: float = 2.0


# ============================================================
# IMAGE PREPROCESSING
# ============================================================

def _to_gray(
    image: np.ndarray,
) -> np.ndarray:

    if image is None:
        raise ValueError(
            "OCR received a None image."
        )

    if not isinstance(
        image,
        np.ndarray,
    ):
        raise TypeError(
            "OCR image must be a NumPy array."
        )

    if image.size == 0:
        raise ValueError(
            "OCR received an empty image."
        )

    if image.ndim == 2:

        gray = image.copy()

    elif (
        image.ndim == 3
        and image.shape[2] == 3
    ):

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY,
        )

    elif (
        image.ndim == 3
        and image.shape[2] == 4
    ):

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGRA2GRAY,
        )

    else:

        raise ValueError(
            f"Unsupported image shape for OCR: {image.shape}"
        )

    return gray


def _prepare_variants(
    image: np.ndarray,
    scale: float = 2.0,
) -> list[
    tuple[str, np.ndarray]
]:

    gray = _to_gray(
        image
    )

    # --------------------------------------------------------
    # Upscale
    # --------------------------------------------------------

    if scale != 1.0:

        gray = cv2.resize(
            gray,
            None,
            fx=scale,
            fy=scale,
            interpolation=cv2.INTER_CUBIC,
        )

    variants: list[
        tuple[str, np.ndarray]
    ] = []

    # --------------------------------------------------------
    # 1. Grayscale
    # --------------------------------------------------------

    variants.append(
        (
            "grayscale",
            gray,
        )
    )

    # --------------------------------------------------------
    # 2. CLAHE
    # --------------------------------------------------------

    clahe = cv2.createCLAHE(
        clipLimit=2.0,
        tileGridSize=(8, 8),
    )

    clahe_img = clahe.apply(
        gray
    )

    variants.append(
        (
            "clahe",
            clahe_img,
        )
    )

    # --------------------------------------------------------
    # 3. OTSU
    # --------------------------------------------------------

    _, otsu = cv2.threshold(
        gray,
        0,
        255,
        cv2.THRESH_BINARY
        + cv2.THRESH_OTSU,
    )

    variants.append(
        (
            "otsu",
            otsu,
        )
    )

    # --------------------------------------------------------
    # 4. Adaptive threshold
    # --------------------------------------------------------

    adaptive = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        11,
    )

    variants.append(
        (
            "adaptive",
            adaptive,
        )
    )

    # --------------------------------------------------------
    # 5. Mild denoise + CLAHE
    # --------------------------------------------------------

    denoised = cv2.GaussianBlur(
        gray,
        (3, 3),
        0,
    )

    denoised_clahe = clahe.apply(
        denoised
    )

    variants.append(
        (
            "denoised_clahe",
            denoised_clahe,
        )
    )

    return variants


# ============================================================
# SAFE INTEGER
# ============================================================

def _safe_int(
    values,
    index: int,
) -> int:

    try:

        return int(
            values[index]
        )

    except (
        IndexError,
        TypeError,
        ValueError,
    ):

        return 0


# ============================================================
# VALID OCR BOX
# ============================================================

def _validate_box(
    x: int,
    y: int,
    w: int,
    h: int,
    image_width: int,
    image_height: int,
) -> Optional[
    tuple[int, int, int, int]
]:

    # Ignore empty boxes.
    if w <= 0 or h <= 0:
        return None

    # Ignore impossible coordinates.
    if x < 0 or y < 0:
        return None

    # --------------------------------------------------------
    # Clamp right/bottom to the actual OCR image.
    # --------------------------------------------------------

    x1 = min(
        max(
            x,
            0,
        ),
        max(
            image_width - 1,
            0,
        ),
    )

    y1 = min(
        max(
            y,
            0,
        ),
        max(
            image_height - 1,
            0,
        ),
    )

    x2 = min(
        x + w,
        image_width,
    )

    y2 = min(
        y + h,
        image_height,
    )

    if x2 <= x1 or y2 <= y1:
        return None

    final_w = x2 - x1
    final_h = y2 - y1

    # --------------------------------------------------------
    # Reject absurdly large single-word boxes.
    #
    # A Tesseract "word" should not normally occupy almost
    # the entire page. This protects downstream field-region
    # analysis from corrupted geometry.
    # --------------------------------------------------------

    if final_w > image_width * 0.80:
        return None

    if final_h > image_height * 0.30:
        return None

    return (
        x1,
        y1,
        final_w,
        final_h,
    )


# ============================================================
# OCR PASS
# ============================================================

def _run_pass(
    image: np.ndarray,
    psm: int,
    variant_name: str,
    scale: float,
) -> OCRResult:

    config = (
        f"--oem 3 --psm {psm}"
    )

    data = (
        pytesseract.image_to_data(
            image,
            output_type=Output.DICT,
            config=config,
            lang="eng",
        )
    )

    texts = data.get(
        "text",
        [],
    )

    confs = data.get(
        "conf",
        [],
    )

    lefts = data.get(
        "left",
        [],
    )

    tops = data.get(
        "top",
        [],
    )

    widths = data.get(
        "width",
        [],
    )

    heights = data.get(
        "height",
        [],
    )

    block_nums = data.get(
        "block_num",
        [],
    )

    par_nums = data.get(
        "par_num",
        [],
    )

    line_nums = data.get(
        "line_num",
        [],
    )

    word_nums = data.get(
        "word_num",
        [],
    )

    image_height, image_width = (
        image.shape[:2]
    )

    words: list[OCRWord] = []

    valid_confidences: list[
        float
    ] = []

    max_len = len(
        texts
    )

    for i in range(
        max_len
    ):

        raw_text = (
            texts[i]
            if i < len(texts)
            else ""
        )

        text = str(
            raw_text
            or ""
        ).strip()

        if not text:
            continue

        # ----------------------------------------------------
        # Confidence
        # ----------------------------------------------------

        try:

            raw_confidence = float(
                confs[i]
            )

        except (
            IndexError,
            TypeError,
            ValueError,
        ):

            raw_confidence = -1.0

        if (
            raw_confidence < 0
            or raw_confidence > 100
        ):
            continue

        # ----------------------------------------------------
        # Bounding box
        # ----------------------------------------------------

        try:

            x = int(
                lefts[i]
            )

            y = int(
                tops[i]
            )

            w = int(
                widths[i]
            )

            h = int(
                heights[i]
            )

        except (
            IndexError,
            TypeError,
            ValueError,
        ):

            continue

        valid_box = _validate_box(
            x,
            y,
            w,
            h,
            image_width,
            image_height,
        )

        if valid_box is None:
            continue

        (
            x,
            y,
            w,
            h,
        ) = valid_box

        # ----------------------------------------------------
        # Hierarchy
        # ----------------------------------------------------

        block_num = _safe_int(
            block_nums,
            i,
        )

        par_num = _safe_int(
            par_nums,
            i,
        )

        line_num = _safe_int(
            line_nums,
            i,
        )

        word_num = _safe_int(
            word_nums,
            i,
        )

        # ----------------------------------------------------
        # Confidence normalized to [0,1]
        # ----------------------------------------------------

        normalized_confidence = max(
            0.0,
            min(
                1.0,
                raw_confidence / 100.0,
            ),
        )

        # ----------------------------------------------------
        # Store word
        # ----------------------------------------------------

        words.append(
            OCRWord(
                text=text,
                x=x,
                y=y,
                w=w,
                h=h,
                confidence=round(
                    normalized_confidence,
                    4,
                ),
                block_num=block_num,
                par_num=par_num,
                line_num=line_num,
                word_num=word_num,
            )
        )

        valid_confidences.append(
            raw_confidence
        )

    # ========================================================
    # Sort words geographically
    # ========================================================

    words.sort(
        key=lambda word: (
            word.block_num,
            word.par_num,
            word.line_num,
            word.word_num,
            word.y,
            word.x,
        )
    )

    # ========================================================
    # Combined text
    # ========================================================

    combined_text = " ".join(
        word.text
        for word in words
    ).strip()

    # ========================================================
    # Average confidence
    # ========================================================

    if valid_confidences:

        average_confidence = (
            float(
                np.mean(
                    valid_confidences
                )
            )
            / 100.0
        )

    else:

        average_confidence = 0.0

    return OCRResult(
        text=combined_text,

        confidence=round(
            float(
                np.clip(
                    average_confidence,
                    0.0,
                    1.0,
                )
            ),
            4,
        ),

        word_confidences=[
            float(
                value
            )
            for value in valid_confidences
        ],

        words=words,

        psm=psm,

        variant=variant_name,

        scale=scale,
    )


# ============================================================
# RESULT SCORING
# ============================================================

def _candidate_score(
    result: OCRResult,
) -> float:
    """
    Score an OCR candidate.

    Confidence has the highest weight.
    Text quantity and word count provide smaller bonuses.

    Geometry validity is already enforced while generating
    the result.
    """

    text = result.text.strip()

    if not text:
        return 0.0

    character_count = len(
        text
    )

    word_count = len(
        result.words
    )

    char_bonus = min(
        character_count / 250.0,
        1.0,
    )

    word_bonus = min(
        word_count / 50.0,
        1.0,
    )

    score = (
        result.confidence * 0.75
        + char_bonus * 0.15
        + word_bonus * 0.10
    )

    return float(
        np.clip(
            score,
            0.0,
            1.0,
        )
    )


# ============================================================
# DEDUPLICATION
# ============================================================

def _deduplicate_words(
    words: list[OCRWord],
) -> list[OCRWord]:

    seen: set[
        tuple
    ] = set()

    output: list[
        OCRWord
    ] = []

    for word in words:

        key = (
            word.text.lower(),
            word.x,
            word.y,
            word.w,
            word.h,
        )

        if key in seen:
            continue

        seen.add(
            key
        )

        output.append(
            word
        )

    return output


# ============================================================
# MAIN OCR FUNCTION
# ============================================================

def run_ocr(
    image: np.ndarray,
    tesseract_cmd: str = "tesseract",
) -> OCRResult:

    # --------------------------------------------------------
    # Configure Tesseract
    # --------------------------------------------------------

    pytesseract.pytesseract.tesseract_cmd = (
        tesseract_cmd
    )

    # --------------------------------------------------------
    # OCR scale
    # --------------------------------------------------------

    scale = 2.0

    # --------------------------------------------------------
    # Generate variants
    # --------------------------------------------------------

    variants = _prepare_variants(
        image,
        scale=scale,
    )

    candidates: list[
        OCRResult
    ] = []

    # --------------------------------------------------------
    # OCR layouts
    # --------------------------------------------------------

    psms = (
        6,
        11,
        12,
    )

    # --------------------------------------------------------
    # Run all combinations
    # --------------------------------------------------------

    for (
        variant_name,
        variant,
    ) in variants:

        for psm in psms:

            try:

                result = _run_pass(
                    image=variant,
                    psm=psm,
                    variant_name=variant_name,
                    scale=scale,
                )

                if result.words:

                    candidates.append(
                        result
                    )

            except Exception:

                # One OCR pass failing should not stop the
                # entire verification pipeline.
                continue

    # --------------------------------------------------------
    # No OCR result
    # --------------------------------------------------------

    if not candidates:

        return OCRResult(
            text="",
            confidence=0.0,
            word_confidences=[],
            words=[],
            psm=6,
            variant="none",
            scale=scale,
        )

    # --------------------------------------------------------
    # Select best candidate
    # --------------------------------------------------------

    best = max(
        candidates,
        key=_candidate_score,
    )

    # --------------------------------------------------------
    # Remove duplicate words
    # --------------------------------------------------------

    best.words = _deduplicate_words(
        best.words
    )

    # --------------------------------------------------------
    # Final geographic ordering
    # --------------------------------------------------------

    best.words.sort(
        key=lambda word: (
            word.block_num,
            word.par_num,
            word.line_num,
            word.word_num,
            word.y,
            word.x,
        )
    )

    # --------------------------------------------------------
    # Rebuild text
    # --------------------------------------------------------

    best.text = " ".join(
        word.text
        for word in best.words
    ).strip()

    return best