# app/services/cross_validator.py

from __future__ import annotations

import re
from typing import Any


# ============================================================
# NORMALIZATION
# ============================================================

def norm(
    value: Any,
) -> str:
    """
    Normalize a value for comparison.

    This is only used for reference-data comparison.
    It does not validate document formats.
    """

    if value is None:
        return ""

    value = str(
        value
    ).upper()

    return re.sub(
        r"[^A-Z0-9]",
        "",
        value,
    )


def _normalize_name(
    value: Any,
) -> str:
    """
    Normalize a person's name for comparison.
    """

    return norm(
        value
    )


def _normalize_date(
    value: Any,
) -> str:
    """
    Normalize a date-like value for comparison.

    We intentionally remove separators so:

        15/07/2005
        15-07-2005
        15.07.2005

    can compare consistently.
    """

    return re.sub(
        r"[^0-9]",
        "",
        str(
            value or ""
        ),
    )


# ============================================================
# NAME SIMILARITY
# ============================================================

def name_similar(
    a: Any,
    b: Any,
) -> bool | None:
    """
    Compare two names with conservative OCR tolerance.

    Examples:

        "Aayush Jangid"
        "AAYUSH JANGID"

    -> True

    This function does not perform identity verification.
    It only compares supplied reference text to extracted text.
    """

    a_norm = _normalize_name(
        a
    )

    b_norm = _normalize_name(
        b
    )

    if not a_norm or not b_norm:
        return None

    if a_norm == b_norm:
        return True

    # --------------------------------------------------------
    # Exact substring tolerance.
    # Useful for OCR spacing differences or minor punctuation.
    # --------------------------------------------------------

    if (
        a_norm in b_norm
        or b_norm in a_norm
    ):
        return True

    # --------------------------------------------------------
    # Token-based comparison
    # --------------------------------------------------------

    a_words = [
        word
        for word in re.findall(
            r"[A-Z]+",
            str(
                a or ""
            ).upper(),
        )
        if word
    ]

    b_words = [
        word
        for word in re.findall(
            r"[A-Z]+",
            str(
                b or ""
            ).upper(),
        )
        if word
    ]

    if not a_words or not b_words:
        return False

    # Same number of words and same normalized tokens.
    if len(a_words) == len(b_words):

        matched = sum(
            1
            for left, right in zip(
                a_words,
                b_words,
            )
            if (
                left == right
                or left in right
                or right in left
            )
        )

        if matched == len(a_words):
            return True

    return False


# ============================================================
# GENERIC EXACT COMPARISON
# ============================================================

def _exact_match(
    reference_value: Any,
    extracted_value: Any,
) -> bool | None:

    reference_normalized = norm(
        reference_value
    )

    extracted_normalized = norm(
        extracted_value
    )

    if (
        not reference_normalized
        or not extracted_normalized
    ):
        return None

    return (
        reference_normalized
        == extracted_normalized
    )


def _date_match(
    reference_value: Any,
    extracted_value: Any,
) -> bool | None:

    reference_normalized = _normalize_date(
        reference_value
    )

    extracted_normalized = _normalize_date(
        extracted_value
    )

    if (
        not reference_normalized
        or not extracted_normalized
    ):
        return None

    return (
        reference_normalized
        == extracted_normalized
    )


# ============================================================
# MAIN CROSS VALIDATION
# ============================================================

def compare(
    fields: dict,
    reference: Any,
) -> dict:
    """
    Compare extracted fields against optional reference data.

    IMPORTANT:

        - Reference data is optional.
        - Missing extracted fields are NOT automatically treated
          as mismatches.
        - Only fields present on BOTH sides are compared.
        - This does not validate document type or document format.
        - A reference mismatch is evidence, not automatic proof
          of forgery.
    """

    fields = fields or {}

    # ========================================================
    # NO REFERENCE DATA
    # ========================================================

    if not reference:

        return {
            "attempted": False,

            "name_match": None,

            "dob_match": None,

            "document_number_match": None,

            "match_score": 0.0,

            "messages": [],
        }

    checks: dict[
        str,
        bool,
    ] = {}

    messages: list[
        str
    ] = []

    # ========================================================
    # NAME
    # ========================================================

    reference_name = getattr(
        reference,
        "name",
        None,
    )

    extracted_name = fields.get(
        "name"
    )

    if (
        reference_name
        and extracted_name
    ):

        result = name_similar(
            reference_name,
            extracted_name,
        )

        if result is not None:

            checks[
                "name"
            ] = result

    # ========================================================
    # DOB
    # ========================================================

    reference_dob = getattr(
        reference,
        "dob",
        None,
    )

    extracted_dob = fields.get(
        "dob"
    )

    if (
        reference_dob
        and extracted_dob
    ):

        result = _date_match(
            reference_dob,
            extracted_dob,
        )

        if result is not None:

            checks[
                "dob"
            ] = result

    # ========================================================
    # DOCUMENT NUMBER
    # ========================================================

    reference_document_number = (
        getattr(
            reference,
            "document_number",
            None,
        )
    )

    extracted_document_number = (
        fields.get(
            "document_number"
        )
    )

    if (
        reference_document_number
        and extracted_document_number
    ):

        result = _exact_match(
            reference_document_number,
            extracted_document_number,
        )

        if result is not None:

            checks[
                "document_number"
            ] = result

    # ========================================================
    # NOTHING COMPARABLE
    # ========================================================

    if not checks:

        messages.append(
            "Reference data was supplied, but none of the "
            "reference fields could be compared with extracted "
            "document fields."
        )

        return {
            "attempted": True,

            "name_match": None,

            "dob_match": None,

            "document_number_match": None,

            "match_score": 0.0,

            "messages": messages,
        }

    # ========================================================
    # MATCH SCORE
    # ========================================================

    matches = [
        value
        for value in checks.values()
        if value is not None
    ]

    match_score = (
        sum(
            1
            for value in matches
            if value
        )
        / len(matches)
    )

    # ========================================================
    # MISMATCH MESSAGES
    # ========================================================

    for field_name, matched in checks.items():

        if not matched:

            pretty_name = (
                field_name
                .replace(
                    "_",
                    " ",
                )
                .title()
            )

            messages.append(
                f"{pretty_name} does not match "
                "the supplied reference data."
            )

    # ========================================================
    # PARTIAL REFERENCE
    # ========================================================

    if len(checks) < 3:

        messages.append(
            "Cross-validation was performed only on the "
            "reference fields that were available and "
            "successfully extracted."
        )

    # ========================================================
    # RETURN
    # ========================================================

    return {
        "attempted": True,

        "name_match": checks.get(
            "name"
        ),

        "dob_match": checks.get(
            "dob"
        ),

        "document_number_match": checks.get(
            "document_number"
        ),

        "match_score": round(
            float(
                match_score
            ),
            4,
        ),

        "messages": messages,
    }