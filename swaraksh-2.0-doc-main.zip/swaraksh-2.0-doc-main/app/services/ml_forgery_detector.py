# app/services/ml_forgery_detector.py

from __future__ import annotations

import io
from dataclasses import dataclass
from typing import Any

import numpy as np
from PIL import Image, ImageChops


# ============================================================
# OPTIONAL ML IMPORTS
# ============================================================

try:
    import torch
    import torch.nn.functional as F
    from transformers import (
        ViTImageProcessor,
        ViTForImageClassification,
    )

    TORCH_AVAILABLE = True

except ImportError:
    torch = None
    F = None
    ViTImageProcessor = None
    ViTForImageClassification = None
    TORCH_AVAILABLE = False


# ============================================================
# MODEL CONFIGURATION
# ============================================================

MODEL_NAME = (
    "zodumair/document-forgery-detector"
)


# ============================================================
# RESULT OBJECT
# ============================================================

@dataclass
class MLForgeryResult:
    """
    Result produced by the pretrained document forgery model.

    This is document-level classification evidence.

    It does NOT identify the exact pixels or field that was
    edited.
    """

    available: bool

    label: str

    confidence: float

    forged_probability: float

    real_probability: float

    model: str

    note: str


# ============================================================
# MODEL WRAPPER
# ============================================================

class DocumentForgeryModel:
    """
    Lazy-loaded pretrained document forgery detector.

    The model is loaded only when the first prediction is
    requested.
    """

    def __init__(
        self,
        model_name: str = MODEL_NAME,
    ) -> None:

        self.model_name = model_name

        self.processor: Any = None

        self.model: Any = None

        self.device = "cpu"

        self._load_error: str | None = None

        self._load_attempted = False

    # ========================================================
    # MODEL LOADING
    # ========================================================

    def _load(self) -> None:
        """
        Load the Hugging Face ViT model once.

        The model repository currently documents loading with
        ViTImageProcessor and ViTForImageClassification.
        """

        if self.model is not None:
            return

        if self._load_attempted:
            return

        self._load_attempted = True

        if not TORCH_AVAILABLE:

            self._load_error = (
                "PyTorch or Transformers is not installed."
            )

            return

        try:

            # ------------------------------------------------
            # Select device
            # ------------------------------------------------

            if torch.cuda.is_available():

                self.device = "cuda"

            else:

                self.device = "cpu"

            # ------------------------------------------------
            # Processor
            # ------------------------------------------------

            self.processor = (
                ViTImageProcessor.from_pretrained(
                    self.model_name
                )
            )

            # ------------------------------------------------
            # Model
            # ------------------------------------------------

            self.model = (
                ViTForImageClassification.from_pretrained(
                    self.model_name
                )
            )

            # ------------------------------------------------
            # Move model to selected device
            # ------------------------------------------------

            self.model.to(
                self.device
            )

            self.model.eval()

            # ------------------------------------------------
            # Clear previous error
            # ------------------------------------------------

            self._load_error = None

        except Exception as exc:

            self.processor = None

            self.model = None

            self._load_error = (
                f"{type(exc).__name__}: {exc}"
            )

    # ========================================================
    # ELA
    # ========================================================

    @staticmethod
    def _compute_ela(
        image: Image.Image,
        quality: int = 90,
        scale: float = 15.0,
    ) -> Image.Image:
        """
        Generate an Error Level Analysis image.

        This follows the preprocessing described by the model
        repository's model card.
        """

        original = image.convert(
            "RGB"
        )

        buffer = io.BytesIO()

        original.save(
            buffer,
            format="JPEG",
            quality=quality,
        )

        buffer.seek(0)

        recompressed = Image.open(
            buffer
        ).convert(
            "RGB"
        )

        ela = ImageChops.difference(
            original,
            recompressed,
        )

        extrema = ela.getextrema()

        max_diff = max(
            channel[1]
            for channel in extrema
        )

        if max_diff <= 0:
            max_diff = 1

        def scale_pixel(
            pixel: int,
        ) -> int:

            scaled = int(
                pixel
                * (
                    255.0
                    / max_diff
                )
                * (
                    scale
                    / 10.0
                )
            )

            return max(
                0,
                min(
                    255,
                    scaled,
                ),
            )

        ela = ela.point(
            scale_pixel
        )

        return ela

    # ========================================================
    # LABEL NORMALIZATION
    # ========================================================

    @staticmethod
    def _label_type(
        label: str,
    ) -> str:
        """
        Normalize model class labels into:

            real
            forged
            unknown
        """

        normalized = str(
            label
        ).strip().lower()

        # Forgery-related labels.
        if any(
            token in normalized
            for token in (
                "forged",
                "forge",
                "fake",
                "tampered",
                "tamper",
            )
        ):

            return "forged"

        # Real-related labels.
        if any(
            token in normalized
            for token in (
                "real",
                "genuine",
                "authentic",
            )
        ):

            return "real"

        return "unknown"

    # ========================================================
    # CLASS PROBABILITY EXTRACTION
    # ========================================================

    def _extract_class_probabilities(
        self,
        probabilities,
    ) -> tuple[
        float,
        float,
        str,
        float,
    ]:
        """
        Convert model probabilities into:

            real probability
            forged probability
            predicted label
            predicted confidence
        """

        labels = (
            self.model.config.id2label
            or {}
        )

        predicted_index = int(
            torch.argmax(
                probabilities
            ).item()
        )

        predicted_confidence = float(
            probabilities[
                predicted_index
            ].item()
        )

        predicted_raw_label = str(
            labels.get(
                predicted_index,
                str(predicted_index),
            )
        )

        predicted_type = (
            self._label_type(
                predicted_raw_label
            )
        )

        real_probability = 0.0

        forged_probability = 0.0

        # ----------------------------------------------------
        # Normal case: labels are descriptive.
        # ----------------------------------------------------

        for index, probability in enumerate(
            probabilities
        ):

            raw_label = str(
                labels.get(
                    index,
                    str(index),
                )
            )

            label_type = (
                self._label_type(
                    raw_label
                )
            )

            value = float(
                probability.item()
            )

            if label_type == "real":

                real_probability = max(
                    real_probability,
                    value,
                )

            elif label_type == "forged":

                forged_probability = max(
                    forged_probability,
                    value,
                )

        # ----------------------------------------------------
        # If the model has labels that we can't interpret,
        # use the actual predicted class rather than silently
        # claiming 0.0 forgery probability.
        #
        # We don't invent class semantics here.
        # ----------------------------------------------------

        if (
            real_probability == 0.0
            and forged_probability == 0.0
        ):

            if predicted_type == "real":

                real_probability = (
                    predicted_confidence
                )

            elif predicted_type == "forged":

                forged_probability = (
                    predicted_confidence
                )

        # ----------------------------------------------------
        # Human-readable label.
        # ----------------------------------------------------

        if predicted_type == "real":

            label = "real"

        elif predicted_type == "forged":

            label = "forged"

        else:

            label = predicted_raw_label

        return (
            real_probability,
            forged_probability,
            label,
            predicted_confidence,
        )

    # ========================================================
    # PREDICTION
    # ========================================================

    def predict(
        self,
        image: np.ndarray,
    ) -> MLForgeryResult:
        """
        Run document-level forgery classification.
        """

        # ----------------------------------------------------
        # Load model
        # ----------------------------------------------------

        self._load()

        if (
            self.model is None
            or self.processor is None
        ):

            return MLForgeryResult(
                available=False,
                label="unavailable",
                confidence=0.0,
                forged_probability=0.0,
                real_probability=0.0,
                model=self.model_name,
                note=(
                    "Pretrained forgery model could not "
                    f"be loaded: "
                    f"{self._load_error or 'unknown error'}"
                ),
            )

        # ----------------------------------------------------
        # Validate image
        # ----------------------------------------------------

        if (
            image is None
            or not isinstance(
                image,
                np.ndarray,
            )
            or image.size == 0
        ):

            return MLForgeryResult(
                available=False,
                label="unavailable",
                confidence=0.0,
                forged_probability=0.0,
                real_probability=0.0,
                model=self.model_name,
                note=(
                    "No valid image was supplied to "
                    "the pretrained forgery model."
                ),
            )

        try:

            # =================================================
            # OpenCV BGR -> RGB
            # =================================================

            if image.ndim == 2:

                rgb = np.stack(
                    [
                        image,
                        image,
                        image,
                    ],
                    axis=-1,
                )

            elif (
                image.ndim == 3
                and image.shape[2] >= 3
            ):

                rgb = cv2_bgr_to_rgb(
                    image
                )

            else:

                return MLForgeryResult(
                    available=False,
                    label="unavailable",
                    confidence=0.0,
                    forged_probability=0.0,
                    real_probability=0.0,
                    model=self.model_name,
                    note=(
                        "Unsupported image shape was supplied "
                        "to the pretrained forgery model."
                    ),
                )

            # =================================================
            # Convert to PIL
            # =================================================

            pil_image = Image.fromarray(
                rgb
            ).convert(
                "RGB"
            )

            # =================================================
            # ELA
            # =================================================

            ela = self._compute_ela(
                pil_image
            )

            # =================================================
            # Blend original + ELA
            # =================================================

            blended = Image.blend(
                pil_image,
                ela,
                alpha=0.3,
            )

            # =================================================
            # Processor
            # =================================================

            inputs = self.processor(
                images=blended,
                return_tensors="pt",
            )

            inputs = {
                key: value.to(
                    self.device
                )
                for key, value in inputs.items()
            }

            # =================================================
            # Inference
            # =================================================

            with torch.no_grad():

                outputs = self.model(
                    **inputs
                )

                probabilities = (
                    F.softmax(
                        outputs.logits,
                        dim=-1,
                    )[0]
                )

            # =================================================
            # Extract prediction
            # =================================================

            (
                real_probability,
                forged_probability,
                label,
                confidence,
            ) = self._extract_class_probabilities(
                probabilities
            )

            return MLForgeryResult(
                available=True,

                label=label,

                confidence=round(
                    confidence,
                    4,
                ),

                forged_probability=round(
                    forged_probability,
                    4,
                ),

                real_probability=round(
                    real_probability,
                    4,
                ),

                model=self.model_name,

                note=(
                    "Document-level pretrained ML evidence. "
                    "The model predicts a document-level "
                    "real/forged class and does not localize "
                    "the exact edited field. Use this result "
                    "with OCR-region and image-forensics evidence."
                ),
            )

        except Exception as exc:

            return MLForgeryResult(
                available=False,

                label="error",

                confidence=0.0,

                forged_probability=0.0,

                real_probability=0.0,

                model=self.model_name,

                note=(
                    "Pretrained model inference failed: "
                    f"{type(exc).__name__}: {exc}"
                ),
            )


# ============================================================
# OPENCV COLOR CONVERSION
# ============================================================

def cv2_bgr_to_rgb(
    image: np.ndarray,
) -> np.ndarray:
    """
    Convert BGR OpenCV image to RGB without importing cv2 at
    module import time.
    """

    import cv2

    return cv2.cvtColor(
        image,
        cv2.COLOR_BGR2RGB,
    )


# ============================================================
# SINGLETON
# ============================================================

_model = DocumentForgeryModel()


# ============================================================
# PUBLIC API
# ============================================================

def analyze(
    image: np.ndarray,
) -> dict:
    """
    Public API used by document_integrity.py.
    """

    result = _model.predict(
        image
    )

    return {
        "available": result.available,

        "label": result.label,

        "confidence": result.confidence,

        "forged_probability": (
            result.forged_probability
        ),

        "real_probability": (
            result.real_probability
        ),

        "model": result.model,

        "note": result.note,
    }