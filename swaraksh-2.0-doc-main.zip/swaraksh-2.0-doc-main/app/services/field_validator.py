# app/services/field_validator.py

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional


# ============================================================
# DATE PATTERNS
# ============================================================

DATE_PATTERNS = [
    re.compile(
        r"\b\d{2}[/-]\d{2}[/-]\d{4}\b"
    ),

    re.compile(
        r"\b\d{4}[/-]\d{2}[/-]\d{2}\b"
    ),

    re.compile(
        r"\b\d{1,2}[./-]\d{1,2}[./-]\d{4}\b"
    ),

    re.compile(
        r"\b(?:"
        r"jan(?:uary)?|"
        r"feb(?:ruary)?|"
        r"mar(?:ch)?|"
        r"apr(?:il)?|"
        r"may|"
        r"jun(?:e)?|"
        r"jul(?:y)?|"
        r"aug(?:ust)?|"
        r"sep(?:tember)?|"
        r"oct(?:ober)?|"
        r"nov(?:ember)?|"
        r"dec(?:ember)?"
        r")"
        r"\s+\d{1,2}"
        r"(?:,)?"
        r"\s+\d{4}\b",
        re.IGNORECASE,
    ),
]


DATE_FORMATS = (
    "%d/%m/%Y",
    "%d-%m-%Y",
    "%d.%m.%Y",

    "%Y/%m/%d",
    "%Y-%m-%d",
    "%Y.%m.%d",

    "%B %d, %Y",
    "%B %d %Y",
    "%b %d, %Y",
    "%b %d %Y",
)


# ============================================================
# COMMON OCR / LABEL WORDS
# ============================================================

FIELD_LABEL_WORDS = {
    "name",
    "full",
    "holder",
    "holders",
    "signature",
    "date",
    "birth",
    "dob",
    "blood",
    "group",
    "organ",
    "donor",
    "address",
    "issue",
    "issued",
    "validity",
    "valid",
    "validity",
    "father",
    "son",
    "daughter",
    "wife",
    "course",
    "program",
    "programme",
    "certificate",
    "number",
    "no",
    "id",
    "license",
    "licence",
    "passport",
    "aadhaar",
}


# ============================================================
# BASIC HELPERS
# ============================================================

def clean_text(
    value: Optional[str],
) -> str:
    """
    Normalize OCR-derived text.
    """

    if not value:
        return ""

    value = str(value)

    value = re.sub(
        r"\s+",
        " ",
        value,
    )

    return value.strip()


def normalize_name(
    value: Optional[str],
) -> str:
    """
    Normalize a potential person name.

    This is sanity checking only.
    It is NOT identity verification.
    """

    if not value:
        return ""

    value = str(value).upper()

    value = re.sub(
        r"[^A-Z.'\- ]",
        "",
        value,
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    )

    return value.strip()


# ============================================================
# DATE HELPERS
# ============================================================

def extract_date_from_value(
    value: Optional[str],
) -> Optional[str]:
    """
    Extract only a date-looking value from OCR text.

    Example:

        "31/08/2005 some OCR noise"

    becomes:

        "31/08/2005"
    """

    if not value:
        return None

    value = str(value)

    for pattern in DATE_PATTERNS:

        match = pattern.search(
            value
        )

        if match:
            return match.group(0)

    return None


def parse_date(
    value: Optional[str],
) -> Optional[date]:
    """
    Parse an OCR-extracted date.
    """

    clean_value = (
        extract_date_from_value(
            value
        )
    )

    if not clean_value:
        return None

    clean_value = (
        clean_value
        .strip()
        .rstrip(".")
    )

    for fmt in DATE_FORMATS:

        try:

            return datetime.strptime(
                clean_value,
                fmt,
            ).date()

        except ValueError:

            continue

    return None


# ============================================================
# CONTENT QUALITY
# ============================================================

def calculate_content_quality(
    fields: dict,
    raw_text: str = "",
) -> float:
    """
    Estimate how much useful structured information exists.

    This measures extraction quality, NOT authenticity.
    """

    field_names = (
        "name",
        "dob",
        "document_number",
        "issue_date",
        "certificate_id",
        "course",
        "issuer",
    )

    populated_fields = [
        field_name
        for field_name in field_names
        if fields.get(
            field_name
        )
        and str(
            fields.get(
                field_name
            )
        ).strip()
    ]

    field_count = len(
        populated_fields
    )

    cleaned_text = clean_text(
        raw_text
    )

    text_length = len(
        cleaned_text
    )

    field_score = min(
        field_count / 4.0,
        1.0,
    )

    text_score = min(
        text_length / 150.0,
        1.0,
    )

    score = (
        field_score * 0.70
        + text_score * 0.30
    )

    return round(
        max(
            0.0,
            min(
                score,
                1.0,
            ),
        ),
        4,
    )


# ============================================================
# DATE VALIDATION
# ============================================================

def validate_date_value(
    value: Optional[str],
) -> tuple[
    Optional[bool],
    Optional[str],
]:
    """
    Validate an extracted date.

    Checks:

    - recognizable date
    - parsable date
    - not in the future
    - year >= 1900
    """

    if not value:
        return None, None

    extracted = extract_date_from_value(
        value
    )

    if not extracted:

        return (
            False,
            "No recognizable date pattern was found.",
        )

    parsed = parse_date(
        extracted
    )

    if parsed is None:

        return (
            False,
            "Date could not be parsed.",
        )

    if parsed > date.today():

        return (
            False,
            "Date is in the future.",
        )

    if parsed.year < 1900:

        return (
            False,
            "Date is earlier than the supported range.",
        )

    return True, None


# ============================================================
# NAME SANITY
# ============================================================

def _contains_field_label(
    value: str,
) -> Optional[str]:
    """
    Detect obvious OCR leakage from another field.

    Example:

        ISHAN SHARMA Holder's Signature

    contains:

        holder
        signature

    Therefore it should not be accepted as a clean name.
    """

    lowered = value.lower()

    label_patterns = [
        (
            r"\bholder'?s?\s+signature\b",
            "holder's signature",
        ),

        (
            r"\bsignature\b",
            "signature",
        ),

        (
            r"\bdate\s+of\s+birth\b",
            "date of birth",
        ),

        (
            r"\bblood\s+group\b",
            "blood group",
        ),

        (
            r"\borgan\s+donor\b",
            "organ donor",
        ),

        (
            r"\bissue\s+date\b",
            "issue date",
        ),

        (
            r"\bvalidity\b",
            "validity",
        ),

        (
            r"\baddress\b",
            "address",
        ),

        (
            r"\blicen[cs]e\b",
            "license/licence",
        ),

        (
            r"\bpassport\b",
            "passport",
        ),

        (
            r"\baadhaar\b",
            "aadhaar",
        ),
    ]

    for pattern, label in label_patterns:

        if re.search(
            pattern,
            lowered,
        ):

            return label

    return None


def validate_name_value(
    value: Optional[str],
) -> tuple[
    Optional[bool],
    Optional[str],
]:
    """
    Generic name sanity checking.

    This does NOT verify identity.

    A name must:

    - contain alphabetic characters
    - contain 1-5 words
    - not contain obvious field labels
    - not look like OCR garbage
    """

    if not value:
        return None, None

    original = clean_text(
        value
    )

    if not original:

        return (
            False,
            "Extracted name is empty.",
        )

    leakage = _contains_field_label(
        original
    )

    if leakage:

        return (
            False,
            (
                "Extracted name contains "
                f"another field label: {leakage}."
            ),
        )

    normalized = normalize_name(
        original
    )

    if not normalized:

        return (
            False,
            "Extracted name is empty after normalization.",
        )

    if len(normalized) < 3:

        return (
            False,
            "Extracted name is too short.",
        )

    words = normalized.split()

    # Much stricter than the old 8-token limit.
    if len(words) > 5:

        return (
            False,
            "Extracted name contains too many tokens.",
        )

    # Reject words that are obviously too short for normal
    # person names, except initials.
    for word in words:

        if len(word) == 1:

            # A single-character initial is allowed.
            continue

        if not re.fullmatch(
            r"[A-Z][A-Z.'-]*",
            word,
        ):

            return (
                False,
                "Extracted name contains invalid token(s).",
            )

    # A meaningful name should have at least one word with
    # two alphabetic characters.
    if not any(
        len(
            re.sub(
                r"[^A-Z]",
                "",
                word,
            )
        ) >= 2
        for word in words
    ):

        return (
            False,
            "Extracted name does not look like a person name.",
        )

    return True, None


# ============================================================
# GENERIC FIELD VALUE SANITY
# ============================================================

def validate_identifier_value(
    value: Optional[str],
) -> tuple[
    Optional[bool],
    Optional[str],
]:
    """
    Generic identifier sanity checking.

    IMPORTANT:

        This does NOT check PAN/Aadhaar/passport/DL/Voter
        formats.

    It only catches obvious extraction errors such as dates
    being incorrectly assigned as identifiers.
    """

    if not value:
        return None, None

    cleaned = clean_text(
        value
    )

    if not cleaned:

        return (
            False,
            "Identifier is empty.",
        )

    # A date must not become a document identifier.
    if re.fullmatch(
        r"\d{1,4}[./-]\d{1,2}[./-]\d{2,4}",
        cleaned,
    ):

        return (
            False,
            "Extracted identifier appears to be a date.",
        )

    compact = re.sub(
        r"[^A-Za-z0-9]",
        "",
        cleaned,
    )

    if len(compact) < 4:

        return (
            False,
            "Extracted identifier is too short.",
        )

    if len(compact) > 40:

        return (
            False,
            "Extracted identifier is unusually long.",
        )

    return True, None


# ============================================================
# INTERNAL CONSISTENCY
# ============================================================

def check_internal_consistency(
    fields: dict,
) -> tuple[
    bool,
    list[str],
]:
    """
    Check whether extracted fields are internally sensible.

    This is document-type independent.

    No PAN/Aadhaar/passport/DL format validation occurs here.
    """

    messages: list[str] = []

    # --------------------------------------------------------
    # DOB
    # --------------------------------------------------------

    dob = fields.get(
        "dob"
    )

    dob_parsed = None

    if dob:

        dob_ok, dob_reason = (
            validate_date_value(
                dob
            )
        )

        if dob_ok is False:

            messages.append(
                "DOB consistency check failed: "
                f"{dob_reason}"
            )

        else:

            dob_parsed = parse_date(
                dob
            )

    # --------------------------------------------------------
    # Issue date
    # --------------------------------------------------------

    issue_date = fields.get(
        "issue_date"
    )

    issue_parsed = None

    if issue_date:

        issue_ok, issue_reason = (
            validate_date_value(
                issue_date
            )
        )

        if issue_ok is False:

            messages.append(
                "Issue date consistency check failed: "
                f"{issue_reason}"
            )

        else:

            issue_parsed = parse_date(
                issue_date
            )

    # --------------------------------------------------------
    # DOB vs issue date
    # --------------------------------------------------------

    if (
        dob_parsed is not None
        and issue_parsed is not None
        and issue_parsed < dob_parsed
    ):

        messages.append(
            "Issue date occurs before the date of birth."
        )

    # --------------------------------------------------------
    # NAME
    # --------------------------------------------------------

    name = fields.get(
        "name"
    )

    if name:

        name_ok, name_reason = (
            validate_name_value(
                name
            )
        )

        if name_ok is False:

            messages.append(
                "Name consistency check failed: "
                f"{name_reason}"
            )

    # --------------------------------------------------------
    # DOCUMENT NUMBER
    # --------------------------------------------------------

    document_number = fields.get(
        "document_number"
    )

    if document_number:

        identifier_ok, identifier_reason = (
            validate_identifier_value(
                document_number
            )
        )

        if identifier_ok is False:

            messages.append(
                "Document number consistency check failed: "
                f"{identifier_reason}"
            )

    # --------------------------------------------------------
    # Result
    # --------------------------------------------------------

    return (
        len(messages) == 0,
        messages,
    )


# ============================================================
# MAIN VALIDATOR
# ============================================================

def validate_fields(
    fields: dict,
    document_type: str = "unknown",
) -> dict:
    """
    UNIVERSAL CONTENT VALIDATOR.

    This function does NOT decide whether a document is genuine.

    It does NOT perform document-type authenticity validation.

    It does NOT require a PAN/Aadhaar/passport/DL/Voter
    number.

    It only checks:

        - extraction quality
        - date sanity
        - name sanity
        - identifier sanity
        - internal consistency
    """

    fields = fields or {}

    messages: list[str] = []

    # ========================================================
    # 1. RAW OCR CONTENT
    # ========================================================

    raw_text = clean_text(
        fields.get(
            "raw_text",
            "",
        )
    )

    # ========================================================
    # 2. CONTENT QUALITY
    # ========================================================

    content_quality = (
        calculate_content_quality(
            fields,
            raw_text,
        )
    )

    # ========================================================
    # 3. POPULATED FIELDS
    # ========================================================

    useful_fields = (
        "name",
        "dob",
        "document_number",
        "issue_date",
        "certificate_id",
        "course",
        "issuer",
    )

    populated_fields = [
        field_name
        for field_name in useful_fields
        if fields.get(
            field_name
        )
        and str(
            fields.get(
                field_name
            )
        ).strip()
    ]

    populated_count = len(
        populated_fields
    )

    # ========================================================
    # 4. CONTENT SUFFICIENCY
    # ========================================================

    if (
        populated_count == 0
        and len(raw_text) < 20
    ):

        content_sufficient = False

    elif (
        content_quality < 0.25
        and len(raw_text) < 40
    ):

        content_sufficient = False

    else:

        content_sufficient = True

    if not content_sufficient:

        messages.append(
            "Insufficient readable/extracted content "
            "for meaningful content validation."
        )

    # ========================================================
    # 5. DATE VALIDATION
    # ========================================================

    date_results: list[bool] = []

    for field_name in (
        "dob",
        "issue_date",
    ):

        value = fields.get(
            field_name
        )

        if not value:
            continue

        ok, reason = (
            validate_date_value(
                value
            )
        )

        if ok is None:
            continue

        date_results.append(
            ok
        )

        if not ok:

            messages.append(
                f"{field_name.replace('_', ' ').title()} "
                f"is invalid: {reason}"
            )

    if not date_results:

        date_valid = None

    else:

        date_valid = all(
            date_results
        )

    # ========================================================
    # 6. NAME VALIDATION
    # ========================================================

    name = fields.get(
        "name"
    )

    name_valid = None

    if name:

        name_ok, name_reason = (
            validate_name_value(
                name
            )
        )

        name_valid = name_ok

        if name_ok is False:

            messages.append(
                f"Name is invalid: {name_reason}"
            )

    # ========================================================
    # 7. IDENTIFIER SANITY
    # ========================================================

    document_number = fields.get(
        "document_number"
    )

    identifier_valid = None

    if document_number:

        identifier_ok, identifier_reason = (
            validate_identifier_value(
                document_number
            )
        )

        identifier_valid = identifier_ok

        if identifier_ok is False:

            messages.append(
                "Document number is invalid: "
                f"{identifier_reason}"
            )

    # ========================================================
    # 8. NO DOCUMENT-FORMAT AUTHENTICITY CHECK
    # ========================================================
    #
    # Deliberately no:
    #
    #     PAN regex
    #     Aadhaar regex
    #     Passport regex
    #     DL regex
    #     Voter ID regex
    #
    # This is intentional.
    #
    # Document type remains informational.
    # ========================================================

    format_valid = True

    # ========================================================
    # 9. INTERNAL CONSISTENCY
    # ========================================================

    internally_consistent, consistency_messages = (
        check_internal_consistency(
            fields
        )
    )

    messages.extend(
        consistency_messages
    )

    # ========================================================
    # 10. FIELD-LEVEL VALIDITY
    # ========================================================

    invalid_name = (
        name_valid is False
    )

    invalid_identifier = (
        identifier_valid is False
    )

    invalid_date = (
        date_valid is False
    )

    # ========================================================
    # 11. OVERALL CONTENT CONSISTENCY
    # ========================================================

    fields_consistent = (
        content_sufficient
        and internally_consistent
        and not invalid_name
        and not invalid_identifier
        and not invalid_date
    )

    # ========================================================
    # 12. CONTENT SUFFICIENCY
    # ========================================================

    required_fields_present = (
        content_sufficient
    )

    # ========================================================
    # 13. VALIDATION STATUS
    # ========================================================

    if (
        content_sufficient
        and fields_consistent
    ):

        validation_status = "SUFFICIENT"

    elif not content_sufficient:

        validation_status = "INSUFFICIENT"

    else:

        validation_status = "INCONSISTENT"

    # ========================================================
    # 14. DEFAULT MESSAGE
    # ========================================================

    if not messages:

        messages.append(
            "Generic content validation completed "
            "without detected contradictions."
        )

    # Remove duplicate messages while preserving order.
    messages = list(
        dict.fromkeys(
            messages
        )
    )

    # ========================================================
    # 15. RETURN
    # ========================================================

    return {
        "document_type": (
            document_type
            or "unknown"
        ),

        "format_valid": (
            format_valid
        ),

        "required_fields_present": (
            required_fields_present
        ),

        "date_valid": date_valid,

        "fields_consistent": (
            fields_consistent
        ),

        "content_quality": (
            content_quality
        ),

        "validation_status": (
            validation_status
        ),

        "populated_fields": (
            populated_fields
        ),

        "messages": messages,
    }