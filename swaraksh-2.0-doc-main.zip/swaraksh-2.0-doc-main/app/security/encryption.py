from cryptography.fernet import Fernet
from pathlib import Path

class EncryptionService:
    def __init__(self, key: str | None):
        self.key = key.encode() if key else Fernet.generate_key()
        self.fernet = Fernet(self.key)
        self.ephemeral = key is None

    @property
    def key_for_env(self) -> str:
        return self.key.decode()

    def encrypt_to_file(self, data: bytes, path: Path) -> None:
        path.write_bytes(self.fernet.encrypt(data))

    def decrypt_file(self, path: Path) -> bytes:
        return self.fernet.decrypt(path.read_bytes())
