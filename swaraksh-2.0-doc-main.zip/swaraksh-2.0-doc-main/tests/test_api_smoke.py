from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from fastapi.testclient import TestClient
from app.main import app


def make_image():
    img = Image.new("RGB", (1200, 700), "white")
    draw = ImageDraw.Draw(img)
    draw.text((80, 70), "INCOME TAX DEPARTMENT", fill="black")
    draw.text((80, 150), "Permanent Account Number", fill="black")
    draw.text((80, 250), "Name: HARSHAL JAIN", fill="black")
    draw.text((80, 330), "DOB: 15/08/2003", fill="black")
    draw.text((80, 430), "ABCDE1234F", fill="black")
    data = BytesIO()
    img.save(data, format="PNG")
    return data.getvalue()


def test_verify_endpoint():
    with TestClient(app) as client:
        response = client.post(
        "/api/v1/documents/verify",
        files={"file": ("test.png", make_image(), "image/png")},
        data={"expected_name": "HARSHAL JAIN", "expected_dob": "15/08/2003", "expected_document_number": "ABCDE1234F"},
    )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["document_type"] == "pan"
        assert body["fields"]["document_number"] == "ABCDE1234F"
        assert body["cross_validation"]["match_score"] == 1.0
