import numpy as np

from app.services.document_integrity import analyze
from app.services.field_validator import validate_fields
from app.services.risk_engine import calculate


def test_unknown_document_does_not_fail_because_of_missing_id_number():
    fields = {
        'name': None,
        'dob': '31/08/2005',
        'document_number': None,
        'issue_date': None,
        'certificate_id': None,
        'course': None,
        'issuer': None,
        'raw_text': 'This is readable document content with a valid date 31/08/2005 and other text.'
    }
    result = validate_fields(fields, 'unknown')
    assert result['format_valid'] is True
    assert result['required_fields_present'] is True


def test_unknown_document_can_never_pass_with_low_ocr():
    validation = {
        'required_fields_present': False,
        'fields_consistent': False,
        'date_valid': None,
        'format_valid': True,
    }
    face = {'face_detected': False, 'manipulation_probability': 0.0}
    integrity = {'quality_score': 0.8, 'tampering_evidence_score': 0.0, 'signals': {}}
    cross = {'attempted': False, 'match_score': 0.0}
    result = calculate(0.2, validation, face, integrity, cross, document_type='unknown')
    assert result['decision'] == 'REVIEW'


def test_integrity_is_independent_of_document_type():
    image = np.full((600, 900, 3), 180, dtype=np.uint8)
    a = analyze(image, False, 'Some readable text for analysis', 'certificate', [], 0.9)
    b = analyze(image, False, 'Some readable text for analysis', 'aadhaar', [], 0.9)
    assert a['tampering_probability'] == b['tampering_probability']
    assert a['score'] == b['score']
