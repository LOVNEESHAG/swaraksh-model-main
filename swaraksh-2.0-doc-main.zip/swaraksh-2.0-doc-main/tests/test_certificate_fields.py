from app.services.field_extractor import extract_fields
from app.services.field_validator import validate_fields


CERTIFICATE_TEXT = """Infosys Navigate your next
PROGRAM COMPLETION CERTIFICATE
The certificate is awarded to LOVNEESH AGRAWAL for successfully completing the program Data Science (114h 9m) on June 30, 2026
Issued on: Thursday, June 30, 2026
Infosys Limited
"""


def test_certificate_fields_extract():
    fields = extract_fields(CERTIFICATE_TEXT, "certificate")
    assert fields["name"] == "LOVNEESH AGRAWAL"
    assert fields["issue_date"] == "June 30, 2026"
    assert fields["issuer"] == "Infosys Limited"


def test_certificate_validation_does_not_require_id_number():
    fields = extract_fields(CERTIFICATE_TEXT, "certificate")
    result = validate_fields(fields, "certificate")
    assert result["format_valid"] is True
    assert result["required_fields_present"] is True
    assert result["date_valid"] is True
    assert result["fields_consistent"] is True
    assert not any("Document number" in msg for msg in result["messages"])
