from app.services.field_validator import validate_fields


def test_valid_content():

    result = validate_fields(
        {
            "name": "TEST PERSON",
            "dob": "15/08/2003",
            "document_number": "ABCDE1234F",
            "raw_text": "TEST PERSON DOB 15/08/2003 ABCDE1234F",
        },
        "unknown",
    )

    assert result["format_valid"] is True
    assert result["required_fields_present"] is True
    assert result["date_valid"] is True
    assert result["fields_consistent"] is True
    assert result["validation_status"] == "SUFFICIENT"


def test_invalid_date():

    result = validate_fields(
        {
            "name": "TEST PERSON",
            "dob": "31/02/2003",
            "document_number": "ABC123",
            "raw_text": "TEST PERSON DOB 31/02/2003 ABC123",
        },
        "unknown",
    )

    assert result["date_valid"] is False
    assert result["fields_consistent"] is False


def test_missing_document_number_is_allowed():

    result = validate_fields(
        {
            "name": "TEST PERSON",
            "dob": "15/08/2003",
            "document_number": None,
            "raw_text": "TEST PERSON DOB 15/08/2003",
        },
        "unknown",
    )

    assert result["required_fields_present"] is True
    assert result["date_valid"] is True
    assert result["fields_consistent"] is True


def test_document_number_format_does_not_control_universal_validation():

    result = validate_fields(
        {
            "name": "TEST PERSON",
            "dob": "15/08/2003",
            "document_number": "ABC123",
            "raw_text": "TEST PERSON DOB 15/08/2003 ABC123",
        },
        "pan",
    )

    # The document number may not match a PAN pattern,
    # but that is NOT used by our universal authenticity pipeline.
    assert result["format_valid"] is True
    assert result["date_valid"] is True
    assert result["fields_consistent"] is True


def test_empty_content_is_insufficient():

    result = validate_fields(
        {
            "name": None,
            "dob": None,
            "document_number": None,
            "raw_text": "",
        },
        "unknown",
    )

    assert result["required_fields_present"] is False
    assert result["fields_consistent"] is False
    assert result["validation_status"] == "INSUFFICIENT"