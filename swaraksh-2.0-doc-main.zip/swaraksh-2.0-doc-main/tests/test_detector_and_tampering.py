import cv2
import numpy as np

from app.services.document_detector import detect_document_type
from app.services.face_tampering import analyze


def test_certificate_is_not_classified_as_pan():
    img = np.zeros((600, 900, 3), dtype=np.uint8)
    text = "PROGRAM COMPLETION CERTIFICATE Infosys Data Science successfully completing the program"
    doc_type, confidence, evidence = detect_document_type(text, img)
    assert doc_type == "certificate"
    assert confidence > 0
    assert "certificate" in evidence or "program completion certificate" in evidence


def test_single_pan_word_does_not_become_pan():
    img = np.zeros((600, 900, 3), dtype=np.uint8)
    doc_type, _, _ = detect_document_type("PAN", img)
    assert doc_type == "unknown"


def test_face_tamper_heuristic_is_bounded():
    doc = np.full((600, 900, 3), 180, dtype=np.uint8)
    face = doc[200:400, 350:550].copy()
    result = analyze(face, doc)
    assert 0.0 <= result.probability <= 1.0
    assert result.signals.get("heuristic_only") is True
