from app.models.schemas import ReferenceIdentity
from app.services.cross_validator import compare

def test_reference_match():
    fields = {"name": "Harshal Jain", "dob": "15/08/2003", "document_number": "ABCDE1234F"}
    ref = ReferenceIdentity(name="HARSHAL JAIN", dob="15/08/2003", document_number="ABCDE1234F")
    result = compare(fields, ref)
    assert result["attempted"] is True
    assert result["match_score"] == 1.0
